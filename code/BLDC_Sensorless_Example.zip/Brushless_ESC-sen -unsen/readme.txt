http://www.avislab.com/blog/brushless08/
