

#include <avr/io.h>
#include <util/delay.h>
#include "i2c_lcd.h"

// === PCF8574 LCD wiring assumptions ===
// P0 = RS, P1 = RW (GND), P2 = EN, P3 = Backlight (optional)
// P4 = D4, P5 = D5, P6 = D6, P7 = D7

#define LCD_ADDR 0x27
#define ENABLE 0b00000100
#define BACKLIGHT 0b00001000

void i2c_start(void) {
	TWCR = (1 << TWSTA) | (1 << TWEN) | (1 << TWINT);
	while (!(TWCR & (1 << TWINT)));
}

void i2c_stop(void) {
	TWCR = (1 << TWSTO) | (1 << TWEN) | (1 << TWINT);
	_delay_us(10);
}

void i2c_write(uint8_t data) {
	TWDR = data;
	TWCR = (1 << TWEN) | (1 << TWINT);
	while (!(TWCR & (1 << TWINT)));
}

void lcd_send_i2c(uint8_t data) {
	i2c_start();
	i2c_write((LCD_ADDR << 1));
	i2c_write(data | BACKLIGHT);
	i2c_stop();
}

void lcd_pulse_enable(uint8_t data) {
	lcd_send_i2c(data | ENABLE);
	_delay_us(1);
	lcd_send_i2c(data & ~ENABLE);
	_delay_us(50);
}

void lcd_write_nibble(uint8_t nibble, uint8_t rs) {
	uint8_t data = (nibble & 0xF0) | (rs ? 0x01 : 0x00);
	lcd_pulse_enable(data);
}

void lcd_send_byte(uint8_t value, uint8_t rs) {
	lcd_write_nibble(value & 0xF0, rs);
	lcd_write_nibble((value << 4) & 0xF0, rs);
}

void i2c_lcd_command(uint8_t cmd) {
	lcd_send_byte(cmd, 0);
}

void i2c_lcd_char(char c) {
	lcd_send_byte(c, 1);
}

void i2c_lcd_init(void) {
	// I2C Init
	TWSR = 0;
	TWBR = 32; // ~100kHz with 16MHz clock

	_delay_ms(50);

	lcd_write_nibble(0x30, 0); _delay_ms(5);
	lcd_write_nibble(0x30, 0); _delay_us(200);
	lcd_write_nibble(0x30, 0); _delay_us(200);
	lcd_write_nibble(0x20, 0); _delay_us(200); // 4-bit mode

	i2c_lcd_command(0x28); // 2 lines, 5x8
	i2c_lcd_command(0x0C); // Display on, no cursor
	i2c_lcd_command(0x06); // Entry mode
	i2c_lcd_clear();
}

void i2c_lcd_clear(void) {
	i2c_lcd_command(0x01);
	_delay_ms(2);
}

void i2c_lcd_print(const char* str) {
	while (*str) {
		i2c_lcd_char(*str++);
	}
}

void i2c_lcd_goto(uint8_t x, uint8_t y) {
	uint8_t addr = (y == 0) ? 0x00 : 0x40;
	i2c_lcd_command(0x80 | (addr + x));
}
