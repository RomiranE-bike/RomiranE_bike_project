#ifndef I2C_LCD_H
#define I2C_LCD_H

void i2c_lcd_init(void);
void i2c_lcd_clear(void);
void i2c_lcd_print(const char* str);
void i2c_lcd_goto(uint8_t x, uint8_t y);

#endif
