/*
 * ATmega328_Master.c
 *
 * Created: 6/1/2025 20:41:13
 * Author : User
 */ 




#define F_CPU 16000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "i2c_lcd.h"

#define BUTTON_PIN PD2
#define BUZZER_PIN PD4

volatile uint8_t button_pressed = 0;

void GPIO_Init(void) {
	DDRD &= ~(1 << BUTTON_PIN); // Set PD2 as input
	PORTD |= (1 << BUTTON_PIN); // Enable internal pull-up
	DDRD |= (1 << BUZZER_PIN);  // Set PD3 as output
	PORTD &= ~(1 << BUZZER_PIN); // Turn buzzer off
}

void Buzzer_Beep(void) {
	PORTD |= (1 << BUZZER_PIN);
	_delay_ms(100);
	PORTD &= ~(1 << BUZZER_PIN);
}

ISR(INT0_vect) {
	button_pressed = 1;
}

void External_Interrupt_Init(void) {
	EIMSK |= (1 << INT0);      // Enable INT0 interrupt
	EICRA |= (1 << ISC01);     // Trigger on falling edge
	sei();                     // Enable global interrupts
}

int main(void) {
	GPIO_Init();
	i2c_lcd_init();
	i2c_lcd_clear();
	i2c_lcd_print("System Ready");

	External_Interrupt_Init();

	while (1) {
		if (button_pressed) {
			button_pressed = 0;
			i2c_lcd_clear();
			i2c_lcd_print("Button Pressed");
			Buzzer_Beep();
		}
	}
}
