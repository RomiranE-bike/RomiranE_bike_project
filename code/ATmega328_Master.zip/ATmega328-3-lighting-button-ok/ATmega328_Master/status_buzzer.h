#ifndef STATUS_BUZZER_H
#define STATUS_BUZZER_H

#include <stdint.h>

enum BuzzerPattern {
    STARTUP,
    FAULT,
    LOCKED,
    UNLOCKED,
    POWER_OFF,
    PIN_FAIL,
    OVERHEAT,
	ALARM,
	BEEP,
    MODE_SWITCH
};

void buzzer_init(void);
void buzzer_play_tone(uint16_t frequency, uint16_t duration_ms);
void buzzer_pattern(enum BuzzerPattern pattern);
void pattern_test(void);

#endif
