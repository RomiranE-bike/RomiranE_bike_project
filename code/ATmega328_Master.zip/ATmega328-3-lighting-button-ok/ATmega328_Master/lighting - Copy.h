/**
 * Intelligent Lighting v1.4
 * PWM-controlled with animations
 */

// FILE: lighting.h
#ifndef LIGHTING_H
#define LIGHTING_H

#include <stdbool.h>
#include <stdint.h>

// Modes
typedef enum {
	LIGHT_MODE_OFF,
	LIGHT_MODE_DAY,
	LIGHT_MODE_NIGHT,
	LIGHT_MODE_HAZARD
} LightMode;

// LED pattern codes
typedef enum {
	LIGHT_PATTERN_STARTUP,
	LIGHT_PATTERN_FAULT,
	LIGHT_PATTERN_LOCKED,
	LIGHT_PATTERN_UNLOCKED,
	LIGHT_PATTERN_MODE_SWITCH
} LightingPattern;

// Turn signal codes
typedef enum {
	SIGNAL_NONE = 0,
	SIGNAL_LEFT,
	SIGNAL_RIGHT,
	SIGNAL_HAZARD
} SignalMode;

void Lighting_Init(void);
void Lighting_SetMode(LightMode mode);
void Lighting_SetBrake(bool active);
void Lighting_SetSignal(SignalMode mode);
void Lighting_Update(void);
void Lighting_HandleSignals(void);
void Lighting_PlayPattern(LightingPattern pattern);

#endif