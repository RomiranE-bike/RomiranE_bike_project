/*
 * ATmega328 Motor Controller
 * 
 * Features:
 * - Dual motor control with PID
 * - LCD interface
 * - UART communication
 * - EEPROM storage for PID parameters
 * - Over-temperature/current protection
 * 
 * Pin Configuration:
 * - LCD: PORTB
 * - Button: PD2
 * - UART: PD0/RX, PD1/TX
 * - ADC: Throttle input on ADC0
 */
//--------------------------------------------------------------------------------------------------------
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include "lcd.h"
#include "config.h"
#include "status_buzzer.h"
#include "lighting.h"
//--------------------------------------------------------------------------------------------------------
#define F_CPU 16000000UL
#define BAUD 9600
#define UBRR_VAL ((F_CPU / (16UL * BAUD)) - 1)
//--------------------------------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------------

int main(void) {
	
	// Initialize peripherals
	
	
	lcd_init();     // Initialize LCD
	lcd_clear();    // Clear screen
	lcd_print("E-Bike Lighting");
	buzzer_init();
	lighting_init();
	
	

	while (1) {
		
		//pattern_test();
		//update_lights();
		_delay_ms(10);  // Main loop delay		
       // _delay_ms(200); // Update rate ~5Hz

	}
}
//--------------------------------------------------------------------------------------------------------
