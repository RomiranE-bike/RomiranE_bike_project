#ifndef CONFIG_H
#define CONFIG_H

#include <avr/io.h>
#include <stdint.h>

#include <avr/interrupt.h>
#include <stdbool.h>
//------------------------------------------------------------------------------------
// System Configuration
#define F_CPU 16000000UL

#define SAMPLE_RATE_MS 100
#define LCD_REFRESH_RATE 500
#define SOC_UPDATE_INTERVAL 5000

//------------------------------------------------------------------------------------
// Beep Configuration (Used for timing buzzer tones)
#define F_BEEP   500     // Beep frequency in Hz
#define D_BEEP   2000    // Beep duration in us

//------------------------------------------------------------------------------------
// LCD Configuration - PORTB
#define LCD_RS_PORT     PORTB
#define LCD_RS_DDR      DDRB
#define LCD_RS_PIN      PB2
#define LCD_EN_PIN      PB3
#define LCD_D4_PIN      PB4
#define LCD_D5_PIN      PB5
#define LCD_D6_PIN      PB6
#define LCD_D7_PIN      PB7

//------------------------------------------------------------------------------------
// Button Inputs - PORTC
#define BUTTON_PORT         PINC
#define BUTTON_UP_PIN       PC0
#define BUTTON_DOWN_PIN     PC1
#define BUTTON_OK_PIN       PC2
#define BUTTON_BACK_PIN     PC3

//------------------------------------------------------------------------------------
/* Analog Input Pin Definitions */
#define THROTTLE_PIN        PC4     //  Throttle position sensor(if using Arduino framework)
#define BATTERY_VOLT_PIN    PC5     // A2 - Battery voltage monitoring
#define TEMP_SENSOR_PIN     PC6     // A3 - Temperature sensor input

//------------------------------------------------------------------------------------
// Output Pins - BUZZER & LIGHTS
#define BUZZER_PORT     PORTB
#define BUZZER_DDR      DDRB
#define BUZZER_PIN      PB1
#define STATUS_LED_PIN  PB0

// LED Pin Definitions
#define HEAD_LIGHT_PIN    PD6  // D6 (OC0A)
#define TAIL_LIGHT_PIN   PD5  // D5 (OC0B)
#define BRAKE_LIGHT_PIN  PD5  // Shared with taillight
#define LEFT_LIGHT_PIN   PD7  // D7
#define RIGHT_LIGHT_PIN  PD4  // D4
#define HAZARD_IND_PIN   PD5  // Shared

// Button Pins
#define MODE_BTN_PIN     PC0
#define BRAKE_BTN_PIN    PC1
#define LEFT_BTN_PIN     PC2
#define RIGHT_BTN_PIN    PC3

//------------------------------------------------------------------------------------
// Battery Configuration
#define BATTERY_CAPACITY_MAH     10000
#define BATTERY_CELLS            10
#define BATTERY_FULL_VOLTAGE     42.0f
#define BATTERY_EMPTY_VOLTAGE    30.0f
#define LOW_VOLTAGE_WARNING      33.0f

//------------------------------------------------------------------------------------
// Safety Limits
#define MAX_BATTERY_CURRENT  20.0f   // Amperes
#define MAX_MOTOR_TEMP       80.0f   // Celsius

//------------------------------------------------------------------------------------
// I2C Configuration
#define MOTOR1_I2C_ADDR  0x10
#define MOTOR2_I2C_ADDR  0x12

#define CMD_SET_TORQUE      0x01
#define CMD_SET_SPEED       0x02
#define CMD_SHUTDOWN        0x03
#define CMD_REDUCE_POWER    0x04

//------------------------------------------------------------------------------------
// EEPROM Addresses
#define EEPROM_PIN_ADDR          0x00
#define EEPROM_SETTINGS_ADDR     0x10
#define EEPROM_LOG_START_ADDR    0x50

//------------------------------------------------------------------------------------
// Ride Mode Enumeration
typedef enum {
	MODE_ECO = 0,
	MODE_NORMAL,
	MODE_SPORT,
	MODE_COUNT
} RideMode;

#endif // CONFIG_H
