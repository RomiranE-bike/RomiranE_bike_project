
// FILE: lighting.c
#include "lighting.h"
#include "config.h"
#include <avr/io.h>
#include <util/delay.h>


static LightMode current_mode = LIGHT_MODE_OFF;
static bool brake_active = false;
static SignalMode signal_mode = SIGNAL_NONE;
static uint8_t pwm_duty = 0;

void Lighting_Init(void) {
	DDRD |= (1 << TAIL_LIGHT_PIN) | (1 << HEAD_LIGHT_PIN);
	DDRD |= (1 << LEFT_SIGNAL_PIN) | (1 << RIGHT_SIGNAL_PIN);
	DDRD |= (1 << PD3); // OC2B for PWM
	DDRC &= ~(1 << BRAKE_SW_PIN);//for break switch

	TCCR2A |= (1 << COM2B1) | (1 << WGM21) | (1 << WGM20);
	TCCR2B |= (1 << CS22); // prescaler 64
	OCR2B = 0;
}

void Lighting_SetMode(LightMode mode) {
	current_mode = mode;
}

void Lighting_SetBrake(bool active) {
	brake_active = active;
}

void Lighting_SetSignal(SignalMode mode) {
	signal_mode = mode;
}


void Lighting_Update(void) {
	static uint8_t hazard_counter = 0;

	if (brake_active) {
		OCR2B = 255;
		return;
	}

	switch (current_mode) {
		case LIGHT_MODE_HAZARD:
		hazard_counter = (hazard_counter + 1) % 20;
		OCR2B = (hazard_counter < 10) ? 255 : 0;
		break;
		case LIGHT_MODE_NIGHT:
		if (pwm_duty < 200) pwm_duty += 5;
		OCR2B = pwm_duty;
		break;
		default:
		OCR2B = 0;
	}
}

void Lighting_HandleSignals(void) {
	static uint8_t blink_state = 0;
	static uint16_t blink_timer = 0;

	blink_timer++;
	if (blink_timer > 20) {
		blink_timer = 0;
		blink_state = !blink_state;

		if (signal_mode == SIGNAL_LEFT || signal_mode == SIGNAL_HAZARD) {
			if (blink_state) {
				PORTD |= (1 << LEFT_SIGNAL_PIN);
				} else {
				PORTD &= ~(1 << LEFT_SIGNAL_PIN);
			}
			} else {
			PORTD &= ~(1 << LEFT_SIGNAL_PIN);
		}

		if (signal_mode == SIGNAL_RIGHT || signal_mode == SIGNAL_HAZARD) {
			if (blink_state) {
				PORTD |= (1 << RIGHT_SIGNAL_PIN);
				} else {
				PORTD &= ~(1 << RIGHT_SIGNAL_PIN);
			}
			} else {
			PORTD &= ~(1 << RIGHT_SIGNAL_PIN);
		}
	}
}

void Lighting_PlayPattern(LightingPattern pattern) {
	for (uint8_t i = 0; i < 3; i++) {
		switch (pattern) {
			case LIGHT_PATTERN_STARTUP:
			OCR2B = 255; _delay_ms(100); OCR2B = 0; _delay_ms(100);
			break;
			case LIGHT_PATTERN_FAULT:
			OCR2B = 255; _delay_ms(300); OCR2B = 0; _delay_ms(200);
			break;
			case LIGHT_PATTERN_LOCKED:
			OCR2B = 180; _delay_ms(500); OCR2B = 0; _delay_ms(200);
			break;
			case LIGHT_PATTERN_UNLOCKED:
			OCR2B = 100; _delay_ms(400); OCR2B = 0; _delay_ms(150);
			break;
			case LIGHT_PATTERN_MODE_SWITCH:
			OCR2B = 255; _delay_ms(70); OCR2B = 0; _delay_ms(50);
			break;
		}
	}
}

void Lighting_test(void){
	

	 //Lighting_SetMode(LIGHT_MODE_HAZARD);
	 //Lighting_SetBrake(true);
	 //Lighting_SetSignal(SIGNAL_LEFT);
	 //Lighting_Update();
	 //Lighting_HandleSignals();
	 Lighting_PlayPattern(LIGHT_PATTERN_STARTUP);
}
