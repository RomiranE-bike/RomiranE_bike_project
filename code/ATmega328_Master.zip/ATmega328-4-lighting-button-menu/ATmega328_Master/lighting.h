/**
 * Intelligent Lighting System v4.0
 * Complete implementation with:
 * - Brake light override
 * - Turn signals with auto-cancel
 * - Button inputs (brake, left, right)
 * - Non-blocking operation
 */
/**
 * Lighting System v4.1 (No millis())
 * Pin Configuration:
 * - Headlight: PD6 (OC0A)
 * - Taillight/Brake: PD5 (OC0B)
 * - Left Signal: PD7
 * - Right Signal: PD4
 * - Break light: PD5 (shared with taillight)
 */
//---------------------------------------------------------------------------------------------------------
// FILE: lighting.h
#ifndef LIGHTING_H
#define LIGHTING_H
//---------------------------------------------------------------------------------------------------------
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdbool.h>
#include "lcd.h"
#include "config.h"
#include "status_buzzer.h"
//---------------------------------------------------------------------------------------------------------
// Mode Definitions
typedef enum {
	MODE_DAY,
	MODE_NIGHT
} LightMode;
//---------------------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------------------
void lighting_init(void);
void update_lights(void);

#endif

//---------------------------------------------------------------------------------------------------------