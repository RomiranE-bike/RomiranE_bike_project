/**
 * Intelligent Lighting v2.2
 * Using Timer0 PWM (OC0A/OC0B)
 */
//---------------------------------------------------------------------------------------------------------
// FILE: lighting.c
#include "lighting.h"
#include "lcd.h"
#include "config.h"
#include "status_buzzer.h"
#include <util/delay.h>
#include <avr/interrupt.h>
//---------------------------------------------------------------------------------------------------------
// --- State Flags ---
volatile bool mode_btn_pressed = false;
volatile bool brake_btn_pressed = false;
volatile bool left_btn_pressed = false;
volatile bool right_btn_pressed = false;

volatile uint8_t tail_blink_counter = 0;
volatile uint8_t signal_blink_counter = 0;

volatile bool tail_blink_state = false;
volatile bool signal_blink_state = false;

volatile uint8_t active_signal_source = 0; // 0 = none, 1 = brake, 2 = left, 3 = right
//---------------------------------------------------------------------------------------------------------
LightMode current_mode = MODE_DAY;
//---------------------------------------------------------------------------------------------------------
void lighting_init(void) {
	// Set output pins
	DDRD |= (1 << HEAD_LIGHT_PIN) | (1 << TAIL_LIGHT_PIN) |
	(1 << LEFT_LIGHT_PIN) | (1 << RIGHT_LIGHT_PIN);

	// Set button pins as input with pull-up resistors
	PORTC |= (1 << MODE_BTN_PIN) | (1 << BRAKE_BTN_PIN) |
	(1 << LEFT_BTN_PIN) | (1 << RIGHT_BTN_PIN);

	// Enable Pin Change Interrupts on PCINT[14:8] (PORTC)
	PCICR |= (1 << PCIE1);
	PCMSK1 |= (1 << PCINT8) | (1 << PCINT9) |(1 << PCINT10) | (1 << PCINT11);

	// Setup Timer0 for ~500ms blink interval at 16MHz / 1024 / 256
	TCCR0A = 0x00;
	TCCR0B |= (1 << CS01) | (1 << CS00); // Prescaler 1024
	TIMSK0 |= (1 << TOIE0);              // Enable overflow interrupt

	sei(); // Global interrupts enabled
}
//---------------------------------------------------------------------------------------------------------
void update_lights(void) {
	
	if (mode_btn_pressed) {buzzer_pattern(BEEP);}
	if (active_signal_source != 0){buzzer_pattern(BEEP);}
			
	// Toggle between DAY and NIGHT modes
	if (mode_btn_pressed) {		
		mode_btn_pressed = false;
		current_mode = (current_mode == MODE_DAY) ? MODE_NIGHT : MODE_DAY;
	}

	// Headlight
	if (current_mode == MODE_NIGHT)
	PORTD |= (1 << HEAD_LIGHT_PIN);
	else
	PORTD &= ~(1 << HEAD_LIGHT_PIN);

	// Tail light logic
	if (active_signal_source == 2 || active_signal_source == 3) {
		PORTD |= (1 << TAIL_LIGHT_PIN); // Solid ON
		} else if (active_signal_source == 1) {
		PORTD |= (1 << BRAKE_LIGHT_PIN); // Brake ON
		} else if (current_mode == MODE_NIGHT && tail_blink_state) {
		PORTD |= (1 << TAIL_LIGHT_PIN); // Blink in night mode
		} else {
		PORTD &= ~(1 << TAIL_LIGHT_PIN);
		PORTD &= ~(1 << BRAKE_LIGHT_PIN);
	}

	// Left indicator
	if (active_signal_source == 2) {
		if (signal_blink_state)
		PORTD |= (1 << LEFT_LIGHT_PIN);
		else
		PORTD &= ~(1 << LEFT_LIGHT_PIN);
		} else {
		PORTD &= ~(1 << LEFT_LIGHT_PIN);
	}

	// Right indicator
	if (active_signal_source == 3) {
		if (signal_blink_state)
		PORTD |= (1 << RIGHT_LIGHT_PIN);
		else
		PORTD &= ~(1 << RIGHT_LIGHT_PIN);
		} else {
		PORTD &= ~(1 << RIGHT_LIGHT_PIN);
	}	
		
}
//---------------------------------------------------------------------------------------------------------
void display_light_state(void) {
	lcd_goto(0, 0);  // First row
	lcd_print("H:");
	lcd_print((PORTD & (1 << HEAD_LIGHT_PIN)) ? "ON " : "OFF");

	//lcd_print(" T:");
	//lcd_print((PORTD & (1 << TAIL_LIGHT_PIN)) ? "ON " : "OFF");
	lcd_print(" B:");
	lcd_print((PORTD & (1 << BRAKE_LIGHT_PIN)) ? "ON" : "OFF");
	
    //lcd_print(" M:");
    lcd_print((current_mode == MODE_NIGHT) ? " NIGHT" : " DAY  ");
	

	lcd_goto(0, 1);  // Second row
	lcd_print("L:");
	lcd_print((PORTD & (1 << LEFT_LIGHT_PIN)) ? "BLK " : "OFF ");

	lcd_print("R:");
	lcd_print((PORTD & (1 << RIGHT_LIGHT_PIN)) ? "BLK " : "OFF ");
	
}
//---------------------------------------------------------------------------------------------------------
// --- PCINT for Buttons ---
ISR(PCINT1_vect) {
	static uint8_t last_state = 0xFF;
	uint8_t current_state  = PINC;

	// Detect falling edge of mode button
	if ((last_state  & (1 << MODE_BTN_PIN)) && !(current_state & (1 << MODE_BTN_PIN))){
		mode_btn_pressed = true;
	}
    
	
	if ((last_state & (1 << BRAKE_BTN_PIN)) && !(current_state & (1 << BRAKE_BTN_PIN))) {
				active_signal_source = (active_signal_source != 1) ? 1 : 0;
				}
	if ((last_state & (1 << LEFT_BTN_PIN)) && !(current_state & (1 << LEFT_BTN_PIN))) {
				active_signal_source = (active_signal_source != 2) ? 2 : 0;
			}
	if ((last_state & (1 << RIGHT_BTN_PIN)) && !(current_state & (1 << RIGHT_BTN_PIN))) {				
            active_signal_source = (active_signal_source != 3) ? 3 : 0;
			}

	last_state = current_state ;
}
//---------------------------------------------------------------------------------------------------------
// --- Timer0 Overflow ISR (~500ms) ---
ISR(TIMER0_OVF_vect) {
	// 61: for ~500ms at 16MHz/1024/256 and 6 : ~100ms blink interval
	 // Tail blinking (~500ms)
	 tail_blink_counter++;
	 if (tail_blink_counter >= 12) {  
		 tail_blink_counter = 0;
		 tail_blink_state = !tail_blink_state;
	 }

	 // Signal blinking (~100ms)
	 signal_blink_counter++;
	 if (signal_blink_counter >= 12) {  
		 signal_blink_counter = 0;
		 signal_blink_state = !signal_blink_state;
	 }

	update_lights();
	display_light_state();  // Show status on LCD
}
//---------------------------------------------------------------------------------------------------------