/**
 * @file watchdog.h
 * @brief Watchdog Timer control
 * @version 2.0.2
 * @date 2023-11-21
 */
#ifndef WATCHDOG_H
#define WATCHDOG_H

#include <avr/wdt.h>

void wdt_init(uint8_t timeout_s);
void wdt_restart(void);  // Renamed from wdt_reset
void wdt_force_reset(void);

#endif // WATCHDOG_H