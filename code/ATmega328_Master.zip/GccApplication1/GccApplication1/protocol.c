/**
 * @file protocol.c
 * @brief Protocol implementation with CRC checking
 * @version 2.0.1
 * @date 2023-11-20
 */

#include "protocol.h"
#include "uart.h"
#include <string.h>

uint8_t calculate_crc(const uint8_t *data, uint8_t length) {
    uint8_t crc = 0;
    for (uint8_t i = 0; i < length; i++) {
        crc ^= data[i];
        for (uint8_t j = 0; j < 8; j++) {
            if (crc & 0x80) {
                crc = (crc << 1) ^ 0x07;
            } else {
                crc <<= 1;
            }
        }
    }
    return crc;
}

uint8_t validate_packet(const motor_packet_t *packet) {
    // Check start byte
    if (packet->start_byte != 0xAA) {
        return 0;
    }
    
    // Check length
    if (packet->length > 16) {
        return 0;
    }
    
    // Verify CRC
    uint8_t calculated_crc = calculate_crc((const uint8_t*)packet, sizeof(motor_packet_t) - 1);
    return (calculated_crc == packet->crc);
}

void build_packet(motor_packet_t *packet, uint8_t command, const uint8_t *data, uint8_t length) {
    packet->start_byte = 0xAA;
    packet->command = command;
    packet->length = (length > 16) ? 16 : length;
    memcpy(packet->data, data, packet->length);
    packet->crc = calculate_crc((const uint8_t*)packet, sizeof(motor_packet_t) - 1);
}

void send_packet(const motor_packet_t *packet) {
    const uint8_t *ptr = (const uint8_t*)packet;
    for (uint8_t i = 0; i < sizeof(motor_packet_t); i++) {
        uart_putc(ptr[i]);
    }
}

uint8_t receive_packet(motor_packet_t *packet) {
    // Wait for start byte
    while (uart_getc() != 0xAA);
    
    // Read remaining packet
    uint8_t *ptr = (uint8_t*)packet;
    ptr[0] = 0xAA; // Already got start byte
    
    for (uint8_t i = 1; i < sizeof(motor_packet_t); i++) {
        ptr[i] = uart_getc();
    }
    
    return validate_packet(packet);
}