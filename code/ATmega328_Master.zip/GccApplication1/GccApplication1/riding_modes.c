/**
 * @file riding_modes.c
 * @brief Riding mode implementation
 * @version 2.0.4
 * @date 2023-11-21
 */
#include "riding_modes.h"
#include "eeprom_manager.h"

// Define the global variable
riding_mode_t current_mode;

static const mode_config_t mode_configs[NUM_RIDING_MODES] = {
    [MODE_ECO]    = {.max_speed = 25, .power_limit = 50, .regen_level = 3},
    [MODE_NORMAL] = {.max_speed = 35, .power_limit = 75, .regen_level = 2},
    [MODE_SPORT]  = {.max_speed = 45, .power_limit = 100, .regen_level = 1}
};

void riding_modes_init(void) {
    current_mode = em_read_byte(EEPROM_MODE_ADDR);
    if(current_mode >= NUM_RIDING_MODES) {
        current_mode = MODE_NORMAL;
    }
}

void riding_modes_set(riding_mode_t mode) {
    if(mode < NUM_RIDING_MODES) {
        current_mode = mode;
        em_write_byte(EEPROM_MODE_ADDR, mode);
    }
}

riding_mode_t riding_modes_get(void) {
    return current_mode;
}

const mode_config_t* riding_modes_get_config(void) {
    return &mode_configs[current_mode];
}