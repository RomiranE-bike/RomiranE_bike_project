/**
  * @file system_monitor.c
  * @brief System health monitoring
  * @version 2.0.1
  * @date 2023-11-20
  */

#include "system_monitor.h"
#include "battery_monitor.h"
#include "led.h"
#include "buzzer.h"

static uint8_t system_errors = 0;

void system_monitor_update(void) {
    battery_status_t batt = battery_get_status();
    
    // Check for faults
    system_errors = 0;
    
    if(batt.voltage > CELL_VOLTAGE_MAX * BATTERY_CELLS * 1.05f) {
        system_errors |= SYS_ERR_OVERVOLTAGE;
    }
    
    if(batt.voltage < CELL_VOLTAGE_MIN * BATTERY_CELLS) {
        system_errors |= SYS_ERR_UNDERVOLTAGE;
    }
    
    if(batt.temp > 60) {
        system_errors |= SYS_ERR_OVERTEMP;
    }
    
    // Update indicators
    if(system_errors) {
        led_set_mode(LED_BLINK_ERROR);
        buzzer_set_mode(BUZZER_ERROR);
    }
}

uint8_t system_get_errors(void) {
    return system_errors;
}