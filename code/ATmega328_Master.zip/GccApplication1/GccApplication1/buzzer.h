/**
 * @file buzzer.h
 * @brief Audible feedback system
 * @version 2.0.1
 * @date 2023-11-20
 */
#ifndef BUZZER_H
#define BUZZER_H

typedef enum {
    BUZZER_OFF,
    BUZZER_SHORT_BEEP,
    BUZZER_LONG_BEEP,
    BUZZER_ERROR,
    BUZZER_STARTUP
} buzzer_mode_t;

void buzzer_init(void);
void buzzer_set_mode(buzzer_mode_t mode);
void buzzer_update(void);

#endif // BUZZER_H