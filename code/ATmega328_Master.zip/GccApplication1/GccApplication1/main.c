/**
 * @file main.c
 * @brief Main application entry point
 * @version 2.0.1
 * @date 2023-11-20
 */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>


#include "system_init.h"
//#include "state_machine.h"
#include "config.h"
#include "i2c_lcd.h"
#include "buttons.h"
#include "hal.h"

int main(void) {
    // Initialize hardware
	hal_init();
    system_init();
    lcd_init(I2C_ADDRESS);
    buttons_init();
    
    // Show startup message
    lcd_print_at(0, 0, "eBike Controller");
    lcd_print_at(0, 1, "v2.0.1 Starting...");
    _delay_ms(1000);
    lcd_clear();
    
    // Main loop
    while (1) {
        state_machine_update();
        
        // Handle button inputs
        button_t btn = buttons_get_pressed();
        if (btn != BUTTON_NONE) {
            // Handle button press
        }
        if (btn != BUTTON_NONE) {
	        // Example: switch riding mode
	        lcd_print_at(0, 1, "Button Pressed!");
        }
        // Other periodic tasks...
    }
    
    return 0;
}