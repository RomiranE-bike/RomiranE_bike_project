/**
 * @file buttons.c
 * @brief Button debouncing and handling
 * @version 2.0.1
 * @date 2023-11-20
 */

#include "buttons.h"
#include "config.h"
#include <util/delay.h>

static uint8_t button_states[4] = {0};
static uint16_t hold_timers[4] = {0};

void buttons_init(void) {
    // Inputs are configured in system_init
}

button_t buttons_get_pressed(void) {
    static uint8_t last_states[4] = {0};
    static uint8_t debounce_counters[4] = {0};
    
    button_t pressed = BUTTON_NONE;
    
    for (uint8_t i = 0; i < 4; i++) {
        uint8_t current_state = (PINC & (1 << i)) == 0; // Active low
        
        if (current_state != last_states[i]) {
            debounce_counters[i] = 0;
            last_states[i] = current_state;
        } else {
            if (debounce_counters[i] < 10) {
                debounce_counters[i]++;
                if (debounce_counters[i] == 10) {
                    button_states[i] = current_state;
                    if (current_state) {
                        pressed = (button_t)i;
                    }
                }
            }
        }
        
        if (button_states[i]) {
            hold_timers[i]++;
        } else {
            hold_timers[i] = 0;
        }
    }
    
    return pressed;
}

uint8_t buttons_get_held_time(button_t button) {
    if (button >= BUTTON_MODE && button <= BUTTON_DOWN) {
        return hold_timers[button] / 10; // Return in 100ms units
    }
    return 0;
}