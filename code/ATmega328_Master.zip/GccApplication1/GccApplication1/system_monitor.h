/**
 * @file system_monitor.h
 * @brief System health monitoring and fault detection
 * @version 2.0.1
 * @date 2023-11-20
 */

#ifndef SYSTEM_MONITOR_H
#define SYSTEM_MONITOR_H

#include <stdint.h>

// System error flags
#define SYS_ERR_OVERVOLTAGE    (1 << 0)
#define SYS_ERR_UNDERVOLTAGE   (1 << 1)
#define SYS_ERR_OVERCURRENT    (1 << 2)
#define SYS_ERR_OVERTEMP       (1 << 3)
#define SYS_ERR_COMM_FAILURE   (1 << 4)
#define SYS_ERR_MOTOR_FAULT    (1 << 5)

/**
 * @brief Initialize system monitoring
 */
void system_monitor_init(void);

/**
 * @brief Update system monitoring (call periodically)
 */
void system_monitor_update(void);

/**
 * @brief Get current system error flags
 * @return Bitmask of active errors (see SYS_ERR_* defines)
 */
uint8_t system_get_errors(void);

/**
 * @brief Check if system is in fault state
 * @return 1 if any critical faults detected, 0 otherwise
 */
uint8_t system_in_fault(void);

#endif // SYSTEM_MONITOR_H