/**
 * @file hal.h
 * @brief Hardware Abstraction Layer
 * @version 2.0.1
 * @date 2023-11-21
 */
#ifndef HAL_H
#define HAL_H

#include <stdint.h>

// System tick functions
void hal_init(void);
uint32_t HAL_GetTick(void);

// Delay functions (blocking)
void HAL_Delay(uint32_t ms);

// GPIO functions
typedef enum {
    GPIO_PIN_RESET = 0,
    GPIO_PIN_SET
} GPIO_PinState;

void HAL_GPIO_WritePin(uint8_t port, uint8_t pin, GPIO_PinState state);
GPIO_PinState HAL_GPIO_ReadPin(uint8_t port, uint8_t pin);

#endif // HAL_H