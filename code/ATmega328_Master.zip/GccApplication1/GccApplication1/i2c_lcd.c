/**
 * @file i2c_lcd.c
 * @brief I2C LCD implementation
 * @version 2.0.1
 * @date 2023-11-20
 */

#include "i2c_lcd.h"
#include "config.h"
#include <util/delay.h>

// Private function prototypes
static void i2c_init(void);
static void i2c_start(void);
static void i2c_stop(void);
static void i2c_write(uint8_t data);
static void lcd_write_nibble(uint8_t nibble, uint8_t rs);
static void lcd_pulse_enable(uint8_t data);

static uint8_t lcd_address;
static uint8_t lcd_backlight_state = LCD_BACKLIGHT;

void lcd_init(uint8_t address) {
    lcd_address = address;
    i2c_init();
    
    // Initialize LCD in 4-bit mode
    _delay_ms(50);
    lcd_write_nibble(0x03 << 4, 0);
    _delay_ms(5);
    lcd_write_nibble(0x03 << 4, 0);
    _delay_us(100);
    lcd_write_nibble(0x03 << 4, 0);
    _delay_us(100);
    lcd_write_nibble(0x02 << 4, 0); // 4-bit mode
    
    // Set 4-bit mode, 2 lines, 5x8 font
    lcd_send_command(LCD_FUNCTION_SET | LCD_4BIT_MODE | LCD_2LINE | LCD_5x8DOTS);
    
    // Turn display on, cursor off, blink off
    lcd_send_command(LCD_DISPLAY_CONTROL | LCD_DISPLAY_ON | LCD_CURSOR_OFF | LCD_BLINK_OFF);
    
    // Clear display
    lcd_clear();
    
    // Set entry mode
    lcd_send_command(LCD_ENTRY_MODE_SET | LCD_ENTRY_LEFT);
}

void lcd_send_command(uint8_t cmd) {
    lcd_write_nibble(cmd & 0xF0, 0);
    lcd_write_nibble((cmd << 4) & 0xF0, 0);
}

void lcd_send_data(uint8_t data) {
    lcd_write_nibble(data & 0xF0, 1);
    lcd_write_nibble((data << 4) & 0xF0, 1);
}

void lcd_clear(void) {
    lcd_send_command(LCD_CLEAR_DISPLAY);
    _delay_ms(2);
}

void lcd_set_cursor(uint8_t col, uint8_t row) {
    uint8_t row_offsets[] = {0x00, 0x40, 0x14, 0x54};
    lcd_send_command(LCD_SET_DDRAM_ADDR | (col + row_offsets[row]));
}

void lcd_print(const char *str) {
    while (*str) {
        lcd_send_data(*str++);
    }
}

void lcd_print_at(uint8_t col, uint8_t row, const char *str) {
    lcd_set_cursor(col, row);
    lcd_print(str);
}

void lcd_backlight(uint8_t state) {
    lcd_backlight_state = state ? LCD_BACKLIGHT : LCD_NOBACKLIGHT;
    i2c_start();
    i2c_write(lcd_address << 1);
    i2c_write(lcd_backlight_state);
    i2c_stop();
}

// Private functions
static void i2c_init(void) {
    TWSR = 0x00; // Prescaler 1
    TWBR = ((F_CPU / I2C_BAUDRATE) - 16) / 2;
    TWCR = (1 << TWEN);
}

static void i2c_start(void) {
    TWCR = (1 << TWINT) | (1 << TWSTA) | (1 << TWEN);
    while (!(TWCR & (1 << TWINT)));
}

static void i2c_stop(void) {
    TWCR = (1 << TWINT) | (1 << TWSTO) | (1 << TWEN);
}

static void i2c_write(uint8_t data) {
    TWDR = data;
    TWCR = (1 << TWINT) | (1 << TWEN);
    while (!(TWCR & (1 << TWINT)));
}

static void lcd_write_nibble(uint8_t nibble, uint8_t rs) {
    uint8_t data = nibble | (rs ? 0x01 : 0x00) | lcd_backlight_state;
    i2c_start();
    i2c_write(lcd_address << 1);
    i2c_write(data | 0x04); // Enable high
    i2c_write(data & ~0x04); // Enable low
    i2c_stop();
}

static void lcd_pulse_enable(uint8_t data) {
    i2c_write(data | 0x04); // Enable high
    _delay_us(1);
    i2c_write(data & ~0x04); // Enable low
    _delay_us(50);
}