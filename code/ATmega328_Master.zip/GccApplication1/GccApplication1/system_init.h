/**
 * @file system_init.h
 * @brief System initialization routines
 * @version 2.0.1
 * @date 2023-11-20
 */

#ifndef SYSTEM_INIT_H
#define SYSTEM_INIT_H

#include <stdint.h>

/**
 * @brief Initialize all system peripherals
 */
void system_init(void);

/**
 * @brief Initialize GPIO pins
 */
void gpio_init(void);

/**
 * @brief Initialize UART communication
 */
void uart_init(void);

/**
 * @brief Initialize I2C interface
 */
void i2c_init(void);

/**
 * @brief Initialize system timers
 */
void timer_init(void);

#endif // SYSTEM_INIT_H