/**
 * @file helpers.c
 * @brief Utility functions
 * @version 2.0.1
 * @date 2023-11-20
 */
#include "helpers.h"
#include <string.h>

uint8_t calculate_crc8(const uint8_t *data, uint8_t length) {
    uint8_t crc = 0;
    for(uint8_t i = 0; i < length; i++) {
        crc ^= data[i];
        for(uint8_t j = 0; j < 8; j++) {
            if(crc & 0x80) crc = (crc << 1) ^ 0x07;
            else crc <<= 1;
        }
    }
    return crc;
}

float map_range(float x, float in_min, float in_max, float out_min, float out_max) {
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

void delay_ms(uint16_t ms) {
    while(ms--) _delay_ms(1);
}

uint8_t constrain_uint8(uint8_t value, uint8_t min, uint8_t max) {
    if(value < min) return min;
    if(value > max) return max;
    return value;
}