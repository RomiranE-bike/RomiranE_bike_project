/**
 * @file buzzer.c
 * @brief Buzzer sound patterns
 * @version 2.0.1
 * @date 2023-11-20
 */
#include "buzzer.h"
#include "config.h"
#include <avr/io.h>

static buzzer_mode_t current_mode = BUZZER_OFF;
static uint16_t beep_timer = 0;
static const uint8_t melody[] = {1,0,1,0,1,0,0,0,1,1,0,0};
static uint8_t note = 0;

void buzzer_init(void) {
    DDRB |= (1 << BUZZER_PIN);
    PORTB &= ~(1 << BUZZER_PIN);
}

void buzzer_set_mode(buzzer_mode_t mode) {
    current_mode = mode;
    beep_timer = 0;
}

void buzzer_update(void) {
    static uint8_t beep_state = 0;
    
    switch(current_mode) {
        case BUZZER_OFF:
            PORTB &= ~(1 << BUZZER_PIN);
            break;
            
        case BUZZER_SHORT_BEEP:
            if(beep_timer == 0) {
                PORTB |= (1 << BUZZER_PIN);
                beep_state = 1;
            }
            if(++beep_timer >= 50) {
                PORTB &= ~(1 << BUZZER_PIN);
                current_mode = BUZZER_OFF;
            }
            break;
            
        case BUZZER_LONG_BEEP:
            if(beep_timer == 0) {
                PORTB |= (1 << BUZZER_PIN);
                beep_state = 1;
            }
            if(++beep_timer >= 200) {
                PORTB &= ~(1 << BUZZER_PIN);
                current_mode = BUZZER_OFF;
            }
            break;
            
        case BUZZER_ERROR:
            if(++beep_timer >= 300) beep_timer = 0;
            if(beep_timer % 100 < 50) PORTB |= (1 << BUZZER_PIN);
            else PORTB &= ~(1 << BUZZER_PIN);
            break;
            
        case BUZZER_STARTUP:
            // Startup melody pattern
            
            
            if(++beep_timer >= 50) {
                beep_timer = 0;
                if(melody[note]) PORTB ^= (1 << BUZZER_PIN);
                if(++note >= sizeof(melody)) {
                    current_mode = BUZZER_OFF;
                    PORTB &= ~(1 << BUZZER_PIN);
                }
            }
            break;
    }
}