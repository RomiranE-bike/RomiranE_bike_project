/**
 * @file riding_modes.h
 * @brief Riding mode configurations
 * @version 2.0.4
 * @date 2023-11-21
 */
#ifndef RIDING_MODES_H
#define RIDING_MODES_H

#include <stdint.h>
#include "config.h"

typedef enum {
    MODE_ECO,
    MODE_NORMAL,
    MODE_SPORT,
    NUM_RIDING_MODES
} riding_mode_t;

typedef struct {
    uint8_t max_speed;
    uint8_t power_limit;
    uint8_t regen_level;
} mode_config_t;

// Declare extern variable
extern riding_mode_t current_mode;

// Function prototypes
void riding_modes_init(void);
void riding_modes_set(riding_mode_t mode);
riding_mode_t riding_modes_get(void);
const mode_config_t* riding_modes_get_config(void);

#endif // RIDING_MODES_H