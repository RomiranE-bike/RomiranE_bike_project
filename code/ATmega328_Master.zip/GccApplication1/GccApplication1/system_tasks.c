/**
  * @file system_tasks.c
  * @brief Periodic system tasks
  * @version 2.0.1
  * @date 2023-11-20
  */
  
#include "system_tasks.h"
#include "i2c_lcd.h"
#include "led.h"
#include "buzzer.h"
#include "battery_monitor.h"

static uint32_t task_counters[NUM_TASKS] = {0};

void system_tasks_init(void) {
    // Initialize all task counters
    for(uint8_t i = 0; i < NUM_TASKS; i++) {
        task_counters[i] = 0;
    }
}

void system_tasks_run(void) {
    // 10ms tasks
    if(task_counters[TASK_10MS] >= 10) {
        task_counters[TASK_10MS] = 0;
        led_update();
        buzzer_update();
    }
    
    // 100ms tasks
    if(task_counters[TASK_100MS] >= 100) {
        task_counters[TASK_100MS] = 0;
        battery_status_t batt = battery_get_status();
        
        // Update LCD with battery info
        char batt_str[16];
        snprintf(batt_str, sizeof(batt_str), "Batt:%dV %d%%", 
            (uint16_t)batt.voltage, batt.soc);
        lcd_print_at(0, 1, batt_str);
    }
    
    // 1s tasks
    if(task_counters[TASK_1S] >= 1000) {
        task_counters[TASK_1S] = 0;
        // System health monitoring
        if(battery_is_critical()) {
            led_set_mode(LED_BLINK_ERROR);
            buzzer_set_mode(BUZZER_ERROR);
        }
    }
    
    // Increment all counters
    for(uint8_t i = 0; i < NUM_TASKS; i++) {
        task_counters[i]++;
    }
}