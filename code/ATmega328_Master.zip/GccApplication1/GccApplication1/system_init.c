/**
 * @file system_init.c
 * @brief System initialization implementation
 * @version 2.0.1
 * @date 2023-11-20
 */

#include "system_init.h"
#include "config.h"
#include <avr/io.h>
#include <avr/interrupt.h>

#include <util/delay.h>  // Must come after F_CPU definition

// Ensure F_CPU is defined BEFORE including delay.h
#define F_CPU 16000000UL  // Match your clock speed

void system_init(void) {
    // Disable interrupts during initialization
    cli();
    
    gpio_init();
    uart_init();
    i2c_init();
    timer_init();
    
    // Enable global interrupts
    sei();
}

void gpio_init(void) {
    // Button inputs (pull-up enabled)
    DDRC &= ~((1 << BUTTON_MODE_PIN) | (1 << BUTTON_SET_PIN) | 
              (1 << BUTTON_UP_PIN) | (1 << BUTTON_DOWN_PIN));
    PORTC |= (1 << BUTTON_MODE_PIN) | (1 << BUTTON_SET_PIN) | 
             (1 << BUTTON_UP_PIN) | (1 << BUTTON_DOWN_PIN);
    
    // LED and buzzer outputs
    DDRB |= (1 << LED_STATUS_PIN) | (1 << BUZZER_PIN);
    PORTB &= ~((1 << LED_STATUS_PIN) | (1 << BUZZER_PIN));
}

void uart_init(void) {
    UBRR0H = (F_CPU / (16UL * UART_BAUDRATE) - 1) >> 8;
    UBRR0L = (F_CPU / (16UL * UART_BAUDRATE) - 1);
    
    UCSR0B = (1 << RXEN0) | (1 << TXEN0);
    UCSR0C = (1 << UCSZ01) | (1 << UCSZ00); // 8-bit data
}

void i2c_init(void) {
    TWSR = 0x00; // Prescaler 1
    TWBR = ((F_CPU / I2C_BAUDRATE) - 16) / 2;
    TWCR = (1 << TWEN);
}

void timer_init(void) {
    // Timer0 for system ticks (1ms)
    TCCR0A = (1 << WGM01); // CTC mode
    TCCR0B = (1 << CS01) | (1 << CS00); // 64 prescaler
    OCR0A = 249; // 1ms interrupt
    TIMSK0 = (1 << OCIE0A);
}