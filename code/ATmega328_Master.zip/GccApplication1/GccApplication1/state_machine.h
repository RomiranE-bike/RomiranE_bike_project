/**
 * @file state_machine.h
 * @brief System state controller
 * @version 2.0.1
 * @date 2023-11-20
 */

#ifndef STATE_MACHINE_H
#define STATE_MACHINE_H

typedef enum {
    SYSTEM_STATE_INIT,
    SYSTEM_STATE_IDLE,
    SYSTEM_STATE_READY,
    SYSTEM_STATE_RUNNING,
    SYSTEM_STATE_FAULT,
    SYSTEM_STATE_SHUTDOWN
} system_state_t;

void state_machine_init(void);
void state_machine_update(void);
system_state_t state_machine_get_state(void);
const char* state_machine_get_state_name(void);

#endif // STATE_MACHINE_H