/**
 * @file state_machine.c
 * @brief State machine implementation
 * @version 2.0.1
 * @date 2023-11-20
 */

#include "state_machine.h"
#include "i2c_lcd.h"
#include "protocol.h"
#include "uart.h"
#include "system_status.h"
#include "hal.h"

static system_state_t current_state = SYSTEM_STATE_INIT;

void state_machine_init(void) {
    current_state = SYSTEM_STATE_INIT;
}

void state_machine_update(void) {
    
    static uint32_t last_tick = 0;
    uint32_t current_tick = HAL_GetTick();
	
    switch (current_state) {
        case SYSTEM_STATE_INIT:
            // Initialize hardware
            if (system_init_complete()) {
                current_state = SYSTEM_STATE_IDLE;
            }
            break;
            
        case SYSTEM_STATE_IDLE:
            // Wait for user input
            if (user_input_detected()) {
                current_state = SYSTEM_STATE_READY;
            }
            break;
            
        case SYSTEM_STATE_READY:
            // Check all systems ready
            if (all_systems_ready()) {
                current_state = SYSTEM_STATE_RUNNING;
            }
            break;
            
        case SYSTEM_STATE_RUNNING:
            // Monitor for faults
            if (fault_detected()) {
                current_state = SYSTEM_STATE_FAULT;
            }
            break;
            
        case SYSTEM_STATE_FAULT:
            // Requires manual reset
            break;
            
        case SYSTEM_STATE_SHUTDOWN:
            // Power down sequence
            break;
    }
    
    
    // Update display every 100ms
    if(current_tick - last_tick > 100) {
	    update_display();
	    last_tick = current_tick;
    }
}

system_state_t state_machine_get_state(void) {
    return current_state;
}

const char* state_machine_get_state_name(void) {
    static const char* names[] = {
        "INIT",
        "IDLE",
        "READY",
        "RUNNING",
        "FAULT",
        "SHUTDOWN"
    };
    return names[current_state];
}