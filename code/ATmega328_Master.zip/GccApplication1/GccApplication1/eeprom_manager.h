/**
 * @file eeprom_manager.h
 * @brief Safe EEPROM access with range checking
 * @version 2.0.2
 * @date 2023-11-21
 */
#ifndef EEPROM_MANAGER_H
#define EEPROM_MANAGER_H

#include <stdint.h>

#ifdef __AVR__
#include <avr/eeprom.h>
#include <avr/io.h>
// AVR-specific EEPROM size definition
#define EEPROM_SIZE E2END + 1
#else
// Mock definitions for non-AVR testing
#define EEPROM_SIZE 1024
extern uint8_t mock_eeprom[EEPROM_SIZE];
#endif

// Safe wrappers for AVR EEPROM
uint8_t  em_read_byte(uint16_t addr);
void     em_write_byte(uint16_t addr, uint8_t data);
uint16_t em_read_word(uint16_t addr);
void     em_write_word(uint16_t addr, uint16_t data);
void     em_update_block(const void *src, void *dst, uint16_t size);
void     em_read_block(void *dst, const void *src, uint16_t size);

// Custom functions
void     em_erase_all(void);
uint8_t  em_verify_pattern(uint16_t start, uint8_t pattern, uint16_t len);

#endif // EEPROM_MANAGER_H