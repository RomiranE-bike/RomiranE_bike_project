/**
 * @file helpers.h
 * @brief Utility functions for eBike controller
 * @version 2.0.1
 * @date 2023-11-20
 */

#ifndef HELPERS_H
#define HELPERS_H

#include <stdint.h>

// Math Utilities
#define PI 3.14159265358979323846f
#define RAD_TO_DEG (180.0f / PI)
#define DEG_TO_RAD (PI / 180.0f)

/**
 * @brief Constrain a value between min and max
 * @param value Input value
 * @param min Minimum allowed value
 * @param max Maximum allowed value
 * @return Constrained value
 */
float constrain(float value, float min, float max);

/**
 * @brief Map a value from one range to another
 * @param x Input value
 * @param in_min Input range minimum
 * @param in_max Input range maximum
 * @param out_min Output range minimum
 * @param out_max Output range maximum
 * @return Mapped value
 */
float map_range(float x, float in_min, float in_max, float out_min, float out_max);

/**
 * @brief Calculate CRC-8 checksum
 * @param data Pointer to data buffer
 * @param len Data length
 * @return CRC-8 value
 */
uint8_t calculate_crc8(const uint8_t *data, uint8_t len);

/**
 * @brief Simple moving average filter
 * @param new_value New sample value
 * @param window_size Number of samples in window (max 16)
 * @return Filtered value
 */
float moving_average(float new_value, uint8_t window_size);

/**
 * @brief Convert RPM to rad/s
 * @param rpm Revolutions per minute
 * @return Radians per second
 */
float rpm_to_rads(float rpm);

/**
 * @brief Safe division (returns 0 if denominator is 0)
 */
float safe_divide(float numerator, float denominator);

#endif // HELPERS_H