/**
 * @file buttons.h
 * @brief Button input handling
 * @version 2.0.1
 * @date 2023-11-20
 */

#ifndef BUTTONS_H
#define BUTTONS_H

#include <stdint.h>

typedef enum {
    BUTTON_MODE,
    BUTTON_SET,
    BUTTON_UP,
    BUTTON_DOWN,
    BUTTON_NONE
} button_t;

void buttons_init(void);
button_t buttons_get_pressed(void);
uint8_t buttons_get_held_time(button_t button);

#endif // BUTTONS_H