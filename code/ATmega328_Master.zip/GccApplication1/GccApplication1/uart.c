/**
 * @file uart.c
 * @brief UART driver implementation
 * @version 2.0.3
 * @date 2023-11-21
 */
#include "uart.h"
#include "config.h"  // Add this line at the top
#include <avr/interrupt.h>

static volatile char rx_buffer[UART_RX_BUFFER_SIZE];
static volatile uint8_t rx_head = 0;
static volatile uint8_t rx_tail = 0;

static volatile char tx_buffer[UART_TX_BUFFER_SIZE];
static volatile uint8_t tx_head = 0;
static volatile uint8_t tx_tail = 0;


void uart_init(void) {
    // Calculate baud rate (now uses defined constants)
    uint16_t ubrr = (F_CPU / (16UL * UART_BAUDRATE)) - 1;
    UBRR0H = (ubrr >> 8);
    UBRR0L = ubrr;
    // Enable receiver, transmitter and RX interrupt
    UCSR0B = (1 << RXEN0) | (1 << TXEN0) | (1 << RXCIE0);
    
    // 8-bit data, no parity, 1 stop bit
    UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);
}

void uart_putc(char c) {
    uint8_t next_head = (tx_head + 1) % UART_TX_BUFFER_SIZE;
    
    while (next_head == tx_tail); // Wait for space in buffer
    
    tx_buffer[tx_head] = c;
    tx_head = next_head;
    
    // Enable TX interrupt if not already enabled
    UCSR0B |= (1 << UDRIE0);
}

void uart_puts(const char *str) {
    while (*str) {
        uart_putc(*str++);
    }
}

char uart_getc(void) {
    while (rx_head == rx_tail); // Wait for data
    char c = rx_buffer[rx_tail];
    rx_tail = (rx_tail + 1) % UART_RX_BUFFER_SIZE;
    return c;
}

uint8_t uart_available(void) {
    return (rx_head >= rx_tail) ? (rx_head - rx_tail) : (UART_RX_BUFFER_SIZE - (rx_tail - rx_head));
}

void uart_flush(void) {
    rx_head = rx_tail = 0;
    tx_head = tx_tail = 0;
}

ISR(USART_RX_vect) {
    uint8_t next_head = (rx_head + 1) % UART_RX_BUFFER_SIZE;
    if (next_head != rx_tail) {
        rx_buffer[rx_head] = UDR0;
        rx_head = next_head;
    }
}

ISR(USART_UDRE_vect) {
    if (tx_head == tx_tail) {
        UCSR0B &= ~(1 << UDRIE0); // Disable interrupt
    } else {
        UDR0 = tx_buffer[tx_tail];
        tx_tail = (tx_tail + 1) % UART_TX_BUFFER_SIZE;
    }
}