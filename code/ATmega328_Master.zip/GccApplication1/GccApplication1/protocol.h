/**
 * @file protocol.h
 * @brief Communication protocol definition
 * @version 2.0.1
 * @date 2023-11-20
 */

#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <stdint.h>

// Packet structure
#pragma pack(push, 1)
typedef struct {
    uint8_t start_byte;    // 0xAA
    uint8_t command;       // Command byte
    uint8_t length;        // Data length
    uint8_t data[16];      // Payload
    uint8_t crc;           // CRC-8 checksum
} motor_packet_t;
#pragma pack(pop)

// Command definitions
#define CMD_SET_SPEED      0x01
#define CMD_SET_MODE       0x02
#define CMD_GET_STATUS     0x03
#define CMD_FAULT_REPORT   0x04
#define CMD_ACK            0x05
#define CMD_NACK           0x06

// Response codes
#define RESP_SUCCESS       0x00
#define RESP_INVALID_CMD   0x01
#define RESP_CRC_ERROR    0x02
#define RESP_LENGTH_ERROR 0x03

uint8_t calculate_crc(const uint8_t *data, uint8_t length);
uint8_t validate_packet(const motor_packet_t *packet);
void build_packet(motor_packet_t *packet, uint8_t command, const uint8_t *data, uint8_t length);
void send_packet(const motor_packet_t *packet);
uint8_t receive_packet(motor_packet_t *packet);

#endif // PROTOCOL_H