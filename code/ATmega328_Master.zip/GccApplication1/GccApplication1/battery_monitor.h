/**
  * @file battery_monitor.h
  * @brief Battery management system
  * @version 2.0.1
  * @date 2023-11-20
  */
  
#ifndef BATTERY_MONITOR_H
#define BATTERY_MONITOR_H

#include <stdint.h>

#define BATTERY_CELLS     13
#define CELL_VOLTAGE_MAX  4.2f
#define CELL_VOLTAGE_MIN  3.0f

typedef struct {
    float voltage;
    float current;
    uint8_t soc; // State of Charge (%)
    int8_t temp;
} battery_status_t;

void battery_monitor_init(void);
battery_status_t battery_get_status(void);
uint8_t battery_is_low(void);
uint8_t battery_is_critical(void);

#endif // BATTERY_MONITOR_H