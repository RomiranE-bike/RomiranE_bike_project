/**
 * @file config.h
 * @brief Hardware configuration
 * @version 2.0.3
 * @date 2023-11-21
 */

#ifndef CONFIG_H
#define CONFIG_H

#include <avr/io.h>
#include <stdint.h>

// EEPROM Addresses
#define EEPROM_MODE_ADDR     0x00  // 1 byte for riding mode
#define EEPROM_MAX_SPEED_ADDR 0x01 // 2 bytes for max speed

// System clock frequency
#define F_CPU 16000000UL

// I2C Configuration
#define I2C_ADDRESS 0x27 // Default PCF8574 address
#define I2C_BAUDRATE 100000 // 100kHz
#define SDA_PIN PC4
#define SCL_PIN PC5

// UART Configuration
#define UART_BAUDRATE 115200
#define UART_RX_BUFFER_SIZE 64
#define UART_TX_BUFFER_SIZE 64

// Pin Definitions
#define BUTTON_MODE_PIN   PC0
#define BUTTON_SET_PIN    PC1
#define BUTTON_UP_PIN     PC2
#define BUTTON_DOWN_PIN   PC3

#define LED_STATUS_PIN    PB0
#define BUZZER_PIN       PB1

// EEPROM Addresses
#define EEPROM_MODE_ADDR     0x00
#define EEPROM_MAX_SPEED_ADDR 0x01

// System Parameters
#define MAX_SPEED_KPH        45
#define MIN_SPEED_KPH        10
#define SPEED_STEP           5

#endif // CONFIG_H