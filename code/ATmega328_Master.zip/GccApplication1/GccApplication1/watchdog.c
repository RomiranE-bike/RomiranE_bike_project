/**
 * @file watchdog.c
 * @brief Watchdog implementation
 * @version 2.0.2
 * @date 2023-11-21
 */
#include "watchdog.h"
#include <avr/wdt.h>

// Undefine conflicting macro from avr/wdt.h
#undef wdt_reset

void wdt_init(uint8_t timeout_s) {
    uint8_t wdt_timeout;
    switch(timeout_s) {
        case 1:  wdt_timeout = WDTO_1S; break;
        case 2:  wdt_timeout = WDTO_2S; break;
        case 4:  wdt_timeout = WDTO_4S; break;
        case 8:  wdt_timeout = WDTO_8S; break;
        default: wdt_timeout = WDTO_2S;
    }
    wdt_enable(wdt_timeout);
}

// Renamed to avoid macro conflict
void wdt_restart(void) {
    wdt_reset(); // Now uses the AVR lib macro
}

void wdt_force_reset(void) {
    wdt_enable(WDTO_15MS);
    while(1);
}

