/**
 * @file throttle.h
 * @brief Throttle input handling
 * @version 2.0.2
 * @date 2023-11-21
 */

#ifndef THROTTLE_H  // <- Header guard start
#define THROTTLE_H

#include <stdint.h>

// Default ADC values (adjust during calibration)
#define THROTTLE_MIN_ADC     210     // 0% throttle position
#define THROTTLE_MAX_ADC     815     // 100% throttle position
#define THROTTLE_DEADZONE    20      // ADC units at lower end

/**
 * @brief Initialize throttle hardware
 */
void throttle_init(void);
/**
 * @brief Read raw throttle ADC value
 * @return 10-bit ADC reading (0-1023)
 */
uint16_t throttle_read_raw(void);

/**
 * @brief Get filtered throttle percentage
 * @return Throttle position (0-100%)
 */
uint8_t throttle_get_percent(void);

/**
 * @brief Start throttle calibration
 * @note Call throttle_save_calibration() after min/max positions are set
 */
void throttle_start_calibration(void);

/**
 * @brief Save calibration values to EEPROM
 */
void throttle_save_calibration(void);

#endif // THROTTLE_H  // <- Header guard end
