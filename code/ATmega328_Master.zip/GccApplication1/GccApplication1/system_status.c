// system_status.c
#include "system_status.h"
#include "buttons.h"
#include "watchdog.h"
#include "led.h"

bool system_init_complete(void) {
    // Check if all critical systems are initialized
    return led_test() && wdt_test(); 
}

bool user_input_detected(void) {
    return buttons_get_pressed() != BUTTON_NONE;
}

bool all_systems_ready(void) {
    return system_init_complete() && 
           !fault_detected();
}

bool fault_detected(void) {
    return led_get_fault() || wdt_get_fault();
}