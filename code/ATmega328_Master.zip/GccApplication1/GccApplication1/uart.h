/**
 * @file uart.h
 * @brief UART driver for master-slave communication
 * @version 2.0.1
 * @date 2023-11-20
 */

#ifndef UART_H
#define UART_H

#include <stdint.h>

#define UART_RX_BUFFER_SIZE 64
#define UART_TX_BUFFER_SIZE 64

void uart_init(void); // Declaration only
void uart_putc(char c);
void uart_puts(const char *str);
char uart_getc(void);
uint8_t uart_available(void);
void uart_flush(void);
void uart_isr_rx(void);
void uart_isr_tx(void);

#endif // UART_H