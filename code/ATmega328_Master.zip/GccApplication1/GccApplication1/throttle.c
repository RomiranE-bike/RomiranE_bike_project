/**
  * @file throttle.c
  * @brief Throttle input processing
  * @version 2.0.1
  * @date 2023-11-20
  */
  
#include "throttle.h"
#include "config.h"
#include "helpers.h"

#define THROTTLE_FILTER_ALPHA 0.1f

static float throttle_value = 0.0f;
static uint16_t throttle_raw = 0;

void throttle_init(void) {
    // Configure ADC for throttle input
    ADMUX = (1 << REFS0) | (1 << MUX1) | (1 << MUX0); // ADC7
    ADCSRA = (1 << ADEN) | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);
}

float throttle_get_value(void) {
    // Read ADC value
    ADCSRA |= (1 << ADSC);
    while(ADCSRA & (1 << ADSC));
    throttle_raw = ADC;
    
    // Apply low-pass filter
    float new_value = throttle_raw / 1023.0f;
    throttle_value += THROTTLE_FILTER_ALPHA * (new_value - throttle_value);
    
    // Apply deadzone and scaling
    if(throttle_value < 0.1f) return 0.0f;
    return constrain_float(throttle_value, 0.0f, 1.0f);
}

uint8_t throttle_is_active(void) {
    return throttle_value > 0.15f;
}