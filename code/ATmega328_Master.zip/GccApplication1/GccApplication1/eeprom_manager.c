/**
 * @file eeprom_manager.c
 * @brief Implementation with conflict-free EEPROM access
 * @version 2.0.1
 * @date 2023-11-20
 */
#include "eeprom_manager.h"
#include <string.h>

#ifdef __AVR__
// AVR-specific implementation
uint8_t em_read_byte(uint16_t addr) {
    return eeprom_read_byte((const uint8_t*)addr);
}

void em_write_byte(uint16_t addr, uint8_t data) {
    eeprom_write_byte((uint8_t*)addr, data);
}
#else
// Non-AVR test implementation
uint8_t mock_eeprom[EEPROM_SIZE];

uint8_t em_read_byte(uint16_t addr) {
    return (addr < EEPROM_SIZE) ? mock_eeprom[addr] : 0xFF;
}

void em_write_byte(uint16_t addr, uint8_t data) {
    if(addr < EEPROM_SIZE) mock_eeprom[addr] = data;
}
#endif

// Common functions
uint16_t em_read_word(uint16_t addr) {
    uint16_t value;
    em_read_block(&value, (const void*)addr, sizeof(value));
    return value;
}

void em_write_word(uint16_t addr, uint16_t data) {
    em_update_block(&data, (void*)addr, sizeof(data));
}

void em_update_block(const void *src, void *dst, uint16_t size) {
    #ifdef __AVR__
    eeprom_update_block(src, dst, size);
    #else
    if((uint16_t)dst + size <= EEPROM_SIZE) {
        memcpy(&mock_eeprom[(uint16_t)dst], src, size);
    }
    #endif
}

void em_read_block(void *dst, const void *src, uint16_t size) {
    #ifdef __AVR__
    eeprom_read_block(dst, src, size);
    #else
    memcpy(dst, &mock_eeprom[(uint16_t)src], size);
    #endif
}

void em_erase_all(void) {
    for(uint16_t i=0; i<EEPROM_SIZE; i++) {
        em_write_byte(i, 0xFF);
    }
}

uint8_t em_verify_pattern(uint16_t start, uint8_t pattern, uint16_t len) {
    for(uint16_t i=0; i<len; i++) {
        if(em_read_byte(start + i) != pattern) return 0;
    }
    return 1;
}