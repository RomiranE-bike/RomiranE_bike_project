/**
 * @file led.h
 * @brief Status LED control
 * @version 2.0.1
 * @date 2023-11-20
 */
#ifndef LED_H
#define LED_H

#include <stdint.h>

typedef enum {
    LED_OFF,
    LED_ON,
    LED_BLINK_SLOW,
    LED_BLINK_FAST,
    LED_BLINK_ERROR
} led_mode_t;

void led_init(void);
void led_set_mode(led_mode_t mode);
void led_update(void);

#endif // LED_H