/**
  * @file battery_monitor.c
  * @brief Battery monitoring implementation
  * @version 2.0.1
  * @date 2023-11-20
  */
  
#include "battery_monitor.h"
#include "config.h"
#include "helpers.h"
#include <avr/io.h>

static float battery_voltage = 0.0f;
static float battery_current = 0.0f;
static int8_t battery_temp = 25;

void battery_monitor_init(void) {
    // Configure ADC for battery monitoring
    ADMUX = (1 << REFS0); // AVCC reference
    ADCSRA = (1 << ADEN) | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);
}

battery_status_t battery_get_status(void) {
    // Read voltage (scaled from voltage divider)
    ADMUX = (1 << REFS0) | (1 << MUX2) | (1 << MUX0); // ADC5
    ADCSRA |= (1 << ADSC);
    while(ADCSRA & (1 << ADSC));
    uint16_t adc_value = ADC;
    battery_voltage = adc_value * (5.0f / 1023.0f) * 4.0f; // Scaling for 48V system
    
    // Read current (from current sensor)
    ADMUX = (1 << REFS0) | (1 << MUX1); // ADC2
    ADCSRA |= (1 << ADSC);
    while(ADCSRA & (1 << ADSC));
    adc_value = ADC;
    battery_current = (adc_value * (5.0f / 1023.0f) - 2.5f) / 0.1f; // 100mV/A sensor
    
    // Simple SOC estimation
    uint8_t soc = (uint8_t)constrain_uint8(
        (battery_voltage - (CELL_VOLTAGE_MIN * BATTERY_CELLS)) / 
        ((CELL_VOLTAGE_MAX - CELL_VOLTAGE_MIN) * BATTERY_CELLS) * 100,
        0, 100
    );
    
    return (battery_status_t){
        .voltage = battery_voltage,
        .current = battery_current,
        .soc = soc,
        .temp = battery_temp
    };
}

uint8_t battery_is_low(void) {
    return battery_voltage < (CELL_VOLTAGE_MIN * BATTERY_CELLS * 1.05f);
}

uint8_t battery_is_critical(void) {
    return battery_voltage < (CELL_VOLTAGE_MIN * BATTERY_CELLS * 1.02f);
}