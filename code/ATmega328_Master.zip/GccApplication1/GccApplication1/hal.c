/**
 * @file hal.c
 * @brief Hardware Abstraction Layer (AVR)
 * @version 2.0.1
 * @date 2023-11-21
 */
#include "hal.h"
#include <avr/io.h>
#include <avr/interrupt.h>

volatile uint32_t systick = 0;

// 1ms interrupt (Timer0)
ISR(TIMER0_COMPA_vect) {
    systick++;
}

void hal_init(void) {
    // Configure Timer0 for 1ms interrupts
    TCCR0A = (1 << WGM01); // CTC mode
    TCCR0B = (1 << CS01) | (1 << CS00); // 64 prescaler
    OCR0A = 249; // 1ms interval at 16MHz
    TIMSK0 = (1 << OCIE0A); // Enable interrupt
    sei(); // Enable global interrupts
}

uint32_t HAL_GetTick(void) {
    return systick;
}

void HAL_Delay(uint32_t ms) {
    uint32_t start = HAL_GetTick();
    while(HAL_GetTick() - start < ms);
}

// GPIO abstraction
void HAL_GPIO_WritePin(uint8_t port, uint8_t pin, GPIO_PinState state) {
    volatile uint8_t *reg = (port == 'B') ? &PORTB : 
                          (port == 'C') ? &PORTC : &PORTD;
    if(state == GPIO_PIN_SET) *reg |= (1 << pin);
    else *reg &= ~(1 << pin);
}

GPIO_PinState HAL_GPIO_ReadPin(uint8_t port, uint8_t pin) {
    volatile uint8_t *reg = (port == 'B') ? &PINB : 
                           (port == 'C') ? &PINC : &PIND;
    return (*reg & (1 << pin)) ? GPIO_PIN_SET : GPIO_PIN_RESET;
}