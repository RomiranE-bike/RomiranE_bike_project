/**
  * @file system_tasks.h
  * @brief Periodic task scheduler
  * @version 2.0.1
  * @date 2023-11-20
  */
  
#ifndef SYSTEM_TASKS_H
#define SYSTEM_TASKS_H

typedef enum {
    TASK_10MS,
    TASK_100MS,
    TASK_1S,
    NUM_TASKS
} system_task_t;

void system_tasks_init(void);
void system_tasks_run(void);

#endif // SYSTEM_TASKS_H