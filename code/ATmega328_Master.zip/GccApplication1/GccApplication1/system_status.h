// system_status.h
#ifndef SYSTEM_STATUS_H
#define SYSTEM_STATUS_H

#include <stdbool.h>

bool system_init_complete(void);
bool user_input_detected(void);
bool all_systems_ready(void);
bool fault_detected(void);

#endif