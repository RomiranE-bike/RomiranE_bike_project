/**
 * @file led.c
 * @brief LED controller implementation
 * @version 2.0.1
 * @date 2023-11-20
 */
#include "led.h"
#include "config.h"
#include <avr/io.h>

static led_mode_t current_mode = LED_OFF;
static uint16_t blink_timer = 0;
static uint8_t blink_state = 0;

void led_init(void) {
    DDRB |= (1 << LED_STATUS_PIN);
    PORTB &= ~(1 << LED_STATUS_PIN);
}

void led_set_mode(led_mode_t mode) {
    current_mode = mode;
    blink_timer = 0;
    blink_state = 0;
}

void led_update(void) {
    static uint8_t error_pattern[] = {1,0,1,0,0,0,0,0};
    static uint8_t error_index = 0;
    
    switch(current_mode) {
        case LED_OFF:
            PORTB &= ~(1 << LED_STATUS_PIN);
            break;
            
        case LED_ON:
            PORTB |= (1 << LED_STATUS_PIN);
            break;
            
        case LED_BLINK_SLOW:
            if(++blink_timer >= 500) {
                blink_timer = 0;
                blink_state ^= 1;
                if(blink_state) PORTB |= (1 << LED_STATUS_PIN);
                else PORTB &= ~(1 << LED_STATUS_PIN);
            }
            break;
            
        case LED_BLINK_FAST:
            if(++blink_timer >= 100) {
                blink_timer = 0;
                blink_state ^= 1;
                if(blink_state) PORTB |= (1 << LED_STATUS_PIN);
                else PORTB &= ~(1 << LED_STATUS_PIN);
            }
            break;
            
        case LED_BLINK_ERROR:
            if(++blink_timer >= 200) {
                blink_timer = 0;
                if(++error_index >= 8) error_index = 0;
                if(error_pattern[error_index]) PORTB |= (1 << LED_STATUS_PIN);
                else PORTB &= ~(1 << LED_STATUS_PIN);
            }
            break;
    }
}