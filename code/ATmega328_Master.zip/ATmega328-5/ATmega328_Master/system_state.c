/**
 * System State Manager Implementation v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 */
#include "config.h"
#include "system_state.h"
#include "eeprom.h"
#include "sensors.h"
#include "motor_control.h"
#include <string.h>

//------------------------------------------------------------------------------------
// Module Variables
//------------------------------------------------------------------------------------
SystemState_t system_state;
PowerManagement power_mgmt;

//------------------------------------------------------------------------------------
// Public Function Implementations
//------------------------------------------------------------------------------------

/**
 * @brief Initialize system state machine
 */
void SystemState_Init(void)
{
    memset(&system_state, 0, sizeof(SystemState_t));
    system_state.current_state = STATE_BOOT;
    
    // Initialize power management
    power_mgmt.mode = PROFILE_NORMAL;
    power_mgmt.current_scale = 1.0f;
    power_mgmt.temp_limit_derate = 100;
    
    // Load saved profile from EEPROM
    system_state.performance_mode = EEPROM_LoadProfile(PROFILE_MAGIC_NUMBER);
    if(system_state.performance_mode > PROFILE_BOOST) {
        system_state.performance_mode = PROFILE_NORMAL;
    }
}

/**
 * @brief Update system state machine
 */
void SystemState_Update(void)
{
    static uint32_t last_update = 0;
    uint32_t now = Get_SystemTick();
    
    // Run at 10Hz
    if(now - last_update < 100) return;
    last_update = now;
    
    // State transition logic
    switch(system_state.current_state) {
        case STATE_BOOT:
            if(Sensors_Read(SENSOR_BATTERY_VOLTAGE) > SHUTDOWN_VOLTAGE) {
                system_state.current_state = STATE_READY;
            }
            break;
            
        case STATE_READY:
            // Transition logic...
            break;
            
        // Additional state cases...
    }
    
    // Update motor data
    MotorStatus* m1 = MotorControl_GetStatus(0);
    MotorStatus* m2 = MotorControl_GetStatus(1);
    
    system_state.motor[0].speed_rpm = m1->actual_speed;
    system_state.motor[0].current_a = m1->actual_current;
    system_state.motor[0].temp_c = m1->temperature;
    
    system_state.motor[1].speed_rpm = m2->actual_speed;
    system_state.motor[1].current_a = m2->actual_current;
    system_state.motor[1].temp_c = m2->temperature;
}

// [Additional functions would follow...]