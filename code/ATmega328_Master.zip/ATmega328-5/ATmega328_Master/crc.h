/**
 * Cyclic Redundancy Check (CRC) Module v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - CRC-8/CRC-16 implementations
 * - Hardware-accelerated when available
 * - Memory block verification
 * - Error detection for communications
 */

#ifndef CRC_H
#define CRC_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
//------------------------------------------------------------------------------------
// CRC Type Definitions
//------------------------------------------------------------------------------------
typedef enum {
    CRC_8 = 0,      // 8-bit CRC (for short packets)
    CRC_16,         // 16-bit CRC (EEPROM/data blocks)
    CRC_32          // 32-bit CRC (not implemented)
} CrcType;

//------------------------------------------------------------------------------------
// Public Function Prototypes
//------------------------------------------------------------------------------------

/**
 * @brief Calculate CRC for data block
 * @param type Which CRC algorithm to use
 * @param data Pointer to data
 * @param length Data size in bytes
 * @return Calculated checksum
 */
uint32_t Calculate_CRC(CrcType type, const uint8_t* data, size_t length);

/**
 * @brief Verify data block with stored CRC
 * @param type CRC algorithm used
 * @param data Pointer to data
 * @param length Data size in bytes
 * @param stored_crc Expected checksum
 * @return True if CRC matches
 */
bool Verify_CRC(CrcType type, const uint8_t* data, size_t length, uint32_t stored_crc);

#endif /* CRC_H */