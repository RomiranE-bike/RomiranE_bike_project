/**
 * Watchdog Timer Implementation v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 */

#include "watchdog.h"
#include <avr/wdt.h>

//------------------------------------------------------------------------------------
// Public Function Implementations
//------------------------------------------------------------------------------------

/**
 * @brief Initialize watchdog timer
 */
void WDT_Init(WDT_Period period)
{
    // Translate period to WDP bits
    uint8_t wdp = 0;
    switch(period) {
        case WDT_16MS:   wdp = (1<<WDP0); break;
        case WDT_32MS:   wdp = (1<<WDP1); break;
        // Additional cases...
        case WDT_8S:     wdp = (1<<WDP3)|(1<<WDP0); break;
    }
    
    // Set timeout and enable
    WDTCSR = (1<<WDCE) | (1<<WDE);
    WDTCSR = wdp | (1<<WDE);
}

/**
 * @brief Reset watchdog counter
 */
void WDT_Reset(void)
{
    wdt_reset();
}

// [Additional watchdog functions would follow...]