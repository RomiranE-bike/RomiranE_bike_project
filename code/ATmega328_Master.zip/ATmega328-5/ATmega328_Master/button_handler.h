/**
 * Button Handler v4.7
 * Last Updated: 2025-06-14
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - Full event detection (press, release, short/long press, hold)
 * - Configurable timing parameters
 * - Multi-button support
 * - Debounced inputs
 */

// button_handler.h
#ifndef BUTTON_HANDLER_H
#define BUTTON_HANDLER_H

#include <stdint.h>
#include <stdbool.h>
#include "config.h"

// Button index enums
#define BTN_RIGHT  0
#define BTN_UP     1
#define BTN_ENTER  2
#define BTN_DOWN   3
#define BTN_LEFT   4

//------------------------------------------------------------------------------------
// Button Input Configuration (5 buttons on PORTC)
//------------------------------------------------------------------------------------
#define BUTTON_PORT            PORTC
#define BUTTON_PIN             PINC
#define BUTTON_DDR             DDRC
#define BUTTON_RIGHT_PIN       PC0
#define BUTTON_UP_PIN          PC1
#define BUTTON_ENTER_PIN       PC2
#define BUTTON_DOWN_PIN        PC3
#define BUTTON_LEFT_PIN        PC4

//------------------------------------------------------------------------------------
// Function Prototypes
//------------------------------------------------------------------------------------
void ButtonHandler_Init(void);
void ButtonHandler_Update(void);

bool Button_IsClicked(uint8_t button);
bool Button_IsDoubleClicked(uint8_t button);
bool Button_IsHeld(uint8_t button);
void HandleButtonEvents(void) ;

#endif // BUTTON_HANDLER_H