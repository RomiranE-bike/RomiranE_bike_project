/**
 * Dual Motor Controller v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - Torque vectoring control
 * - Speed synchronization
 * - Emergency stop
 * - UART communication with STM32 controllers
 */

#ifndef MOTOR_CONTROL_H
#define MOTOR_CONTROL_H

#include <stdbool.h>
#include <stdint.h>
//------------------------------------------------------------------------------------
// Motor Command Definitions
//------------------------------------------------------------------------------------
typedef enum {
    CMD_SET_TORQUE = 0,    // Set torque value (Nm)
    CMD_SET_SPEED,         // Set target speed (RPM)
    CMD_EMERGENCY_STOP,    // Immediate stop command
    CMD_ENABLE,            // Enable motor
    CMD_DISABLE,           // Disable motor
	CMD_ACK,              // Data: 1 byte original command
    CMD_GET_STATUS         // Request status update
} MotorCommand;

//------------------------------------------------------------------------------------
// Motor Status Structure
//------------------------------------------------------------------------------------
typedef struct {
    float actual_speed;     // Current speed (RPM)
    float actual_current;   // Current draw (A)
    float temperature;      // Motor temperature (°C)
    uint8_t fault_code;     // Error code (0 = no error)
} MotorStatus;

//------------------------------------------------------------------------------------
// Public Function Prototypes
//------------------------------------------------------------------------------------

/**
 * @brief Initialize motor control subsystem
 */
void MotorControl_Init(void);

/**
 * @brief Send command to motor controller
 * @param motor_id Which motor to address (0 or 1)
 * @param cmd Command to send
 * @param value Parameter value for command
 * @return True if command was sent successfully
 */
bool MotorControl_SendCommand(uint8_t motor_id, MotorCommand cmd, float value);

/**
 * @brief Update motor control parameters
 * Called from main control loop
 */
void MotorControl_Update(void);

/**
 * @brief Emergency stop all motors
 */
void MotorControl_EmergencyStop(void);

/**
 * @brief Get current motor status
 * @param motor_id Which motor to query (0 or 1)
 * @return Pointer to status structure
 */
MotorStatus* MotorControl_GetStatus(uint8_t motor_id);

#endif /* MOTOR_CONTROL_H */