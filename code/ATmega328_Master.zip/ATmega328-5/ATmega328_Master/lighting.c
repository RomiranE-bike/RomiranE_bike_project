/**
 * Intelligent Lighting System Implementation v5.1
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 */

#include "lighting.h"
#include "timers.h"
#include <avr/interrupt.h>
#include <util/delay.h>

//------------------------------------------------------------------------------------
// Module Constants
//------------------------------------------------------------------------------------
#define BLINK_SLOW_INTERVAL 500    // 500ms for slow blink (1Hz)
#define BLINK_FAST_INTERVAL 250    // 250ms for fast blink (2Hz)
#define TURN_SIGNAL_TIMEOUT 10000  // 10s auto-cancel for turn signals
#define DAYLIGHT_THRESHOLD  500    // ADC value for daylight detection

//------------------------------------------------------------------------------------
// Static Variables
//------------------------------------------------------------------------------------
static SystemMode current_mode = MODE_AUTO;
static LightState light_states[CHANNEL_COUNT];
static uint16_t turn_signal_timer = 0;
static uint8_t turn_signal_active = 0;
static bool brake_light_active = false;
static uint16_t blink_timer = 0;
static bool blink_state = false;

//------------------------------------------------------------------------------------
// Private Function Prototypes
//------------------------------------------------------------------------------------
static void Update_Headlight(void);
static void Update_Taillight(void);
static void Update_TurnSignals(void);
static void Update_BrakeLight(void);
static void Detect_LightCondition(void);
static void Set_ChannelOutput(LightChannel ch, bool state);

//------------------------------------------------------------------------------------
// Public Function Implementations
//------------------------------------------------------------------------------------

/**
 * @brief Initialize lighting system hardware
 */
void Lighting_Init(void)
{
    // Configure light output pins
    DDRD |= (1 << LED_HEAD_PIN) | (1 << LED_TAIL_PIN);
    DDRD |= (1 << LED_LEFT_PIN) | (1 << LED_RIGHT_PIN) | (1 << LED_BRAKE_PIN);
    
    // Initialize PWM for dimming control
    Timer0_InitPWM();
    
    // Initialize all lights to off state
    for(uint8_t i = 0; i < CHANNEL_COUNT; i++) {
        light_states[i] = LIGHT_OFF;
    }
    
    // Initialize light sensor ADC if in auto mode LIGHT_SENSOR_CHANNEL=ch6
    if(current_mode == MODE_AUTO) {
        ADC_Read(6);
    }
}

/**
 * @brief Main lighting system update
 */
void Lighting_Update(void)
{
    static uint32_t last_update = 0;
    uint32_t current_time = Get_SystemTick();
    
    // Run at 20Hz update rate
    if(current_time - last_update < 50) return;
    last_update = current_time;
    
    // Auto mode light detection
    if(current_mode == MODE_AUTO) {
        Detect_LightCondition();
    }
    
    // Update all light channels
    Update_Headlight();
    Update_Taillight();
    Update_TurnSignals();
    Update_BrakeLight();
    
    // Handle turn signal timeout
    if(turn_signal_active && (current_time > turn_signal_timer)) {
        turn_signal_active = 0;
        light_states[CHANNEL_LEFT_TURN] = LIGHT_OFF;
        light_states[CHANNEL_RIGHT_TURN] = LIGHT_OFF;
    }
    
    // Update blink state
    blink_timer += 50;
    if((blink_state && blink_timer > BLINK_SLOW_INTERVAL/2) ||
       (!blink_state && blink_timer > BLINK_SLOW_INTERVAL)) {
        blink_state = !blink_state;
        blink_timer = 0;
    }
}

//------------------------------------------------------------------------------------
// Private Function Implementations
//------------------------------------------------------------------------------------

/**
 * @brief Update headlight based on current mode and state
 */
static void Update_Headlight(void)
{
    bool should_light = false;
    
    if(current_mode == MODE_NIGHT) {
        should_light = true;
    }
    else if(current_mode == MODE_AUTO && light_states[CHANNEL_HEADLIGHT] == LIGHT_ON) {
        should_light = true;
    }
    
    if(should_light) {
        if(light_states[CHANNEL_HEADLIGHT] == LIGHT_DIM) {
            Set_PWM_Duty(LED_HEAD_PIN, 30); // 30% brightness
        }
        else {
            Set_ChannelOutput(CHANNEL_HEADLIGHT, true);
        }
    }
    else {
        Set_ChannelOutput(CHANNEL_HEADLIGHT, false);
    }
}

// [Additional private functions would follow the same pattern...]

//------------------------------------------------------------------------------------
// Helper Functions
//------------------------------------------------------------------------------------

/**
 * @brief Set physical channel output state
 * @param ch Light channel to control
 * @param state True to turn on, False to turn off
 */
static void Set_ChannelOutput(LightChannel ch, bool state)
{
    switch(ch) {
        case CHANNEL_HEADLIGHT:
            state ? (PORTD |= (1 << LED_HEAD_PIN)) : (PORTD &= ~(1 << LED_HEAD_PIN));
            break;
        // [Other channels would follow...]
    }
}
//------------------------------------------------------------------------------------
// Define LED pins (using Arduino pin numbers for clarity)
#define LED_HEAD_PIN   6  // OC0A (PD6)

void Timer0_InitPWM(void)
{
	// 1. Set PWM pin as output
	LED_DDR |= (1 << LED_HEAD_PIN);  // PD6 (OC0A) as output for PWM
	
	// 2. Configure Timer0 for Fast PWM mode
	TCCR0A = (1 << WGM01) | (1 << WGM00);  // Fast PWM mode
	TCCR0A |= (1 << COM0A1);               // Clear OC0A on compare match
	
	// 3. Set prescaler to 64 (balance between frequency and resolution)
	TCCR0B = (1 << CS01) | (1 << CS00);    // Prescaler 64
	
	// PWM frequency = 16MHz / 64 / 256 = ~976.56Hz
	// Initial duty cycle = 0%
	OCR0A = 0;
}
//------------------------------------------------------------------------------------
void Set_PWM_Duty(uint8_t pin, uint8_t duty_percent)
{
	// Convert percentage (0-100) to 8-bit value (0-255)
	uint8_t pwm_value = (255 * duty_percent) / 100;
	
	// Clip to maximum 255 in case of rounding errors
	if(duty_percent >= 100) pwm_value = 255;
	
	switch(pin) {
		case LED_HEAD_PIN:
		OCR0A = pwm_value;  // Set duty cycle for OC0A
		break;
		// Add more PWM pins here if needed
		default:
		// Handle invalid pin error
		break;
	}
}
//------------------------------------------------------------------------------------