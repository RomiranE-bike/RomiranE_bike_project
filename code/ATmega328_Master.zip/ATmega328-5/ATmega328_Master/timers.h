/**
 * Timer Management System v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - 1ms system tick timer
 * - PWM generation for motors/lights
 * - Input capture for speed measurement
 * - Timeout management
 */

#ifndef TIMER_H
#define TIMER_H

#include <stdint.h>
#include <stdbool.h>

//------------------------------------------------------------------------------------
// Timer Channel Definitions
//------------------------------------------------------------------------------------
typedef enum {
	
    TIMER1 = 0,     // System tick (16-bit)
    TIMER2,         // Buzzer/PWM (8-bit)
    TIMER3          // Motor control (16-bit)
} TimerChannel;

//------------------------------------------------------------------------------------
// PWM Configuration
//------------------------------------------------------------------------------------
typedef struct {
    uint8_t duty_cycle;  // 0-100 percentage
    uint16_t frequency;  // Hz
    bool inverted;       // Inverted polarity
} PwmConfig;

//------------------------------------------------------------------------------------
// Public Function Prototypes
//------------------------------------------------------------------------------------

/**
 * @brief Initialize timer subsystem
 */
void Timer_Init(void);

/**
 * @brief Get current system ticks (1ms resolution)
 * @return Milliseconds since system start
 */
uint32_t Get_SystemTick(void);

/**
 * @brief Configure PWM output
 * @param timer Which timer to configure
 * @param channel Output channel (A/B)
 * @param config PWM settings
 */
void Timer_ConfigurePWM(TimerChannel timer, uint8_t channel, PwmConfig config);

/**
 * @brief Create software timer
 * @param duration_ms Timeout duration
 * @return Timer ID for reference
 */
uint8_t Timer_Create(uint16_t duration_ms);

/**
 * @brief Check if timer has expired
 * @param timer_id Timer to check
 * @return True if expired
 */
bool Timer_Expired(uint8_t timer_id);

#endif /* TIMER_H */