/**
 * CRC Calculation Implementation v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 */

#include "crc.h"
#include <avr/pgmspace.h>

//------------------------------------------------------------------------------------
// CRC Lookup Tables (Stored in Program Memory)
//------------------------------------------------------------------------------------
static const uint8_t PROGMEM crc8_table[256] = {
    0x00, 0x07, 0x0E, 0x09, 0x1C, 0x1B, 0x12, 0x15, // 0x00-0x07
    // ... (full 256-byte table for CRC-8)
    0xA0, 0xA7, 0xAE, 0xA9, 0xBC, 0xBB, 0xB2, 0xB5  // 0xF8-0xFF
};

static const uint16_t PROGMEM crc16_table[256] = {
    0x0000, 0xC0C1, 0xC181, 0x0140, 0xC301, 0x03C0, 0x0280, 0xC241, // 0x00-0x07
    // ... (full 256-entry table for CRC-16)
    0x8201, 0x42C0, 0x4380, 0x8341, 0x4100, 0x81C1, 0x8081, 0x4040  // 0xF8-0xFF
};

//------------------------------------------------------------------------------------
// Public Function Implementations
//------------------------------------------------------------------------------------

/**
 * @brief Calculate CRC checksum for data block
 * @param type CRC algorithm to use (CRC_8/CRC_16)
 * @param data Pointer to input data
 * @param length Data size in bytes
 * @return Calculated checksum
 */
uint32_t Calculate_CRC(CrcType type, const uint8_t* data, size_t length){
    if(data == NULL || length == 0) return 0;
    
    switch(type) {
        case CRC_8: {
            uint8_t crc = 0x00;
            while(length--) {
                crc = pgm_read_byte(&crc8_table[crc ^ *data++]);
            }
            return crc;
        }
        
        case CRC_16: {
            uint16_t crc = 0xFFFF;
            while(length--) {
                crc = (crc >> 8) ^ pgm_read_word(&crc16_table[(crc & 0xFF) ^ *data++]);
            }
            return crc;
        }
        
        default:
            return 0;
    }
}
//------------------------------------------------------------------------------------
/**
 * @brief Verify data integrity using CRC
 * @param type CRC algorithm used
 * @param data Pointer to data
 * @param length Data size in bytes
 * @param stored_crc Expected checksum value
 * @return True if calculated CRC matches stored CRC
 */
bool Verify_CRC(CrcType type, const uint8_t* data, size_t length, uint32_t stored_crc)
{
    return (Calculate_CRC(type, data, length)) == stored_crc;
}
//------------------------------------------------------------------------------------