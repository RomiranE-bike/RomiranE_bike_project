/**
 * Anti-Theft Security System Implementation v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 */

#include "security.h"
#include "eeprom.h"
#include "timers.h"
#include <avr/eeprom.h>
#include <util/delay.h>

//------------------------------------------------------------------------------------
// Module Constants
//------------------------------------------------------------------------------------
#define PIN_STORAGE_ADDR 0x0100    // EEPROM address for PIN storage
#define LOCKOUT_ATTEMPTS 3         // Maximum failed attempts before lockout
#define LOCKOUT_DURATION 30000     // 30 second lockout period

//------------------------------------------------------------------------------------
// Static Variables
//------------------------------------------------------------------------------------
static uint32_t stored_pin = 0;
static uint8_t failed_attempts = 0;
static uint32_t lockout_start = 0;
static bool system_locked = false;

//------------------------------------------------------------------------------------
// Public Function Implementations
//------------------------------------------------------------------------------------

/**
 * @brief Initialize security system
 */
void Security_Init(void)
{
    // Load PIN from EEPROM
    eeprom_read_block(&stored_pin, (void*)PIN_STORAGE_ADDR, sizeof(stored_pin));
    
    // If no PIN is set, use default
    if(stored_pin == 0xFFFFFFFF) {
        stored_pin = 1234; // Default PIN
        eeprom_write_block(&stored_pin, (void*)PIN_STORAGE_ADDR, sizeof(stored_pin));
    }
    
    // Reset security state
    failed_attempts = 0;
    system_locked = false;
}

/**
 * @brief Verify entered PIN
 */
bool Security_CheckPIN(uint32_t entered_pin)
{
    // Check if system is locked
    if(system_locked) {
        return false;
    }
    
    // Check for master PIN override
    if(entered_pin == MASTER_PIN) {
        failed_attempts = 0;
        return true;
    }
    
    // Verify PIN
    if(entered_pin == stored_pin) {
        failed_attempts = 0;
        return true;
    }
    
    // Handle failed attempt
    failed_attempts++;
    if(failed_attempts >= LOCKOUT_ATTEMPTS) {
        system_locked = true;
        lockout_start = Get_SystemTick();
    }
    
    return false;
}

// [Additional functions would follow...]