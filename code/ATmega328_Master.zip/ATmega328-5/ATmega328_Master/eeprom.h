/**
 * EEPROM Manager v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - Wear-leveling algorithm
 * - Automatic save/load of settings
 * - Data validation with CRC
 * - Error recovery
 */

#ifndef EEPROM_H
#define EEPROM_H

#include <stdint.h>
#include <stdbool.h>
#include "power_management.h"
//------------------------------------------------------------------------------------
// EEPROM Structure Definitions
//------------------------------------------------------------------------------------
#pragma pack(push, 1)
typedef struct {
    uint8_t performance_profile;
    uint8_t max_current_limit;
    uint8_t light_mode;
    uint16_t odometer;
    uint8_t crc;
} EE_Settings;
#pragma pack(pop)

//------------------------------------------------------------------------------------
// Public Function Prototypes
//------------------------------------------------------------------------------------
bool EEPROM_LoadProfile(RidingProfile* profile);
void EEPROM_SaveProfile(const RidingProfile* profile);
/**
 * @brief Initialize EEPROM subsystem
 */
void EEPROM_Init(void);

/**
 * @brief Load settings from EEPROM
 * @return True if valid settings were loaded
 */
bool EEPROM_LoadSettings(void);

/**
 * @brief Save current settings to EEPROM
 * Implements wear-leveling across multiple pages
 */
void EEPROM_SaveSettings(void);

/**
 * @brief Check if settings need saving and write if necessary
 */
void EEPROM_CheckSave(void);

/**
 * @brief Get pointer to current settings structure
 * @return Pointer to settings structure
 */
EE_Settings* EEPROM_GetSettings(void);

#endif /* EEPROM_H */