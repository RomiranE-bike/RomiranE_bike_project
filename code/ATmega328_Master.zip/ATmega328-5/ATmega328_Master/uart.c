/**
 * UART Driver Implementation v4.6
 * Last Updated: 2025-06-14
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 */
#include "config.h"
#include "uart.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/atomic.h>

//------------------------------------------------------------------------------------
// Static Variables
//------------------------------------------------------------------------------------
static struct {
    uint8_t tx_buffer[UART_BUFFER_SIZE];
    volatile uint8_t tx_head;
    volatile uint8_t tx_tail;
    volatile bool tx_in_progress;
    
    uint8_t rx_buffer[UART_BUFFER_SIZE];
    volatile uint8_t rx_head;
    volatile uint8_t rx_tail;
} uart_state;

//------------------------------------------------------------------------------------
// Private Function Prototypes
//------------------------------------------------------------------------------------
static void UART_StartTransmission(void);

//------------------------------------------------------------------------------------
// Public Function Implementations
//------------------------------------------------------------------------------------

void UART_Init(uint32_t baud)
{
    // Calculate UBRR value
    uint16_t ubrr = (F_CPU / 16 / baud) - 1;
    
    // Set baud rate
    UBRR0H = (uint8_t)(ubrr >> 8);
    UBRR0L = (uint8_t)ubrr;
    
    // Enable receiver, transmitter and RX interrupt
    UCSR0B = (1<<RXEN0)|(1<<TXEN0)|(1<<RXCIE0);
    
    // Set frame format: 8 data bits, 1 stop bit, no parity
    UCSR0C = (1<<UCSZ01)|(1<<UCSZ00);
    
    // Initialize state
    uart_state.tx_head = 0;
    uart_state.tx_tail = 0;
    uart_state.tx_in_progress = false;
    uart_state.rx_head = 0;
    uart_state.rx_tail = 0;
}

bool UART_Transmit(const uint8_t *data, uint16_t length)
{
    if(length == 0) return false;
    
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
        uint8_t i;
        for(i = 0; i < length; i++) {
            uint8_t next = (uart_state.tx_head + 1) % UART_BUFFER_SIZE;
            
            // Wait for buffer space if full
            while(next == uart_state.tx_tail) {
                // Buffer full - could add timeout here
            }
            
            uart_state.tx_buffer[uart_state.tx_head] = data[i];
            uart_state.tx_head = next;
        }
        
        if(!uart_state.tx_in_progress) {
            UART_StartTransmission();
        }
    }
    
    return true;
}

uint8_t UART_Available(void)
{
    uint8_t available;
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
        if(uart_state.rx_head >= uart_state.rx_tail) {
            available = uart_state.rx_head - uart_state.rx_tail;
        } else {
            available = UART_BUFFER_SIZE - uart_state.rx_tail + uart_state.rx_head;
        }
    }
    return available;
}

uint8_t UART_Read(void)
{
    if(UART_Available() == 0) return 0;
    
    uint8_t data;
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
        data = uart_state.rx_buffer[uart_state.rx_tail];
        uart_state.rx_tail = (uart_state.rx_tail + 1) % UART_BUFFER_SIZE;
    }
    return data;
}

bool UART_IsTransmitting(void)
{
    return uart_state.tx_in_progress || (uart_state.tx_head != uart_state.tx_tail);
}

//------------------------------------------------------------------------------------
// Private Functions
//------------------------------------------------------------------------------------

static void UART_StartTransmission(void)
{
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
        if(uart_state.tx_tail != uart_state.tx_head) {
            uart_state.tx_in_progress = true;
            UDR0 = uart_state.tx_buffer[uart_state.tx_tail];
            uart_state.tx_tail = (uart_state.tx_tail + 1) % UART_BUFFER_SIZE;
            UCSR0B |= (1<<UDRIE0); // Enable TX interrupt
        }
    }
}

//------------------------------------------------------------------------------------
// Interrupt Service Routines
//------------------------------------------------------------------------------------

ISR(USART_RX_vect)
{
    uint8_t data = UDR0;
    uint8_t next = (uart_state.rx_head + 1) % UART_BUFFER_SIZE;
    
    if(next != uart_state.rx_tail) {
        uart_state.rx_buffer[uart_state.rx_head] = data;
        uart_state.rx_head = next;
    }
    // Else: buffer overflow - could add error handling
}

ISR(USART_UDRE_vect)
{
    if(uart_state.tx_tail != uart_state.tx_head) {
        UDR0 = uart_state.tx_buffer[uart_state.tx_tail];
        uart_state.tx_tail = (uart_state.tx_tail + 1) % UART_BUFFER_SIZE;
    } else {
        // Disable interrupt when buffer empty
        UCSR0B &= ~(1<<UDRIE0);
        uart_state.tx_in_progress = false;
    }
}