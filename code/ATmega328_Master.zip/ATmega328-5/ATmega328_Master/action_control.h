/*
 * action_control.h
 *
 * Created: 6/13/2025 20:28:08
 *  Author: User
 */ 

//------------------------------------------------------------------------------------
#ifndef ACTION_CONTROL_H_
#define ACTION_CONTROL_H_
//------------------------------------------------------------------------------------
#include "config.h"
#include <stdint.h>
#include <stdbool.h>
//------------------------------------------------------------------------------------
void Beep(uint16_t freqHz, uint16_t durationMs);
void StatusLED_On(void);
void StatusLED_Off(void);
void StatusLED_Toggle(void);
//------------------------------------------------------------------------------------
// Lighting functions
void head_Led_toggle(void);
void break_Led_toggle(void);
void turn_right_led_toggle(void);
void turn_left_led_toggle(void);
void tail_Led_blink(void);
void turn_right_led_blink(void);
void turn_left_led_blink(void);

//------------------------------------------------------------------------------------
// Motor functions
void IncreaseSpeed(void);
void DecreaseSpeed(void);
void all_motor_stop(void);
bool front_motor_toggle(void);
bool rear_motor_toggle(void);
bool all_motor_toggle(void);
bool is_front_motor_on(void);
bool is_rear_motor_on(void);
uint8_t get_speed_value(void);
//------------------------------------------------------------------------------------
// Power functions
bool Power_on_toggle(void);
bool is_power_on(void);
//------------------------------------------------------------------------------------
// Timing (to be called regularly in main loop or via timer interrupt)
void ActionControl_Update(uint32_t systemTicks);
//------------------------------------------------------------------------------------
#endif /* ACTION_CONTROL_H_ */
//------------------------------------------------------------------------------------