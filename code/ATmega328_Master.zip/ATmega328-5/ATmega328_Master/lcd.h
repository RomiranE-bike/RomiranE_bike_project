/**
 * LCD 2x16 Driver v4.6
 * Last Updated: 2025-06-12 15:20
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - 4-bit interface mode
 * - Optimized for HD44780 compatible displays
 * - Non-blocking delay via system tick
 * - Custom character support
 * - Dynamic display update support
 */
#ifndef LCD_H
#define LCD_H
//------------------------------------------------------------------------------------
#include "config.h"
#include <stdint.h>
#include <stdbool.h>

// LCD Pins
#define LCD_RS_PIN   PB2
#define LCD_EN_PIN   PB3
#define LCD_D4_PIN   PB4
#define LCD_D5_PIN   PB5
#define LCD_D6_PIN   PB6
#define LCD_D7_PIN   PB7
#define LCD_PORT     PORTB
#define LCD_DDR      DDRB

//------------------------------------------------------------------------------------
// Public Functions
//------------------------------------------------------------------------------------
void LCD_Init(void);
void LCD_Clear(void);
void LCD_SetCursor(uint8_t row, uint8_t col);
void LCD_WriteChar(char data);
void LCD_WriteString(const char *str);
void LCD_DisplayWelcome(void);
void LCD_UpdateDisplay(uint8_t speed_kph, char mode, float battery_voltage, uint8_t temp_celsius);
void LCD_CreateChar(uint8_t location, uint8_t charmap[]);
//------------------------------------------------------------------------------------
typedef enum {
	PAGE_STATUS = 0,
	PAGE_MOTOR_STATS,
	PAGE_SYSTEM,
	PAGE_BUTTONS,
	PAGE_COUNT
} LcdPage;
//------------------------------------------------------------------------------------
static LcdPage currentPage = PAGE_STATUS;
static uint32_t lastPageSwitch = 0;
//------------------------------------------------------------------------------------


#endif  /* LCD_H */
