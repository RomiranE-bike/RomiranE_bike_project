/**
 * Communication Protocol v4.6
 * Last Updated: 2025-06-14
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - Robust packet structure with CRC-8
 * - Full command/response system
 * - Error detection and recovery
 * - Multi-device addressing
 */

#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

//------------------------------------------------------------------------------------
// Packet Structure (Byte-aligned)
//------------------------------------------------------------------------------------
#pragma pack(push, 1)
typedef struct {
    uint8_t start_byte;    // 0xAA (packet start marker)
    uint8_t destination;   // Device address (0 = broadcast)
    uint8_t command;       // Command byte
    uint8_t length;        // Payload length (0-16)
    uint8_t data[16];      // Command payload
    uint8_t crc;           // CRC-8 checksum
} MotorPacket;
#pragma pack(pop)

//------------------------------------------------------------------------------------
// Command Definitions
//------------------------------------------------------------------------------------
typedef enum {
    C0MD_SET_SPEED      = 0x01,  // Data: 2 bytes (RPM)
    C0MD_SET_TORQUE     = 0x02,  // Data: 2 bytes (0.1Nm)
    C0MD_GET_STATUS     = 0x03,  // Data: None
    C0MD_FAULT_REPORT   = 0x04,  // Data: 1 byte fault code
    C0MD_ACK            = 0x05,  // Data: 1 byte original command
    C0MD_NACK           = 0x06,  // Data: 1 byte error code
    C0MD_PING           = 0x07,  // Data: None
    C0MD_CONFIG         = 0x08,  // Data: Variable
    C0MD_RESET          = 0x09   // Data: None
} ProtocolCommand;

//------------------------------------------------------------------------------------
// Response Code Definitions
//------------------------------------------------------------------------------------
typedef enum {
    RESP_SUCCESS       = 0x00,
    RESP_INVALID_CMD   = 0x01,
    RESP_CRC_ERROR     = 0x02,
    RESP_LENGTH_ERROR  = 0x03,
    RESP_BUSY          = 0x04,
    RESP_FAULT         = 0x05,
    RESP_TIMEOUT       = 0x06,
    RESP_OVERRUN       = 0x07
} ProtocolResponse;

//------------------------------------------------------------------------------------
// Public Function Prototypes
//------------------------------------------------------------------------------------

/**
 * @brief Initialize protocol system
 */
void Protocol_Init(void);

/**
 * @brief Build complete packet with checksum
 * @param packet Pointer to packet structure
 * @param dest Destination address
 * @param command Command to send
 * @param data Command payload (NULL for no payload)
 * @param length Payload length (0-16)
 */
void Protocol_BuildPacket(MotorPacket *packet, uint8_t dest, uint8_t command, 
                         const uint8_t *data, uint8_t length);

/**
 * @brief Validate received packet structure and checksum
 * @param packet Packet to validate
 * @return True if packet is valid
 */
bool Protocol_ValidatePacket(const MotorPacket *packet);

/**
 * @brief Send packet via communication interface
 * @param packet Packet to send
 * @return True if transmission started successfully
 */
bool Protocol_SendPacket(const MotorPacket *packet);

/**
 * @brief Receive packet from communication interface
 * @param packet Pointer to receive buffer
 * @return True if valid packet received
 */
bool Protocol_ReceivePacket(MotorPacket *packet);

/**
 * @brief Calculate CRC-8 checksum (Dallas/Maxim algorithm)
 * @param data Pointer to data buffer
 * @param length Number of bytes to process
 * @return Calculated checksum
 */
uint8_t Protocol_CalculateCRC(const uint8_t *data, uint8_t length);

#endif /* PROTOCOL_H */