/**
 * Communication Protocol Implementation v4.6
 * Last Updated: 2025-06-14
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 */

#include "protocol.h"
#include "uart.h"
#include "timers.h"

//------------------------------------------------------------------------------------
// Module Constants
//------------------------------------------------------------------------------------
#define START_BYTE 0xAA
#define MAX_PAYLOAD 16
#define PACKET_TIMEOUT_MS 100

//------------------------------------------------------------------------------------
// Static Variables
//------------------------------------------------------------------------------------
static struct {
    uint8_t rx_buffer[sizeof(MotorPacket)];
    uint8_t rx_index;
    uint32_t last_rx_time;
    bool packet_ready;
} protocol_state;

//------------------------------------------------------------------------------------
// Public Function Implementations
//------------------------------------------------------------------------------------

void Protocol_Init(void)
{
    memset(&protocol_state, 0, sizeof(protocol_state));
    UART_Init(115200); // Initialize with appropriate baud rate
}
//------------------------------------------------------------------------------------
void Protocol_BuildPacket(MotorPacket *packet, uint8_t dest, uint8_t command, 
                         const uint8_t *data, uint8_t length)
{
    packet->start_byte = START_BYTE;
    packet->destination = dest;
    packet->command = command;
    packet->length = (length > MAX_PAYLOAD) ? MAX_PAYLOAD : length;
    
    if(data && length > 0) {
        memcpy(packet->data, data, packet->length);
    } else {
        memset(packet->data, 0, MAX_PAYLOAD);
    }
    
    packet->crc = Protocol_CalculateCRC((uint8_t*)packet, sizeof(MotorPacket)-1);
}
//------------------------------------------------------------------------------------
bool Protocol_ValidatePacket(const MotorPacket *packet)
{
    // Basic validation
    if(packet->start_byte != START_BYTE) return false;
    if(packet->length > MAX_PAYLOAD) return false;
    
    // CRC verification
    uint8_t calculated_crc = Protocol_CalculateCRC((uint8_t*)packet, sizeof(MotorPacket)-1);
    return (packet->crc == calculated_crc);
}
//------------------------------------------------------------------------------------
bool Protocol_SendPacket(const MotorPacket *packet)
{
    if(!Protocol_ValidatePacket(packet)) {
        return false;
    }
    
    return UART_Transmit((uint8_t*)packet, sizeof(MotorPacket));
}
//------------------------------------------------------------------------------------
bool Protocol_ReceivePacket(MotorPacket *packet)
{
    uint32_t now = Get_SystemTick();
    
    // Check for timeout
    if(protocol_state.packet_ready || 
       (protocol_state.rx_index > 0 && (now - protocol_state.last_rx_time) > PACKET_TIMEOUT_MS)) {
        protocol_state.rx_index = 0;
    }
    
    // Process incoming bytes
    while(UART_Available()) {
        uint8_t byte = UART_Read();
        protocol_state.last_rx_time = now;
        
        // Check for start byte (reset if found)
        if(protocol_state.rx_index == 0 && byte != START_BYTE) {
            continue;
        }
        
        protocol_state.rx_buffer[protocol_state.rx_index++] = byte;
        
        // Check if complete packet received
        if(protocol_state.rx_index >= sizeof(MotorPacket)) {
            protocol_state.packet_ready = true;
            protocol_state.rx_index = 0;
            break;
        }
    }
    
    // Process complete packet
    if(protocol_state.packet_ready) {
        protocol_state.packet_ready = false;
        memcpy(packet, protocol_state.rx_buffer, sizeof(MotorPacket));
        return Protocol_ValidatePacket(packet);
    }
    
    return false;
}
//------------------------------------------------------------------------------------
uint8_t Protocol_CalculateCRC(const uint8_t *data, uint8_t length)
{
    uint8_t crc = 0;
    for(uint8_t i = 0; i < length; i++) {
        crc ^= data[i];
        for(uint8_t j = 0; j < 8; j++) {
            if(crc & 0x01) {
                crc = (crc >> 1) ^ 0x8C;
            } else {
                crc >>= 1;
            }
        }
    }
    return crc;
}
//------------------------------------------------------------------------------------