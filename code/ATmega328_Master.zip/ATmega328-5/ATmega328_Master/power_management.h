/**
 * Power Management System v4.6
 * Last Updated: 2025-06-12 19:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - Battery state monitoring
 * - Power profile management
 * - Thermal derating
 * - Low-voltage protection
 */

#ifndef POWER_MANAGEMENT_H
#define POWER_MANAGEMENT_H

#include <stdint.h>
#include <stdbool.h>

//------------------------------------------------------------------------------------
// Configuration Constants
//------------------------------------------------------------------------------------
#define LOW_VOLTAGE_THRESHOLD 3000  // 30.00V (3000 = 30.00 * 100 for fixed-point)
#define CRITICAL_VOLTAGE      2800  // 28.00V - immediate power cutoff
#define PROFILE_MAGIC_NUMBER 0xEB52 // Unique identifier for valid profiles

//------------------------------------------------------------------------------------
// Riding Profile Definitions
//------------------------------------------------------------------------------------
typedef enum {
    PM_PROFILE_ECO = 0,    // Energy-saving mode (70% power)
    PM_PROFILE_NORMAL,     // Standard operation (100% power)
    PM_PROFILE_SPORT,      // High performance (120% power)
    PM_PROFILE_BOOST       // Temporary maximum (150% power, time-limited)
} RidingMode;

//------------------------------------------------------------------------------------
// Power Management Structure
//------------------------------------------------------------------------------------
typedef struct {
    uint16_t magic_number;  // Validation marker (MUST be first field!)
    RidingMode current_mode;
    uint8_t eco_power;      // Percentage (70%)
    uint8_t sport_power;    // Percentage (120%)
    uint8_t boost_timeout;  // Seconds (30s)
} RidingProfile;

//------------------------------------------------------------------------------------
// Public Function Prototypes
//------------------------------------------------------------------------------------
void Power_Init(void);
bool Power_SetMode(RidingMode mode);
uint8_t Power_GetLimit(void);
void Power_Update(void);
void Power_SetProfile(RidingProfile profile);
uint16_t Power_GetBatteryVoltage(void);

#endif /* POWER_MANAGEMENT_H */