/**
 * LED Control Module v4.6 (Simple)
 * Last Updated: 2025-06-12 17:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - Controls 5 LED outputs
 * - Simple on/off and blinking modes
 * - Day/night mode for headlight
 * - Hazard light functionality
 */

#ifndef LED_H
#define LED_H

#include <stdbool.h>
#include "config.h"

//------------------------------------------------------------------------------------
// LED Mode Definitions
//------------------------------------------------------------------------------------
typedef enum {
    LED_OFF = 0,
    LED_ON,
    LED_BLINK_SLOW,    // 1Hz blinking
    LED_BLINK_FAST,    // 2Hz blinking
    LED_BLINK_HAZARD,  // All lights flash
    LED_MODE_COUNT
} LEDMode;

//------------------------------------------------------------------------------------
// Light Type Definitions
//------------------------------------------------------------------------------------
typedef enum {
    LIGHT_HEAD = 0,
    LIGHT_TAIL,
    LIGHT_LEFT,
    LIGHT_RIGHT,
    LIGHT_BRAKE,
    LIGHT_STATUS,
    LIGHT_COUNT
} LightType;

//------------------------------------------------------------------------------------
// Public Function Prototypes
//------------------------------------------------------------------------------------

/**
 * @brief Initialize LED GPIOs
 */
void LED_Init(void);

/**
 * @brief Set LED state
 * @param light Which light to control
 * @param mode Desired operation mode
 */
void LED_Set(LightType light, LEDMode mode);

/**
 * @brief Toggle headlight day/night mode
 * @param night_mode True for night mode (light on)
 */
void LED_SetNightMode(bool night_mode);

/**
 * @brief Update all LED states
 * @note Called periodically from main loop
 */
void LED_Update(void);

/**
 * @brief Emergency flash all lights
 * @param enable True to activate emergency mode
 */
void LED_EmergencyFlash(bool enable);

#endif /* LED_H */