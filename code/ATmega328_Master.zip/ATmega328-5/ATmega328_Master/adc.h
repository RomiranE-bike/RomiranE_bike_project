/**
 * Analog-to-Digital Converter (ADC) Driver v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - 10-bit resolution ADC
 * - 8-channel multiplexer
 * - Auto-triggering mode
 * - Interrupt-driven operation
 * - Noise reduction techniques
 */

#ifndef ADC_H
#define ADC_H

#include <stdint.h>
#include <math.h>
#include <stdint.h>
#include <stdbool.h>
//------------------------------------------------------------------------------------
// Configuration Constants
//------------------------------------------------------------------------------------

//#define ADC_REF_VOLTAGE 5.0f   // ? OK: top-level macro definition   // Reference voltage in volts
#define ADC_MAX_VALUE   1023    // 10-bit resolution
static const float ADC_REF_VOLTAGE = 5.0f;
bool Temperature_IsCritical(void);
uint16_t ADC_ReadVoltage(void);
uint16_t ADC_ReadTemp(void); // Optional for temperature sensing
//------------------------------------------------------------------------------------
// ADC Channel Definitions
//------------------------------------------------------------------------------------
typedef enum {
    ADC_CH0 = 0,    // Potentiometer/Speed Control
    ADC_CH1,        // Battery Voltage
    ADC_CH2,        // Battery Current
    ADC_CH3,        // Motor 1 Temperature (NTC)
    ADC_CH4,        // Motor 2 Temperature (NTC)
    ADC_CH5,        // Throttle Position
    ADC_CH6,        // Light Sensor (Auto mode)
    ADC_CH7         // Reserved
} AdcChannel;
//------------------------------------------------------------------------------------
// Callback Typedef
//------------------------------------------------------------------------------------
typedef void (*AdcCallback)(AdcChannel channel, uint16_t value);

//------------------------------------------------------------------------------------
// Public Function Prototypes
//------------------------------------------------------------------------------------

/**
 * @brief Initialize ADC with specified reference voltage
 * @param ref_voltage Reference voltage in volts (typically 5.0V)
 */
void ADC_Init(float ref_voltage);

/**
 * @brief Start single conversion on specified channel
 * @param channel Channel to convert (0-7)
 * @return Raw 10-bit ADC value
 */
uint16_t ADC_Read(AdcChannel channel);

/**
 * @brief Start continuous conversion with callback
 * @param callback Function to call when conversion completes
 */
void ADC_StartContinuous(AdcCallback callback);

/**
 * @brief Stop continuous conversions
 */
void ADC_StopContinuous(void);

/**
 * @brief Convert raw ADC value to voltage
 * @param raw_value 10-bit ADC reading
 * @return Voltage in volts
 */
float ADC_ToVoltage(uint16_t raw_value);


#endif /* ADC_H */