/**
 * LCD 2x16 Driver Implementation v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 */
//--------------------------------------------------------------------------------------
#include "lcd.h"
#include <util/delay.h>
//--------------------------------------------------------------------------------------
// External system tick (must be implemented elsewhere)
extern volatile uint32_t systemTicks;  // Uses main.c's tick

static uint32_t lcd_lastUpdate = 0;
static bool lcd_welcomeShown = false;

static void LCD_EnablePulse(void);
static void LCD_Send4Bits(uint8_t nibble);
static void LCD_SendCommand(uint8_t cmd);
static void LCD_SendData(uint8_t data);
//--------------------------------------------------------------------------------------
void LCD_Init(void) {
	LCD_DDR |= (1 << LCD_RS_PIN) | (1 << LCD_EN_PIN) |
	(1 << LCD_D4_PIN) | (1 << LCD_D5_PIN) |
	(1 << LCD_D6_PIN) | (1 << LCD_D7_PIN);

	_delay_ms(50);

	LCD_Send4Bits(0x03); _delay_ms(5);
	LCD_Send4Bits(0x03); _delay_us(150);
	LCD_Send4Bits(0x03); _delay_us(150);
	LCD_Send4Bits(0x02);  // 4-bit mode

	LCD_SendCommand(0x28);  // Function set
	LCD_SendCommand(0x0C);  // Display ON
	LCD_Clear();
	LCD_SendCommand(0x06);  // Entry mode
}
//--------------------------------------------------------------------------------------
void LCD_Clear(void) {
	LCD_SendCommand(0x01);
	_delay_ms(2);
}
//--------------------------------------------------------------------------------------
void LCD_SetCursor(uint8_t row, uint8_t col) {
	uint8_t addr = (row == 0) ? 0x00 : 0x40;
	LCD_SendCommand(0x80 | (addr + col));
}
//--------------------------------------------------------------------------------------
void LCD_WriteChar(char data) {
	LCD_SendData(data);
}
//--------------------------------------------------------------------------------------
void LCD_WriteString(const char *str) {
	while (*str) LCD_WriteChar(*str++);
}
//--------------------------------------------------------------------------------------
void LCD_DisplayWelcome(void) {
	static uint32_t startTime = 0;

	if (!lcd_welcomeShown) {
		LCD_Clear();
		LCD_SetCursor(0, 0);
		LCD_WriteString("ROMIRAN E-BIKE");
		LCD_SetCursor(1, 0);
		LCD_WriteString("Controller v4.6 ");
		startTime = systemTicks;
		lcd_welcomeShown = true;
		// Wait for 1500ms non-blocking
		} else if (systemTicks - startTime > 1500) {
		LCD_Clear();  // Clear after 1.5s
	}
}
//--------------------------------------------------------------------------------------

void LCD_CreateChar(uint8_t location, uint8_t charmap[]) {
	location &= 0x07;
	LCD_SendCommand(0x40 | (location << 3));
	for (uint8_t i = 0; i < 8; i++) {
		LCD_SendData(charmap[i]);
	}
}
//--------------------------------------------------------------------------------------
static void LCD_EnablePulse(void) {
	LCD_PORT |= (1 << LCD_EN_PIN);
	_delay_us(1);
	LCD_PORT &= ~(1 << LCD_EN_PIN);
	_delay_us(100);
}
//--------------------------------------------------------------------------------------
static void LCD_Send4Bits(uint8_t nibble) {
	LCD_PORT &= ~((1 << LCD_D4_PIN) | (1 << LCD_D5_PIN) | (1 << LCD_D6_PIN) | (1 << LCD_D7_PIN));
	if (nibble & 0x01) LCD_PORT |= (1 << LCD_D4_PIN);
	if (nibble & 0x02) LCD_PORT |= (1 << LCD_D5_PIN);
	if (nibble & 0x04) LCD_PORT |= (1 << LCD_D6_PIN);
	if (nibble & 0x08) LCD_PORT |= (1 << LCD_D7_PIN);
	LCD_EnablePulse();
}
//--------------------------------------------------------------------------------------
static void LCD_SendCommand(uint8_t cmd) {
	LCD_PORT &= ~(1 << LCD_RS_PIN);
	LCD_Send4Bits(cmd >> 4);
	LCD_Send4Bits(cmd & 0x0F);
	_delay_us(50);
}
//--------------------------------------------------------------------------------------
static void LCD_SendData(uint8_t data) {
	LCD_PORT |= (1 << LCD_RS_PIN);
	LCD_Send4Bits(data >> 4);
	LCD_Send4Bits(data & 0x0F);
	_delay_us(50);
}
//--------------------------------------------------------------------------------------
void LCD_UpdateDisplay(uint8_t speed_kph, char mode, float battery_voltage, uint8_t temp_celsius) {
	if (systemTicks - lcd_lastUpdate >= 500) {  // Refresh every 500ms
		lcd_lastUpdate = systemTicks;

		char line1[17], line2[17];  // 16 chars + null terminator

		// Format line 1: SPD:25km/h MODE:E
		snprintf(line1, sizeof(line1), "SPD:%2dkm/h MODE:%c", speed_kph, mode);

		// Format line 2: BAT:36.4V TEMP:35C
		snprintf(line2, sizeof(line2), "BAT:%2.1fV TEMP:%2dC", battery_voltage, temp_celsius);

		// Display lines
		LCD_SetCursor(0, 0);
		LCD_WriteString(line1);

		LCD_SetCursor(1, 0);
		LCD_WriteString(line2);
	}
}

//Example:
//LCD_UpdateDisplay(FOC_GetSpeedKph(), current_mode, ReadBatteryVoltage(), ReadTemperature());
//LCD_UpdateDisplay(ebike_speed_kph, ebike_mode, ebike_battery_voltage, ebike_temp_celsius);
//--------------------------------------------------------------------------------------
void LCD_DisplayPage(
bool power_on,
bool motor1_running,
bool motor2_running,
uint8_t user_speed_kph,
uint8_t motor1_temp, float motor1_current,
uint8_t motor2_temp, float motor2_current,
uint8_t system_temp,
float battery_voltage, float battery_current,
bool btn_on, bool btn_stop, bool btn_brake,
bool btn_left, bool btn_right, bool btn_horn
) {
	static uint8_t page = 0;
	static uint32_t last_switch = 0;
	char line[17];
	char valstr[8];
    uint32_t now = systemTicks;  // Capture the current time at this call
	if (now - last_switch >= 100) { // 2000 ms = 2 seconds
		last_switch = now;
		page = (page + 1) % 4;// Rotate pages (0 ? 1 ? 2 ? 3 ? 0)
		LCD_Clear();
	}

	switch (page) {
		case 0:
		LCD_SetCursor(0, 0);
		LCD_WriteString("PWR:");
		LCD_WriteString(power_on ? "ON " : "OFF");
		
		LCD_WriteString(" M1:");
		LCD_WriteString(motor1_running ? "RUN" : "STP");

		LCD_SetCursor(1, 0);
		LCD_WriteString("M2:");
		LCD_WriteString(motor2_running ? "RUN" : "STP");
		
		LCD_WriteString(" SPD:");
		itoa(user_speed_kph, line, 10);
		LCD_WriteString(line);
		LCD_WriteString("k");
		break;

		case 1:
		LCD_SetCursor(0, 0);
		LCD_WriteString("M1:");
		itoa(motor1_temp, line, 10);
		LCD_WriteString(line);
		LCD_WriteString("C ");

		FloatToStr10(valstr, motor1_current);
		LCD_WriteString("I:");
		LCD_WriteString(valstr);
		LCD_WriteString("A");

		LCD_SetCursor(1, 0);
		LCD_WriteString("M2:");
		itoa(motor2_temp, line, 10);
		LCD_WriteString(line);
		LCD_WriteString("C ");

		FloatToStr10(valstr, motor2_current);
		LCD_WriteString("I:");
		LCD_WriteString(valstr);
		LCD_WriteString("A");
		break;

		case 2:
		LCD_SetCursor(0, 0);
		LCD_WriteString("SYS:");
		itoa(system_temp, line, 10);
		LCD_WriteString(line);
		LCD_WriteString("C BAT:");

		FloatToStr10(valstr, battery_voltage);
		LCD_WriteString(valstr);
		LCD_WriteString("V");

		LCD_SetCursor(1, 0);
		LCD_WriteString("CUR:");
		FloatToStr10(valstr, battery_current);
		LCD_WriteString(valstr);
		LCD_WriteString("A");
		break;

		case 3:
		LCD_SetCursor(0, 0);
		LCD_WriteString("ON:");
		LCD_WriteChar(btn_on ? '1' : '0');
		LCD_WriteString(" ST:");
		LCD_WriteChar(btn_stop ? '1' : '0');
		LCD_WriteString(" BR:");
		LCD_WriteChar(btn_brake ? '1' : '0');

		LCD_SetCursor(1, 0);
		LCD_WriteString("L:");
		LCD_WriteChar(btn_left ? '1' : '0');
		LCD_WriteString(" R:");
		LCD_WriteChar(btn_right ? '1' : '0');
		LCD_WriteString(" HN:");
		LCD_WriteChar(btn_horn ? '1' : '0');
		break;
	}
}

//--------------------------------------------------------------------------------------
void FloatToStr10(char *buf, float val) {
	// Converts float (e.g. 12.3) to "12.3"
	int int_part = (int)val;
	int frac_part = (int)((val - int_part) * 10);
	if (frac_part < 0) frac_part = -frac_part;
	sprintf(buf, "%d.%d", int_part, frac_part);
}
//--------------------------------------------------------------------------------------