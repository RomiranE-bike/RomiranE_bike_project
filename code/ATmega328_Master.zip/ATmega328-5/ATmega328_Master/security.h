/**
 * Anti-Theft Security System v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - PIN protection
 * - Automatic lockout
 * - Tamper detection
 * - EEPROM storage
 */

#ifndef SECURITY_H
#define SECURITY_H

#include <stdbool.h>
#include <stdint.h>
//------------------------------------------------------------------------------------
// Security Constants
//------------------------------------------------------------------------------------
#define MAX_PIN_ATTEMPTS 3          // Maximum failed attempts
#define LOCKOUT_DURATION 30000      // 30 second lockout (ms)
#define MASTER_PIN 0xFFFFFFFF       // Recovery PIN (change in production)

//------------------------------------------------------------------------------------
// Public Function Prototypes
//------------------------------------------------------------------------------------

/**
 * @brief Initialize security subsystem
 */
void Security_Init(void);

/**
 * @brief Check if entered PIN is correct
 * @param entered_pin PIN to verify
 * @return True if PIN is correct
 */
bool Security_CheckPIN(uint32_t entered_pin);

/**
 * @brief Check if system is in lockout state
 * @return True if locked out
 */
bool Security_IsLocked(void);

/**
 * @brief Reset security system (clear lockout)
 */
void Security_Reset(void);

/**
 * @brief Change current PIN
 * @param old_pin Current PIN for verification
 * @param new_pin New PIN to set
 * @return True if PIN was changed successfully
 */
bool Security_ChangePIN(uint32_t old_pin, uint32_t new_pin);

/**
 * @brief Get remaining lockout time
 * @return Milliseconds remaining in lockout
 */
uint32_t Security_GetLockoutTime(void);

#endif /* SECURITY_H */