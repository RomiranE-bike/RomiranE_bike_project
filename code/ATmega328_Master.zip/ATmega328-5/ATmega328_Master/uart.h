/**
 * UART Driver v4.6
 * Last Updated: 2025-06-14
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - Configurable baud rates
 * - Interrupt-driven operation
 * - Buffered I/O
 * - Error detection
 */

#ifndef UART_H
#define UART_H

#include <stdint.h>
#include <stdbool.h>

//------------------------------------------------------------------------------------
// Configuration Constants
//------------------------------------------------------------------------------------
#define UART_BUFFER_SIZE 64

//------------------------------------------------------------------------------------
// Public Function Prototypes
//------------------------------------------------------------------------------------

/**
 * @brief Initialize UART interface
 * @param baud Desired baud rate
 */
void UART_Init(uint32_t baud);

/**
 * @brief Transmit data buffer
 * @param data Pointer to transmit buffer
 * @param length Number of bytes to transmit
 * @return True if transmission started successfully
 */
bool UART_Transmit(const uint8_t *data, uint16_t length);

/**
 * @brief Check if data is available to read
 * @return Number of bytes available in receive buffer
 */
uint8_t UART_Available(void);

/**
 * @brief Read one byte from receive buffer
 * @return Received byte (0 if buffer empty)
 */
uint8_t UART_Read(void);

/**
 * @brief Get current transmission status
 * @return True if transmission in progress
 */
bool UART_IsTransmitting(void);

#endif /* UART_H */