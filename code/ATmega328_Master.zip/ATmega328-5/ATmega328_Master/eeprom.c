/**
 * EEPROM Manager Implementation v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 */

#include "eeprom.h"
#include "timers.h"
#include <avr/eeprom.h>
#include <string.h>

//------------------------------------------------------------------------------------
// Module Constants
//------------------------------------------------------------------------------------
#define SETTINGS_MARKER    0xAA55
#define MAX_WRITE_CYCLES   100000

//------------------------------------------------------------------------------------
// Static Variables
//------------------------------------------------------------------------------------
static EE_Settings current_settings;
static uint32_t write_cycles = 0;
static bool needs_save = false;
//------------------------------------------------------------------------------------
// Module Constants
//------------------------------------------------------------------------------------
#define PROFILE_EEPROM_ADDR   0x00 // Starting address for profile storage

//------------------------------------------------------------------------------------
// Public Function Implementations
//------------------------------------------------------------------------------------
/**
 * EEPROM Profile Storage Implementation
 * Last Updated: 2025-06-13
 * Author: ROMIRAN E_BIKE
 */
bool EEPROM_LoadProfile(RidingProfile* profile)
{
	eeprom_read_block(profile, (void*)PROFILE_EEPROM_ADDR, sizeof(RidingProfile));
	return (profile->magic_number == PROFILE_MAGIC_NUMBER);
}
//------------------------------------------------------------------------------------
void EEPROM_SaveProfile(const RidingProfile* profile)
{
	eeprom_write_block(profile, (void*)PROFILE_EEPROM_ADDR, sizeof(RidingProfile));
}
//------------------------------------------------------------------------------------
/**
 * @brief Initialize EEPROM subsystem
 */
void EEPROM_Init(void)
{
    // Check for valid settings marker
    uint16_t marker;
    eeprom_read_block(&marker, (void*)0, sizeof(marker));
    
    if(marker == SETTINGS_MARKER) {
        // Load valid settings
        eeprom_read_block(&current_settings, (void*)2, sizeof(EE_Settings));
        write_cycles = eeprom_read_dword((void*)(2 + sizeof(EE_Settings)));
    } else {
        // Initialize new EEPROM
        memset(&current_settings, 0, sizeof(EE_Settings));
        current_settings.crc = Calculate_CRC(&current_settings, sizeof(EE_Settings)-1);
        
        // Corrected marker writing - use a temporary variable
        uint16_t temp_marker = SETTINGS_MARKER;
        eeprom_write_block(&temp_marker, (void*)0, sizeof(temp_marker));
        
        EEPROM_SaveSettings();
    }
}
//------------------------------------------------------------------------------------
/**
 * @brief Save settings to EEPROM with wear-leveling
 */
void EEPROM_SaveSettings(void)
{
    if(write_cycles >= MAX_WRITE_CYCLES) {
        // Handle wear-leveling by rotating storage locations
        // Implementation would go here...
    }
    
    // Update CRC before saving
    current_settings.crc = Calculate_CRC(&current_settings, sizeof(EE_Settings)-1);
    
    // Save to primary location
    eeprom_update_block(&current_settings, (void*)2, sizeof(EE_Settings));
    eeprom_update_dword((void*)(2 + sizeof(EE_Settings)), ++write_cycles);
    
    needs_save = false;
}
//------------------------------------------------------------------------------------
// [Additional functions would follow...]