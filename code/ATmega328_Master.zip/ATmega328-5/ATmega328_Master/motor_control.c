/**
 * Dual Motor Controller Implementation v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 */

#include "motor_control.h"
#include "uart.h"
#include "protocol.h"
#include "safety.h"
#include <string.h>

//------------------------------------------------------------------------------------
// Module Constants
//------------------------------------------------------------------------------------
#define MOTOR_UPDATE_INTERVAL 10   // 10ms between motor updates
#define COMMAND_TIMEOUT_MS    200  // 200ms response timeout

//------------------------------------------------------------------------------------
// Static Variables
//------------------------------------------------------------------------------------
static MotorStatus motor_status[2];
static uint32_t last_update_time[2] = {0};
static uint8_t motor_enabled = 0;

//------------------------------------------------------------------------------------
// Public Function Implementations
//------------------------------------------------------------------------------------

/**
 * @brief Initialize motor control system
 */
void MotorControl_Init(void)
{
    // Initialize UART for motor communication
    UART_Init(115200);
    
    // Initialize motor status structures
    memset(&motor_status[0], 0, sizeof(MotorStatus));
    memset(&motor_status[1], 0, sizeof(MotorStatus));
    
    // Disable motors by default
    motor_enabled = 0;
}

/**
 * @brief Send command to motor controller
 */
bool MotorControl_SendCommand(uint8_t motor_id, MotorCommand cmd, float value)
{
    if(motor_id > 1) return false;
    
    MotorPacket packet;
    uint8_t data[4];
    
    // Convert float value to byte array
    memcpy(data, &value, sizeof(float));
    
    // Build command packet
	Protocol_BuildPacket(&packet, motor_id + 1, (uint8_t)cmd, data, sizeof(float));
    //Protocol_BuildPacket(&packet, (uint8_t)cmd, data, sizeof(float));
    //packet.destination = motor_id + 1; // Address motors as 1 and 2
    
    // Send packet and wait for ACK
    if(!Protocol_SendPacket(&packet)) {
        return false;
    }
    
    // Wait for response
    uint32_t start_time = Get_SystemTick();
    while(Get_SystemTick() - start_time < COMMAND_TIMEOUT_MS) {
        if(Protocol_ReceivePacket(&packet)) {
            if(packet.command == CMD_ACK) {
                return true;
            }
        }
    }
    
    return false;
}

// [Additional functions would follow...]