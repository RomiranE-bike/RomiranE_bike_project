/**
 * Sensor Acquisition Implementation v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 */

#include "sensors.h"
#include "adc.h"
#include "timers.h"
#include <avr/interrupt.h>
#include <util/delay.h>
#include <math.h> // For filter calculations

//------------------------------------------------------------------------------------
// Module Constants
//------------------------------------------------------------------------------------
#define ADC_SAMPLES 16              // Number of samples for averaging
#define CALIBRATION_TIMEOUT 5000    // 5s calibration timeout
#define TEMP_NTC_BETA 3950          // NTC beta coefficient
#define TEMP_NTC_R25 10000.0        // NTC resistance at 25°C
#define TEMP_SERIES_R 10000.0       // Series resistor value

//------------------------------------------------------------------------------------
// Static Variables
//------------------------------------------------------------------------------------
static SensorCalibration calibrations[SENSOR_COUNT];
static uint16_t adc_samples[SENSOR_COUNT][ADC_SAMPLES];
static uint8_t sample_index = 0;
static float filtered_values[SENSOR_COUNT];

//------------------------------------------------------------------------------------
// Private Function Prototypes
//------------------------------------------------------------------------------------
static float Read_RawADC(SensorChannel channel);
static float Apply_Calibration(SensorChannel ch, float raw);
static float Filter_Value(SensorChannel ch, float new_value);
static float Convert_NTC_temp(float adc_value);

//------------------------------------------------------------------------------------
// Public Function Implementations
//------------------------------------------------------------------------------------

/**
 * @brief Initialize all sensors and ADC
 */
void Sensors_Init(void)
{
    // Initialize ADC hardware
    ADC_Init(ADC_REF_VOLTAGE);
    
    // Load calibration data from EEPROM
   // EEPROM_LoadCalibrations();
    
    // Initialize sample buffers
    for(uint8_t ch = 0; ch < SENSOR_COUNT; ch++) {
        for(uint8_t i = 0; i < ADC_SAMPLES; i++) {
            adc_samples[ch][i] = 0;
        }
        filtered_values[ch] = 0.0f;
    }
    
    // Set default calibrations if none loaded
    if(calibrations[SENSOR_BATTERY_VOLTAGE].scale == 0) {
        calibrations[SENSOR_BATTERY_VOLTAGE] = (SensorCalibration){0.0734f, 0.0f, 30.0f, 60.0f};
        calibrations[SENSOR_BATTERY_CURRENT] = (SensorCalibration){0.0244f, -0.512f, -30.0f, 30.0f};
    }
}

/**
 * @brief Read and process sensor value
 */
float Sensors_Read(SensorChannel channel)
{
    if(channel >= SENSOR_COUNT) return 0.0f;
    
    // Read raw ADC value
    float raw = ADC_Read(channel);
    
    // Special handling for temperature sensors
    if(channel == SENSOR_MOTOR1_TEMP || channel == SENSOR_MOTOR2_TEMP) {
        raw = Convert_NTC_temp(raw);
    }
    
    // Apply calibration and filtering
    float calibrated = Apply_Calibration(channel, raw);
    filtered_values[channel] = Filter_Value(channel, calibrated);
    
    return filtered_values[channel];
}

//------------------------------------------------------------------------------------
// Private Function Implementations
//------------------------------------------------------------------------------------

/**
 * @brief Convert NTC reading to temperature
 */
static float Convert_NTC_temp(float adc_value)
{
    float resistance = TEMP_SERIES_R / ((1023.0 / adc_value) - 1.0);
    float steinhart = log(resistance / TEMP_NTC_R25) / TEMP_NTC_BETA;
    steinhart += 1.0 / (25.0 + 273.15);
    return (1.0 / steinhart) - 273.15;
}

// [Additional private functions would follow...]