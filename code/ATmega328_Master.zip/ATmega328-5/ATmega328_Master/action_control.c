/*
 * action_control.c
 *
 * Created: 6/13/2025 20:31:01
 *  Author: User
 */ 
#include "action_control.h"
#include <avr/io.h>
//------------------------------------------------------------------------------------
#define MAX_SPEED 100
#define MIN_SPEED 0
#define BLINK_INTERVAL 50 // ms
//------------------------------------------------------------------------------------
static bool power_on = false;
static bool front_motor_on = false;
static bool rear_motor_on = false;
static uint8_t speed_value = 0;
//------------------------------------------------------------------------------------
static uint32_t last_tail_blink = 0;
static uint32_t last_right_blink = 0;
static uint32_t last_left_blink = 0;
static bool tail_state = false;
static bool right_state = false;
static bool left_state = false;
//------------------------------------------------------------------------------------
// Lighting implementations
void head_Led_toggle(void)          { LED_PORT ^= (1 << LED_HEAD_PIN); }
void break_Led_toggle(void)         { LED_PORT ^= (1 << LED_BRAKE_PIN); }
void turn_right_led_toggle(void)    { LED_PORT ^= (1 << LED_RIGHT_PIN); }
void turn_left_led_toggle(void)     { LED_PORT ^= (1 << LED_LEFT_PIN); }

void tail_Led_blink(void)           { tail_state = !tail_state; }
void turn_right_led_blink(void)     { right_state = !right_state; }
void turn_left_led_blink(void)      { left_state = !left_state; }
//------------------------------------------------------------------------------------
// Soft blinking logic
void ActionControl_Update(uint32_t systemTicks) {
	if (tail_state && (systemTicks - last_tail_blink >= BLINK_INTERVAL)) {
		LED_PORT ^= (1 << LED_BRAKE_PIN);
		last_tail_blink = systemTicks;
	}
	if (right_state && (systemTicks - last_right_blink >= BLINK_INTERVAL)) {
		LED_PORT ^= (1 << LED_RIGHT_PIN);
		last_right_blink = systemTicks;
	}
	if (left_state && (systemTicks - last_left_blink >= BLINK_INTERVAL)) {
		LED_PORT ^= (1 << LED_LEFT_PIN);
		last_left_blink = systemTicks;
	}
}
//------------------------------------------------------------------------------------
// Motor implementations
void IncreaseSpeed(void) {
	if (speed_value < MAX_SPEED) speed_value++;
}
//------------------------------------------------------------------------------------
void DecreaseSpeed(void) {
	if (speed_value > MIN_SPEED) speed_value--;
}
//------------------------------------------------------------------------------------
void all_motor_stop(void) {
	front_motor_on = false;
	rear_motor_on = false;
	speed_value = 0;
}
//------------------------------------------------------------------------------------
bool front_motor_toggle(void) {
	front_motor_on = !front_motor_on;
	return front_motor_on;
}
//------------------------------------------------------------------------------------
bool rear_motor_toggle(void) {
	rear_motor_on = !rear_motor_on;
	return rear_motor_on;
}
//------------------------------------------------------------------------------------
bool all_motor_toggle(void) {
	bool new_state = !(front_motor_on || rear_motor_on);
	front_motor_on = rear_motor_on = new_state;
	return new_state;
}
//------------------------------------------------------------------------------------
bool is_front_motor_on(void) { return front_motor_on; }
bool is_rear_motor_on(void)  { return rear_motor_on;  }
uint8_t get_speed_value(void) { return speed_value; }
//------------------------------------------------------------------------------------
// Power implementation
bool Power_on_toggle(void) {
	power_on = !power_on;
	return power_on;
}
//------------------------------------------------------------------------------------
bool is_power_on(void) {
	return power_on;
}
//------------------------------------------------------------------------------------
