/**
 * Power Management System Implementation v4.6
 * Last Updated: 2025-06-13
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Hardware Dependencies:
 * - ADC for battery monitoring
 * - Timer for boost mode timeout
 * - EEPROM for profile storage
 */

#include "power_management.h"
#include "adc.h"
#include "eeprom.h"
#include <avr/io.h>
#include <string.h>

//------------------------------------------------------------------------------------
// Module Constants
//------------------------------------------------------------------------------------
#define DEFAULT_ECO_POWER        70    // 70% power in ECO mode
#define DEFAULT_SPORT_POWER     120    // 120% power in SPORT mode
#define DEFAULT_BOOST_TIMEOUT    30    // 30 seconds boost duration
#define VOLTAGE_CHECK_INTERVAL 1000    // 1 second voltage monitoring interval

//------------------------------------------------------------------------------------
// Static Variables
//------------------------------------------------------------------------------------
static RidingProfile current_profile = {
    .magic_number = PROFILE_MAGIC_NUMBER,
    .current_mode = PM_PROFILE_NORMAL,
    .eco_power = DEFAULT_ECO_POWER,
    .sport_power = DEFAULT_SPORT_POWER,
    .boost_timeout = DEFAULT_BOOST_TIMEOUT
};

static uint32_t last_boost_time = 0;
static uint32_t last_voltage_check = 0;
static uint16_t battery_voltage = 0;
static bool voltage_critical = false;

//------------------------------------------------------------------------------------
// Private Function Prototypes
//------------------------------------------------------------------------------------
static void Load_DefaultProfile(void);
static void Check_BatteryVoltage(void);
static void Handle_BoostTimeout(void);
static void Handle_CriticalVoltage(void);

//------------------------------------------------------------------------------------
// Public Function Implementations
//------------------------------------------------------------------------------------

void Power_Init(void)
{
    // Try to load profile from EEPROM
    if(!EEPROM_LoadProfile(&current_profile)) {
        Load_DefaultProfile();
    }
    
    // Verify magic number and fields
    if(current_profile.magic_number != PROFILE_MAGIC_NUMBER ||
       current_profile.eco_power > 100 ||
       current_profile.sport_power > 150) {
        Load_DefaultProfile();
    }
    
    // Initialize timers
    last_boost_time = Get_SystemTick();
    last_voltage_check = Get_SystemTick();
    
    // Take initial voltage reading
    battery_voltage = ADC_ReadVoltage();
    voltage_critical = (battery_voltage < CRITICAL_VOLTAGE);
}

bool Power_SetMode(RidingMode mode)
{
    if(voltage_critical) return false;
    if(mode == PM_PROFILE_BOOST && battery_voltage < LOW_VOLTAGE_THRESHOLD) {
        return false;
    }
    
    current_profile.current_mode = mode;
    
    if(mode == PM_PROFILE_BOOST) {
        last_boost_time = Get_SystemTick();
    }
    
    return true;
}

uint8_t Power_GetLimit(void)
{
    if(voltage_critical) return 0;
    
    uint8_t power_limit = 100; // Default for normal mode
    
    switch(current_profile.current_mode) {
        case PM_PROFILE_ECO:    power_limit = current_profile.eco_power; break;
        case PM_PROFILE_SPORT:  power_limit = current_profile.sport_power; break;
        case PM_PROFILE_BOOST:  power_limit = 150; break;
        default: break;
    }
    
    if(Temperature_IsCritical()) {
        power_limit = power_limit * 70 / 100;
    }
    
    return power_limit;
}

void Power_Update(void)
{
    uint32_t current_time = Get_SystemTick();
    
    if(current_time - last_voltage_check >= VOLTAGE_CHECK_INTERVAL) {
        last_voltage_check = current_time;
        Check_BatteryVoltage();
        Handle_CriticalVoltage();
    }
    
    if(current_profile.current_mode == PM_PROFILE_BOOST) {
        Handle_BoostTimeout();
    }
}

void Power_SetProfile(RidingProfile profile)
{
    profile.eco_power = (profile.eco_power > 100) ? 100 : profile.eco_power;
    profile.sport_power = (profile.sport_power < 100) ? 100 : 
                         (profile.sport_power > 150) ? 150 : profile.sport_power;
    profile.magic_number = PROFILE_MAGIC_NUMBER;
    
    memcpy(&current_profile, &profile, sizeof(RidingProfile));
    EEPROM_SaveProfile(&current_profile);
}

uint16_t Power_GetBatteryVoltage(void)
{
    return battery_voltage;
}

//------------------------------------------------------------------------------------
// Private Function Implementations
//------------------------------------------------------------------------------------

static void Load_DefaultProfile(void)
{
    current_profile.magic_number = PROFILE_MAGIC_NUMBER;
    current_profile.current_mode = PM_PROFILE_NORMAL;
    current_profile.eco_power = DEFAULT_ECO_POWER;
    current_profile.sport_power = DEFAULT_SPORT_POWER;
    current_profile.boost_timeout = DEFAULT_BOOST_TIMEOUT;
}

static void Check_BatteryVoltage(void)
{
    battery_voltage = ADC_ReadVoltage();
    voltage_critical = (battery_voltage < CRITICAL_VOLTAGE);
    
    if(!voltage_critical && battery_voltage < LOW_VOLTAGE_THRESHOLD) {
        current_profile.current_mode = PM_PROFILE_ECO;
    }
}

static void Handle_BoostTimeout(void)
{
    if(Get_SystemTick() - last_boost_time >= (current_profile.boost_timeout * 1000)) {
        current_profile.current_mode = PM_PROFILE_NORMAL;
    }
}

static void Handle_CriticalVoltage(void)
{
    if(voltage_critical) {
        current_profile.current_mode = PM_PROFILE_ECO;
        current_profile.eco_power = 0; // Force power cutoff
    }
}
//------------------------------------------------------------------------------------
/*
ADC_Init(); // If needed
Temperature_Init(); // If needed
Power_Init(); // Will call EEPROM functions
Call periodically:

c
void main_loop()
{
	Power_Update(); // Handles all monitoring
	// ... other system tasks
}
Access data when needed:

c
uint16_t voltage = Power_GetBatteryVoltage();
bool is_overheated = Temperature_IsCritical();
*///------------------------------------------------------------------------------------