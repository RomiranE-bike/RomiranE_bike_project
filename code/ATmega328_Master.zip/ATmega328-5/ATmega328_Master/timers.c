/**
 * Timer Management Implementation v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 */
#include "config.h"
#include "timers.h"
#include <avr/interrupt.h>

//------------------------------------------------------------------------------------
// Module Variables
//------------------------------------------------------------------------------------

volatile uint32_t system_ticks = 0;     // Milliseconds since boot
volatile uint8_t control_loop_flag = 0; // Control loop execution flag
//------------------------------------------------------------------------------------
// Public Function Implementations
//------------------------------------------------------------------------------------

/**
 * @brief Initialize system timers
 */
void Timer_Init(void)
{
	// Timer1 for system ticks (1ms)
	TCCR1B = (1<<WGM12) | (1<<CS11);  // CTC mode, prescaler 8
	OCR1A = (F_CPU / 8000) - 1;       // 1ms interval (16MHz/8/1000Hz)
	TIMSK1 = (1<<OCIE1A);
	
	// Timer0 for PWM generation (Fast PWM mode)
	TCCR0A = (1<<WGM01) | (1<<WGM00); // Fast PWM mode
	TCCR0A |= (1<<COM0A1);            // Clear OC0A on compare match
	TCCR0B = (1<<CS01);               // Prescaler 8
	
	// Optional: Set default duty cycle (0-255)
	OCR0A = 0;                        // Start with 0% duty cycle
	
	// Enable Timer0 overflow interrupt if needed
	// TIMSK0 = (1<<TOIE0);
}

/**
 * @brief Get current system ticks
 */
uint32_t Get_SystemTick(void)
{
    uint32_t ticks;
    cli();
    ticks = system_ticks;
    sei();
    return ticks;
}

//------------------------------------------------------------------------------------
// Interrupt Service Routines
//------------------------------------------------------------------------------------


//------------------------------------------------------------------------------------
// Interrupt Service Routines
//------------------------------------------------------------------------------------

/**
 * @brief Timer1 Compare A Interrupt (1ms system tick)
 * Handles:
 * - System timekeeping
 * - Control loop timing
 * - Button debouncing timing
 */
ISR(TIMER1_COMPA_vect) {
    system_ticks++;
    
    // Set control loop flag at 100Hz (every 10ms)
    if(system_ticks % (1000/CONTROL_LOOP_HZ) == 0) {
        control_loop_flag = 1;
    }
}

// [Additional timer functions would follow...]