/**
 * ADC Controller Implementation v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 */

#include "adc.h"
#include <avr/interrupt.h>
#include <stddef.h>  // Standard C header that defines NULL
//------------------------------------------------------------------------------------
// Module Variables
//------------------------------------------------------------------------------------
static volatile uint16_t adc_results[8];
static volatile uint8_t current_channel = 0;
static AdcCallback callback = NULL;
//------------------------------------------------------------------------------------
// Static Variables
//------------------------------------------------------------------------------------
static bool critical_state = false;

//------------------------------------------------------------------------------------
// Module Constants
//------------------------------------------------------------------------------------

#define TEMP_CRITICAL_THRESH  80  // 80�C critical threshold
#define TEMP_HYSTERESIS       5   // 5�C hysteresis
//------------------------------------------------------------------------------------
// Module Constants
//------------------------------------------------------------------------------------
#define ADC_REF_VOLTAGE      5000 // 5.0V reference in mV
#define VOLTAGE_DIVIDER_RATIO 2.5 // (R1+R2)/R2

//------------------------------------------------------------------------------------
// Public Function Implementations
//------------------------------------------------------------------------------------

uint16_t ADC_ReadVoltage(void)
{
	
	// Read result and convert to millivolts
	uint16_t adc_value = ADC_Read(ADC_CH1);// ADC_CH1 for battery voltage
	uint16_t voltage = (adc_value * ADC_REF_VOLTAGE * VOLTAGE_DIVIDER_RATIO) / 1024;
	
	return voltage; // Returns voltage in millivolts (e.g., 3000 = 30.00V)
}

//------------------------------------------------------------------------------------
// Public Function Implementations
//------------------------------------------------------------------------------------

bool Temperature_IsCritical(void)
{
	// Read temperature sensor (implementation depends on your hardware)
	uint16_t temp_adc = ADC_Read(ADC_CH3);// ADC_CH3 for temperature
	uint8_t temperature = (temp_adc * 100) / 1024; // Example conversion
	
	// Hysteresis check
	if(!critical_state && temperature >= TEMP_CRITICAL_THRESH) {
		critical_state = true;
	}
	else if(critical_state && temperature < (TEMP_CRITICAL_THRESH - TEMP_HYSTERESIS)) {
		critical_state = false;
	}
	
	return critical_state;
}
//------------------------------------------------------------------------------------
// Public Function Implementations
//------------------------------------------------------------------------------------

/**
 * @brief Initialize ADC with auto-scanning
 */
void ADC_Init(float ref_voltage)
{
    // Configure ADC
    ADMUX = (1<<REFS0); // AVcc reference
    ADCSRA = (1<<ADEN)|(1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0); // Enable, prescaler 128
    ADCSRB = 0;
    DIDR0 = 0xFF; // Disable digital inputs on ADC pins
    
    // Start first conversion
    ADCSRA |= (1<<ADSC);
}
//------------------------------------------------------------------------------------
// Private Functions
//------------------------------------------------------------------------------------
/**
 * @brief Read ADC channel (blocking)
 */
uint16_t ADC_Read(AdcChannel channel)
{
    if(channel > 7) return 0;
    
    // Set channel
    ADMUX = (ADMUX & 0xF0) | (channel & 0x0F);
    
    // Start conversion
    ADCSRA |= (1<<ADSC);
    
    // Wait for completion
    while(ADCSRA & (1<<ADSC));
    
    return ADC;
}

//------------------------------------------------------------------------------------
// Interrupt Service Routine
//------------------------------------------------------------------------------------

/**
 * @brief ADC conversion complete interrupt
 */
ISR(ADC_vect)
{
    // Store result
    adc_results[current_channel] = ADC;
    
    // Move to next channel
    current_channel = (current_channel + 1) % 8;
    ADMUX = (ADMUX & 0xF0) | (current_channel & 0x0F);
    
    // Start next conversion
    ADCSRA |= (1<<ADSC);
    
    // Notify callback if registered
    if(callback) {
        callback(current_channel, adc_results[current_channel]);
    }
}
//------------------------------------------------------------------------------------