/**
 * LED Control Module Implementation v4.6 (Simple)
 * Last Updated: 2025-06-12 17:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Hardware Dependencies:
 * - ATmega328P GPIO
 * - System tick timer for timing
 */

#include "led.h"
#include "timers.h"
#include <avr/io.h>
#include <string.h>

//------------------------------------------------------------------------------------
// Module Constants
//------------------------------------------------------------------------------------
#define BLINK_SLOW_INTERVAL    500     // 500ms (1Hz)
#define BLINK_FAST_INTERVAL    250     // 250ms (2Hz)
#define HAZARD_INTERVAL        BLINK_FAST_INTERVAL

//------------------------------------------------------------------------------------
// Static Variables
//------------------------------------------------------------------------------------
static LEDMode led_modes[LIGHT_COUNT];
static bool led_states[LIGHT_COUNT];
static uint32_t blink_timer = 0;
static bool blink_state = false;
static bool emergency_mode = false;
static bool night_mode = false;

// LED to hardware mapping
static const struct {
    volatile uint8_t* port;
    uint8_t pin;
} led_map[LIGHT_COUNT] = {
    [LIGHT_HEAD]   = {&LED_PORT, LED_HEAD_PIN},
    [LIGHT_TAIL]   = {&LED_PORT, LED_TAIL_PIN},
    [LIGHT_LEFT]   = {&LED_PORT, LED_LEFT_PIN},
    [LIGHT_RIGHT]  = {&LED_PORT, LED_RIGHT_PIN},
    [LIGHT_BRAKE]  = {&LED_PORT, LED_BRAKE_PIN},
    [LIGHT_STATUS] = {&LED_PORT, LED_STATUS_PIN}
};

//------------------------------------------------------------------------------------
// Private Function Prototypes
//------------------------------------------------------------------------------------
static void Update_LEDOutput(LightType light);
static void Handle_BlinkPatterns(void);
static void Handle_EmergencyMode(void);

//------------------------------------------------------------------------------------
// Public Function Implementations
//------------------------------------------------------------------------------------

void LED_Init(void)
{
    // Initialize all LEDs to OFF state
    memset(led_modes, LED_OFF, sizeof(led_modes));
    memset(led_states, false, sizeof(led_states));
    
    // Set all LED pins as outputs
    for(int i = 0; i < LIGHT_COUNT; i++) {
        *(led_map[i].port - 1) |= (1 << led_map[i].pin); // DDRx = PORTx - 1
        Update_LEDOutput(i);
    }
}
//------------------------------------------------------------------------------------
void LED_Set(LightType light, LEDMode mode)
{
    if(light >= LIGHT_COUNT) return;
    
    led_modes[light] = mode;
    Update_LEDOutput(light);
}
//------------------------------------------------------------------------------------
void LED_SetNightMode(bool night_mode_enable)
{
    night_mode = night_mode_enable;
    LED_Set(LIGHT_HEAD, night_mode ? LED_ON : LED_OFF);
}
//------------------------------------------------------------------------------------
void LED_Update(void)
{
    Handle_BlinkPatterns();
    Handle_EmergencyMode();
    
    // Update all LED outputs
    for(int i = 0; i < LIGHT_COUNT; i++) {
        Update_LEDOutput(i);
    }
}
//------------------------------------------------------------------------------------
void LED_EmergencyFlash(bool enable)
{
    emergency_mode = enable;
}

//------------------------------------------------------------------------------------
// Private Function Implementations
//------------------------------------------------------------------------------------

static void Update_LEDOutput(LightType light)
{
    bool state = false;
    
    switch(led_modes[light]) {
        case LED_OFF:
            state = false;
            break;
            
        case LED_ON:
            state = true;
            break;
            
        case LED_BLINK_SLOW:
        case LED_BLINK_FAST:
        case LED_BLINK_HAZARD:
            state = blink_state;
            break;
    }
    
    // Apply night mode if not in emergency mode
    if(!emergency_mode && light == LIGHT_HEAD) {
        state = night_mode ? true : false;
    }
    
    // Update physical pin
    if(state) {
        *led_map[light].port |= (1 << led_map[light].pin);
    } else {
        *led_map[light].port &= ~(1 << led_map[light].pin);
    }
    
    led_states[light] = state;
}
//------------------------------------------------------------------------------------
static void Handle_BlinkPatterns(void)
{
    uint32_t now = Get_SystemTick();
    uint32_t interval = BLINK_SLOW_INTERVAL;
    
    // Determine fastest required blink interval
    for(int i = 0; i < LIGHT_COUNT; i++) {
        if(led_modes[i] == LED_BLINK_FAST || led_modes[i] == LED_BLINK_HAZARD) {
            interval = BLINK_FAST_INTERVAL;
            break;
        }
    }
    
    // Update blink state if interval elapsed
    if(now - blink_timer >= interval) {
        blink_state = !blink_state;
        blink_timer = now;
    }
}
//------------------------------------------------------------------------------------
static void Handle_EmergencyMode(void)
{
    if(!emergency_mode) return;
    
    // Simplified emergency flash implementation
    static uint32_t last_flash = 0;
    uint32_t now = Get_SystemTick();
    
    if(now - last_flash >= HAZARD_INTERVAL) {
        last_flash = now;
        blink_state = !blink_state;
        
        for(int i = 0; i < LIGHT_COUNT; i++) {
            *led_map[i].port = blink_state 
                ? (*led_map[i].port | (1 << led_map[i].pin))
                : (*led_map[i].port & ~(1 << led_map[i].pin));
        }
    }
}
//------------------------------------------------------------------------------------