/**
 * Fault Management System Implementation v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 */

#include "fault_handling.h"
#include "eeprom.h"
#include "status_buzzer.h"
#include <avr/eeprom.h>

//------------------------------------------------------------------------------------
// Module Constants
//------------------------------------------------------------------------------------
#define FAULT_LOG_SIZE 16
#define FAULT_EEPROM_BASE 0x0200

//------------------------------------------------------------------------------------
// Static Variables
//------------------------------------------------------------------------------------
static uint8_t active_faults = 0;
static FaultRecord fault_log[FAULT_LOG_SIZE];
static uint8_t log_index = 0;

//------------------------------------------------------------------------------------
// Public Function Implementations
//------------------------------------------------------------------------------------

/**
 * @brief Initialize fault management system
 */
void Fault_Init(void)
{
    active_faults = 0;
    log_index = 0;
    memset(fault_log, 0, sizeof(fault_log));
    
    // Load persistent faults from EEPROM
    eeprom_read_block((void*)fault_log, (void*)FAULT_EEPROM_BASE, sizeof(fault_log));
    
    // Validate CRC for each record
    for(uint8_t i = 0; i < FAULT_LOG_SIZE; i++) {
        // Create a local copy of the fault record for validation
        FaultRecord record = fault_log[i];
        
        if(record.crc != Calculate_CRC(&record, sizeof(FaultRecord)-1)) {
            memset(&fault_log[i], 0, sizeof(FaultRecord));
        } else if(record.active) {
            active_faults |= (1 << record.type);
        }
    }
}
//------------------------------------------------------------------------------------
/**
 * @brief Trigger new fault condition
 */
void Fault_Trigger(FaultType fault, FaultSeverity severity)
{
    if(fault >= FAULT_COUNT) return;
    
    // Set fault bit
    active_faults |= (1 << fault);
    
    // Log fault
    fault_log[log_index].type = fault;
    fault_log[log_index].severity = severity;
    fault_log[log_index].timestamp = Get_SystemTick();
    fault_log[log_index].active = true;
    fault_log[log_index].crc = Calculate_CRC(&fault_log[log_index], sizeof(FaultRecord)-1);
    
    // Update EEPROM
    eeprom_update_block(&fault_log[log_index], 
                       (void*)(FAULT_EEPROM_BASE + log_index * sizeof(FaultRecord)), 
                       sizeof(FaultRecord));
    
    // Advance log index
    log_index = (log_index + 1) % FAULT_LOG_SIZE;
    
    // Audible alert based on severity
    if(severity >= SEVERITY_WARNING) {
        StatusBuzzer_Trigger(severity == SEVERITY_FATAL ? STATUS_ALARM : STATUS_WARNING);
    }
}
//------------------------------------------------------------------------------------
// [Additional functions would follow...]