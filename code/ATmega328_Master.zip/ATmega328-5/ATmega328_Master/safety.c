/**
 * Safety Monitoring System Implementation v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 */

#include "safety.h"
#include "sensors.h"
#include "motor_control.h"
#include "fault_handling.h"
#include "config.h"
//------------------------------------------------------------------------------------
// Module Constants
//------------------------------------------------------------------------------------
#define DERATE_STEP 5       // 5% derate per step
#define CHECK_INTERVAL 100  // 100ms between checks

//------------------------------------------------------------------------------------
// Static Variables
//------------------------------------------------------------------------------------
static SafetyLimits limits = {
    .max_current = OVERCURRENT_THRESHOLD,
    .max_temp = OVERTEMP_THRESHOLD,
    .min_voltage = SHUTDOWN_VOLTAGE,
    .max_speed = 2000       // RPM
};
static uint32_t last_check = 0;

//------------------------------------------------------------------------------------
// Public Function Implementations
//------------------------------------------------------------------------------------

/**
 * @brief Monitor all safety parameters
 */
void Safety_Monitor(void)
{
    uint32_t now = Get_SystemTick();
    if(now - last_check < CHECK_INTERVAL) return;
    last_check = now;
    
    float voltage = Sensors_Read(SENSOR_BATTERY_VOLTAGE);
    float current = fabs(Sensors_Read(SENSOR_BATTERY_CURRENT));
    float temp1 = Sensors_Read(SENSOR_MOTOR1_TEMP);
    float temp2 = Sensors_Read(SENSOR_MOTOR2_TEMP);
    
    // Voltage monitoring
    if(voltage < limits.min_voltage * 0.9) {
        Fault_Trigger(FAULT_UNDERVOLTAGE, SEVERITY_FATAL);
    } 
    else if(voltage < limits.min_voltage) {
        Fault_Trigger(FAULT_UNDERVOLTAGE, SEVERITY_CRITICAL);
    }
    
    // Current monitoring
    if(current > limits.max_current * 1.2) {
        Fault_Trigger(FAULT_OVERCURRENT, SEVERITY_FATAL);
        MotorControl_EmergencyStop();
    }
    else if(current > limits.max_current) {
        Fault_Trigger(FAULT_OVERCURRENT, SEVERITY_CRITICAL);
    }
    
    // Temperature monitoring (using highest motor temp)
    float max_temp = fmaxf(temp1, temp2);
    if(max_temp > limits.max_temp + 10) {
        Fault_Trigger(FAULT_OVERTEMP, SEVERITY_FATAL);
        MotorControl_EmergencyStop();
    }
    else if(max_temp > limits.max_temp) {
        Fault_Trigger(FAULT_OVERTEMP, SEVERITY_CRITICAL);
    }
}

// [Additional functions would follow...]