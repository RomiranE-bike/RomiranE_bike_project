/*
 * beep_pwm.h
 *
 * Created: 6/15/2025 18:20:15
 *  Author: User
 */ 


#ifndef BEEP_PWM_H_
#define BEEP_PWM_H_



#include <stdint.h>
#include <stdbool.h>

void BeepPWM_Init(void);
void BeepPWM_Start(uint16_t freqHz, uint16_t durationMs);
void BeepPWM_Update(uint32_t systemTicks);
bool BeepPWM_IsActive(void);



#endif /* BEEP_PWM_H_ */