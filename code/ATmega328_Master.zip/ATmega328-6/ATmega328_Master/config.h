/**
 * BLDC E-Bike Controller v4.5
 * ATmega328 Master Configuration
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 */

#ifndef CONFIG_H
#define CONFIG_H

//------------------------------------------------------------------------------------
// System Includes
//------------------------------------------------------------------------------------
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdint.h>    //unit8_t,uint16_t,uint32_t....
#include <stdbool.h>   //bool....
#include <util/delay.h>



//------------------------------------------------------------------------------------
// System Clock Configuration
//------------------------------------------------------------------------------------
#define F_CPU 16000000UL               // 16MHz crystal
#define CONTROL_LOOP_HZ 100            // Main control frequency (100Hz)
#define SAFETY_LOOP_HZ 10              // Safety system frequency (10Hz)
#define TELEMETRY_INTERVAL_MS 1000     // Data reporting interval (1s)
//------------------------------------------------------------------------------------
// Safety Thresholds
//------------------------------------------------------------------------------------
#define OVERCURRENT_THRESHOLD 15.0f    // Amps (15A max continuous)
#define SHUTDOWN_VOLTAGE 30.0f         // Volts (minimum battery voltage)
#define OVERTEMP_THRESHOLD 80.0f       // Degrees Celsius (max motor temp)
//------------------------------------------------------------------------------------
// EEPROM Configuration
//------------------------------------------------------------------------------------
#define EEPROM_SETTINGS_ADDR 0x0000    // Start address for settings
#define EEPROM_CYCLES_MAX    100000    // Max write cycles before wear-leveling
#define SAFETY_CHECK_HZ 10  // 10Hz safety check frequency
//------------------------------------------------------------------------------------
// LCD Pin Configuration (2x16 Character LCD - 4-bit mode)
//------------------------------------------------------------------------------------
#define LCD_RS_PIN   PB2               // Register Select (Command/Data)
#define LCD_EN_PIN   PB3               // Enable pin
#define LCD_D4_PIN   PB4               // Data bit 4
#define LCD_D5_PIN   PB5               // Data bit 5
#define LCD_D6_PIN   PB6               // Data bit 6
#define LCD_D7_PIN   PB7               // Data bit 7
#define LCD_PORT     PORTB             // Port register
#define LCD_DDR      DDRB              // Data direction register

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------
// Button Input Configuration (5 buttons)
//------------------------------------------------------------------------------------
#define BUTTON_PORT            PORTC       // Button input port
#define BUTTON_PIN             PINC       // Button input port
#define BUTTON_DDR             DDRC
#define BUTTON_RIGHT_PIN       PC0        // Up/Increase value
#define BUTTON_UP_PIN          PC1        // Up/Increase value
#define BUTTON_ENTER_PIN       PC2        // Mode selection button,Power on/off button, Enter/Confirm selection
#define BUTTON_DOWN_PIN        PC3        // Down/Decrease value
#define BUTTON_LEFT_PIN        PC4        // Down/Decrease value

//------------------------------------------------------------------------------------
// LED Output Configuration (5 LEDs)
//------------------------------------------------------------------------------------
#define LED_PORT           PORTD      // LED control port
#define LED_DDR            DDRD       // REG control DDR


#define LED_HEAD_PIN       PD4         // LED_LEFT_PIN signal
#define LED_BRAKE_PIN      PD5         // Brake light
#define LED_TAIL_PIN       PD5         // Brake light
#define LED_RIGHT_PIN      PD6         // Right turn signal
#define LED_LEFT_PIN       PD7         // Left turn signal


//------------------------------------------------------------------------------------
// Buzzer Configuration (Passive PWM buzzer)
//------------------------------------------------------------------------------------
#define BUZZER_PORT        PORTB          // Buzzer control port
#define BUZZER_DDR         DDRB           // Buzzer data direction
#define BUZZER_PIN         PB1            // Buzzer pin (PWM capable)
#define LED_STATUS_PIN     PB0         // System status LED
#define LED_STATUS_PORT         PORTB
#define LED_STATUS_DDR          DDRB
//------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------
// Analog Input Configuration
//------------------------------------------------------------------------------------
#define POTENTIOMETER_ADC_CH  0        // ADC0 - Speed control potentiometer
#define VOLTAGE_ADC_CH       1         // ADC1 - Battery voltage sensing
#define CURRENT_ADC_CH       2         // ADC2 - Current sensing
#define TEMP1_ADC_CH         3         // ADC3 - Motor 1 temperature
#define TEMP2_ADC_CH         4         // ADC4 - Motor 2 temperature
//------------------------------------------------------------------------------------
#endif /* CONFIG_H */