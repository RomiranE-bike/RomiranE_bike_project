/**
 * Button Handler Implementation v4.7
 * Last Updated: 2025-06-14
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 */

/**
 * Button Handler v1.0
 * Supports: debounce, single click, double click, hold detection
 * Uses: Timer0 systemTicks (1ms tick)
 * MCU: ATmega328P
 * Author: ROMIRAN E_BIKE
 * Date: 2025-06-13
 */
//---------------------------------------------------------------------------------------------
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdbool.h>
#include <stdint.h>
#include "button_handler.h"
#include "action_control.h"// Custom header for LED control functions/ motor-related functions/Power on/off
//---------------------------------------------------------------------------------------------
#define DEBOUNCE_TIME      5     // ms
#define DOUBLE_CLICK_TIME  10    // ms
#define HOLD_TIME          100    // ms

extern volatile uint32_t systemTicks;  // Uses main.c's tick


//---------------------------------------------------------------------------------------------
void ButtonHandler_Init(void) {
    BUTTON_DDR &= ~((1 << BUTTON_RIGHT_PIN) |
                    (1 << BUTTON_UP_PIN) |
                    (1 << BUTTON_ENTER_PIN) |
                    (1 << BUTTON_DOWN_PIN) |
                    (1 << BUTTON_LEFT_PIN));
    BUTTON_PORT |= (1 << BUTTON_RIGHT_PIN) |
                   (1 << BUTTON_UP_PIN) |
                   (1 << BUTTON_ENTER_PIN) |
                   (1 << BUTTON_DOWN_PIN) |
                   (1 << BUTTON_LEFT_PIN); // Enable pull-ups
}
//---------------------------------------------------------------------------------------------
// Internal button state
typedef struct {
    bool current;
    bool last;
    bool clicked;
    bool double_clicked;
    bool held;
    uint32_t last_change;
    uint32_t last_click;
} ButtonState;
//---------------------------------------------------------------------------------------------
static ButtonState buttons[5];
//---------------------------------------------------------------------------------------------
static bool ReadButton(uint8_t pin) {
    return !(BUTTON_PIN & (1 << pin));  // Active low
}
//---------------------------------------------------------------------------------------------
void ButtonHandler_Update(void) {
    static const uint8_t buttonPins[5] = {
        BUTTON_RIGHT_PIN, BUTTON_UP_PIN, BUTTON_ENTER_PIN, BUTTON_DOWN_PIN, BUTTON_LEFT_PIN
    };

    for (uint8_t i = 0; i < 5; i++) {
        ButtonState *btn = &buttons[i];
        bool raw = ReadButton(buttonPins[i]);
        uint32_t now = systemTicks;

        if (raw != btn->last) {
            btn->last_change = now;
            btn->last = raw;
        }

        if ((now - btn->last_change) >= DEBOUNCE_TIME) {
            if (raw != btn->current) {
                btn->current = raw;

                if (btn->current) { // Pressed	
                    if ((now - btn->last_click) < DOUBLE_CLICK_TIME) {
                        btn->double_clicked = true;
                    } else {
                        btn->clicked = true;
                    }
                    btn->last_click = now;
                    btn->held = false;
                } else { // Released
                    if ((now - btn->last_click) >= HOLD_TIME) {
                        btn->held = true;
                    }
                }
            }
        }
    }
}
//---------------------------------------------------------------------------------------------
bool Button_IsClicked(uint8_t button) {
    if (buttons[button].clicked) {
        buttons[button].clicked = false;
        return true;
    }
    return false;
}
//---------------------------------------------------------------------------------------------
bool Button_IsDoubleClicked(uint8_t button) {
    if (buttons[button].double_clicked) {
        buttons[button].double_clicked = false;
        return true;
    }
    return false;
}
//---------------------------------------------------------------------------------------------
bool Button_IsHeld(uint8_t button) {
    return buttons[button].held;
}
//---------------------------------------------------------------------------------------------

void HandleButtonEvents(void) {
	for (uint8_t btn = 0; btn < 5; btn++) {

		// Clicked Event (Single short press)
		if (Button_IsClicked(btn)) {
			 // Button click ? short, high-pitched beep
			BeepPWM_Start(15000, 1);  // 2kHz tone, 100ms 
			switch (btn) {
				case BTN_UP:    head_Led_toggle();            break; // LED_HEAD_PIN
				case BTN_DOWN:  tail_Led_blink();             break; // LED_TAIL_PIN
				case BTN_RIGHT: turn_right_led_blink();       break; // LED_RIGHT_PIN
				case BTN_LEFT:  turn_left_led_blink();        break; // LED_LEFT_PIN
				case BTN_ENTER: break_Led_toggle();           break; // LED_BRAKE_PIN + safety
				
			}
		}

		// Held Event (Button held for > hold threshold)
		if (Button_IsHeld(btn)) {
			// Button hold ? medium-pitched, longer
			BeepPWM_Start(15000, 5);  // 2kHz tone, 100ms 
			switch (btn) {
				case BTN_UP:    IncreaseSpeed();               break;
				case BTN_DOWN:  DecreaseSpeed();               break;
				case BTN_RIGHT: turn_right_led_toggle();       break;
				case BTN_LEFT:  turn_left_led_toggle();        break;
				case BTN_ENTER: Power_on_toggle();             break;
			}
		}

		// Double-Click Event
		if (Button_IsDoubleClicked(btn)) {
			// Button double-click ? low, long beep
			BeepPWM_Start(15000, 10);  // 2kHz tone, 100ms 
			switch (btn) {
				case BTN_UP:    front_motor_toggle();    break;
				case BTN_DOWN:  rear_motor_toggle();     break;
				case BTN_RIGHT:        break;
				case BTN_LEFT:         break;
				case BTN_ENTER: all_motor_toggle();      break;
			}
		}
	}
}

//---------------------------------------------------------------------------------------------
