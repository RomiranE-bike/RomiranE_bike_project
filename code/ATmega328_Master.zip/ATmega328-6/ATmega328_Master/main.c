/**
 * ATmega328 Master Controller - Main File v4.5
 * Project: BLDC-EBIKE-ATHENA-2025-06-11-V4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - Multi-layer safety system interface
 * - Dynamic performance profiles
 * - Timer/interrupt based task scheduling
 * - Five button input handling
 * - Five LED output control
 * - LCD 2x16 display interface
 * - Passive buzzer with PWM audio
 * - Sensor data acquisition
 */
//------------------------------------------------------------------------------------
#include "config.h"

//------------------------------------------------------------------------------------
// Global Variables
//------------------------------------------------------------------------------------
// Simulated system state variables
bool power_state = true;
bool m1_running = true;
bool m2_running = false;

uint8_t m1_temp = 42;
float m1_current = 5.3;

uint8_t m2_temp = 38;
float m2_current = 4.9;

uint8_t system_temp = 40;

float battery_voltage = 36.8;
float battery_current = 7.2;

uint8_t user_speed_kph = 25;

bool btn_on = true;
bool btn_stop = false;
bool btn_brake = true;
bool btn_left = true;
bool btn_right = false;
bool btn_horn = true;

//uint32_t systemTicks = 0;  // You should increment this using a timer interrupt
//Add this to your main system or timer.c:
volatile uint32_t systemTicks = 0;

//------------------------------------------------------------------------------------
// Hardware Initialization
//------------------------------------------------------------------------------------

void Hardware_Init(void) {
    // Initialize watchdog first for maximum safety
    
    // Configure GPIO directions
    
    // Initialize peripherals
    LCD_Init();
    LCD_Clear();
	buzzer_init();
    ButtonHandler_Init();
	BeepPWM_Init();
    // Setup
    LED_DDR |= (1 << LED_LEFT_PIN) | (1 << LED_BRAKE_PIN) | (1 << LED_TAIL_PIN) | (1 << LED_HEAD_PIN) | (1 << LED_RIGHT_PIN); // Output pins
    sei();          // Enable global interrupts
    Timer0_Init();  // Start system tick timer
	
}

//------------------------------------------------------------------------------------
//Configure Timer0 for 1ms overflow:
void Timer0_Init(void) {
	TCCR0A = (1 << WGM01);               // CTC mode
	TCCR0B = (1 << CS01) | (1 << CS00);  // Prescaler 64
	OCR0A = 249;                         //(With 16 MHz clock and OCR0A = 249, you get exactly 1ms per interrupt)
	TIMSK0 |= (1 << OCIE0A);             // Enable compare match A
}

//Prescaler: 64
//OCR0A: 249
//Interrupt rate: 16,000,000 / 64 / (249 + 1) = 1000 Hz ? 1 ms per tick
//------------------------------------------------------------------------------------
ISR(TIMER0_COMPA_vect) {
	systemTicks++;  // 1 ms tick
}
//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------
// Main Application Loop
//------------------------------------------------------------------------------------

int main(void) {
    // Initialize all hardware
    Hardware_Init();
	
	LCD_DisplayWelcome();
    _delay_ms(1500);         // 100 ms delay
	//buzzer_pattern(STARTUP);
	LCD_Clear();
    // Main loop
    while(1) {
		
		    
            ButtonHandler_Update(); // Update button states
			HandleButtonEvents() ;
			BeepPWM_Update(systemTicks);
            ActionControl_Update(systemTicks); // Update blinking, etc.
			
            // Update LCD display		
            LCD_DisplayPage(
            power_state, m1_running, m2_running,user_speed_kph,
            m1_temp, m1_current,m2_temp, m2_current,
            system_temp,battery_voltage, battery_current,
            btn_on, btn_stop, btn_brake,
            btn_left, btn_right, btn_horn
            );

		 // Example: Do something with current speed
		 uint8_t current_speed = get_speed_value();
		 // ... maybe display it or use for PWM control logic

		 _delay_ms(10); // Optional sleep if button system is not interrupt-based	
        // Optionally delay a bit to reduce CPU usage
        _delay_ms(10);  // Or just run fast if using systemTicks properly
    }
}
//------------------------------------------------------------------------------------