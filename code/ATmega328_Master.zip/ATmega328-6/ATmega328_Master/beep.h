/*
 * beep.h
 *
 * Created: 6/1/2024 15:31:26
 *  editor: me
 */ 
//--------------------------------------------------------------------------------------------------------------
#ifndef BEEP_H_
#define BEEP_H_

//--------------------------------------------------------------------------------------------------------------
#include <avr/io.h>
#include <util/delay.h>
//#include "config.h"
//--------------------------------------------------------------------------------------------------------------

// Configuration constants
#define D_BLINK  2000   // blink delay in ms
#define D_BEEP   2000   // beep half-cycle delay in us
#define F_BEEP    500   // beep frequency (number of toggle cycles)

//------------------------------------------------------------------------------------
// Buzzer Configuration (Passive PWM buzzer)
//------------------------------------------------------------------------------------
#define BUZZER_PORT        PORTB          // Buzzer control port
#define BUZZER_DDR         DDRB           // Buzzer data direction
#define BUZZER_PIN         PB1            // Buzzer pin (PWM capable)
#define LED_STATUS_PIN     PB0         // System status LED
#define LED_STATUS_PORT         PORTB
#define LED_STATUS_DDR          DDRB
//------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------------

// Function declarations
void beep(void);
void blink(void);
void alarm(void);
//--------------------------------------------------------------------------------------------------------------

// Blink routine
void blink(void) {
	//LED_STATUS_DDR |= (1 << LED_STATUS_PIN);           // Set LED pin as output
	LED_STATUS_PORT |= (1 << LED_STATUS_PIN);          // Turn ON LED
	_delay_ms(D_BLINK);                                // Delay
	LED_STATUS_PORT &= ~(1 << LED_STATUS_PIN);         // Turn OFF LED
	_delay_ms(D_BLINK);                                // Delay
}

// Beep routine
void beep(void) {
	//BUZZER_DDR |= (1 << BUZZER_PIN);                   // Set BUZZER pin as output
	for (int i = 0; i < F_BEEP; i++) {
		BUZZER_PORT |= (1 << BUZZER_PIN);              // BUZZER ON
		_delay_us(D_BEEP);                             // Delay
		BUZZER_PORT &= ~(1 << BUZZER_PIN);             // BUZZER OFF
		_delay_us(D_BEEP);                             // Delay
	}
}

// Alarm routine (combined beep + blink)
void alarm(void) {
	for (int i = 0; i < 50; i++) {
		beep();
		blink();
		_delay_ms(10);
	}
}
//--------------------------------------------------------------------------------------------------------------
#endif // BEEP_H_
