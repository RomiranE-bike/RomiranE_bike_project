/*
 * action_control.h
 *
 * Created: 6/13/2025 20:28:08
 *  Author: User
 */ 

//------------------------------------------------------------------------------------
#ifndef ACTION_CONTROL_H_
#define ACTION_CONTROL_H_
//------------------------------------------------------------------------------------
#include "config.h"
#include <stdint.h>
#include <stdbool.h>

//------------------------------------------------------------------------------------
void StatusLED_On(void);
void StatusLED_Off(void);
void StatusLED_Toggle(void);
//------------------------------------------------------------------------------------
// Lighting functions
void head_Led_toggle(void);
void break_Led_toggle(void);
void turn_right_led_toggle(void);
void turn_left_led_toggle(void);
void tail_Led_blink(void);
void turn_right_led_blink(void);
void turn_left_led_blink(void);
//------------------------------------------------------------------------------------
// Motor functions
void IncreaseSpeed(void);
void DecreaseSpeed(void);
void all_motor_stop(void);
bool front_motor_toggle(void);
bool rear_motor_toggle(void);
bool all_motor_toggle(void);
//------------------------------------------------------------------------------------
// Power functions
bool Power_on_toggle(void);
bool is_power_on(void);
//------------------------------------------------------------------------------------
// Timing (to be called regularly in main loop or via timer interrupt)
void ActionControl_Update(uint32_t systemTicks);
//------------------------------------------------------------------------------------
bool is_front_motor_on(void);     // M1
bool is_rear_motor_on(void);      // M2
uint8_t get_speed_value(void);
uint8_t get_motor1_temp(void);
uint8_t get_motor2_temp(void);
float get_motor1_current(void);
float get_motor2_current(void);
uint8_t get_system_temp(void);
float get_battery_voltage(void);
float get_battery_current(void);
//------------------------------------------------------------------------------------
#endif /* ACTION_CONTROL_H_ */
//------------------------------------------------------------------------------------