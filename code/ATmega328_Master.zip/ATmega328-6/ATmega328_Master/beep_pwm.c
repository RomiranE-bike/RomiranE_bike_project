/*
 * beep_pwm.c
 *
 * Created: 6/15/2025 18:21:10
 *  Author: User
 */ 
#include "beep_pwm.h"
#include "config.h"
#include <avr/io.h>

static bool beep_active = false;
static uint32_t beep_start_time = 0;
static uint16_t beep_duration_ms = 0;

void BeepPWM_Init(void) {
	// Set PB1 (OC1A) and optional PB0 (LED) as output
	LED_STATUS_DDR |=  (1 << LED_STATUS_PIN);
	LED_STATUS_PORT &= ~ (1 << LED_STATUS_PIN);
	BUZZER_DDR |= (1 << BUZZER_PIN) ;
	BUZZER_PORT &= ~(1 << BUZZER_PIN);
}

void BeepPWM_Start(uint16_t freqHz, uint16_t durationMs) {
	if (freqHz == 0 || durationMs == 0) return;

	uint16_t top = (F_CPU / (2UL * 8UL * freqHz)) - 1; // Using prescaler 8

	TCCR1A = (1 << COM1A0);               // Toggle OC1A on Compare Match
	TCCR1B = (1 << WGM12) | (1 << CS11); // CTC mode, Prescaler 8
	OCR1A = top;

	beep_start_time = 0;
	beep_duration_ms = durationMs;
	beep_active = true;

	PORTB |= (1 << LED_STATUS_PIN); // Optional LED on
}

void BeepPWM_Update(uint32_t systemTicks) {
	if (!beep_active) return;

	if (beep_start_time == 0) {
		beep_start_time = systemTicks;
	}

	if ((systemTicks - beep_start_time) >= beep_duration_ms) {
		// Stop timer
		TCCR1A = 0;
		TCCR1B = 0;
		BUZZER_PORT &= ~(1 << LED_STATUS_PIN);
		LED_STATUS_PORT &= ~(1 << LED_STATUS_PIN);
		beep_active = false;
	}
}

bool BeepPWM_IsActive(void) {
	return beep_active;
}
