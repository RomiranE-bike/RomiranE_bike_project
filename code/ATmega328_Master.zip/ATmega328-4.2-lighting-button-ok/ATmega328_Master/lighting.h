/**
 * Intelligent Lighting System v5.1
 * Features:
 * - Day/Night mode toggle
 * - Left/Right turn signals with auto-cancel
 * - Brake light override
 * - LCD status display
 * - Buzzer feedback
 * - Interrupt-driven design
 */

#ifndef LIGHTING_H
#define LIGHTING_H

#include <avr/io.h>
#include <stdbool.h>
#include "config.h"
#include "lcd.h"
#include "status_buzzer.h"

// enum for system lighting mode
typedef enum {
    MODE_DAY,
    MODE_NIGHT
} SystemMode;

// enum for light state
typedef enum {
    LIGHT_OFF,
    LIGHT_ON,
    LIGHT_BLINK
} LightState;

// Public interface
void Lighting_Init(void);
void Lighting_Update(void);
void Lighting_DisplayStatus(void);

#endif // LIGHTING_H
//---------------------------------------------------------------------------------------------------------