/**
 * Intelligent Lighting System v5.1
 * Features:
 * - Hardware timer-based debouncing
 * - Day/Night mode toggle
 * - Turn signals with auto-cancel
 * - Brake light override
 * - LCD status display
 */
//---------------------------------------------------------------------------------------------------------
#include "lighting.h"
#include <avr/interrupt.h>
#include <util/delay.h>
//---------------------------------------------------------------------------------------------------------
// System State
static volatile SystemMode current_mode = MODE_DAY;
static volatile LightState brake_state = LIGHT_OFF;
static volatile LightState left_signal = LIGHT_OFF;
static volatile LightState right_signal = LIGHT_OFF;

// Timing Counters
static volatile uint8_t blink_counter = 0;
static volatile bool blink_state = false;
static volatile uint16_t signal_timeout = 0;

// Debounce timers and stable states
#define DEBOUNCE_DELAY_MS 20
volatile uint8_t debounce_timer[4] = {0};
volatile bool button_stable_state[4] = {1, 1, 1, 1};
//---------------------------------------------------------------------------------------------------------
// Button Indices
#define BTN_MODE_INDEX   0
#define BTN_BRAKE_INDEX  1
#define BTN_LEFT_INDEX   2
#define BTN_RIGHT_INDEX  3
//---------------------------------------------------------------------------------------------------------
/**
 * Initialize lighting hardware and timers
 */
void Lighting_Init(void) {
    // Configure LED outputs
    DDRD |= (1 << HEAD_LIGHT_PIN) | (1 << TAIL_LIGHT_PIN) |
            (1 << LEFT_LIGHT_PIN) | (1 << RIGHT_LIGHT_PIN);

    // Configure buttons with pull-ups
    DDRC &= ~((1 << MODE_BTN_PIN) | (1 << BRAKE_BTN_PIN) |
              (1 << LEFT_BTN_PIN) | (1 << RIGHT_BTN_PIN));
    PORTC |= (1 << MODE_BTN_PIN) | (1 << BRAKE_BTN_PIN) |
             (1 << LEFT_BTN_PIN) | (1 << RIGHT_BTN_PIN);

    // Timer0 for blinking and debounce (CTC mode, 1ms interval)
    TCCR0A = (1 << WGM01);  // CTC mode
    TCCR0B = (1 << CS01) | (1 << CS00);  // Prescaler 64
    OCR0A = 249;  // 1ms at 16MHz / 64
    TIMSK0 = (1 << OCIE0A);

    // Enable pin change interrupts for buttons
    PCICR |= (1 << PCIE1);
    PCMSK1 |= (1 << PCINT8) | (1 << PCINT9) | (1 << PCINT10) | (1 << PCINT11);

    sei();  // Enable global interrupts
}
//---------------------------------------------------------------------------------------------------------
/**
 * Update all lighting outputs based on current state
 */
void Lighting_Update(void) {
    // Headlight control
    if(current_mode == MODE_NIGHT) {
        PORTD |= (1 << HEAD_LIGHT_PIN);
    } else {
        PORTD &= ~(1 << HEAD_LIGHT_PIN);
    }

    // Brake light (overrides taillight)
    if(brake_state == LIGHT_ON) {
        PORTD |= (1 << TAIL_LIGHT_PIN);
    } 
    // Taillight blinking in night mode
    else if(current_mode == MODE_NIGHT && blink_state) {
        PORTD |= (1 << TAIL_LIGHT_PIN);
    } else {
        PORTD &= ~(1 << TAIL_LIGHT_PIN);
    }

    // Turn signals
    if(left_signal == LIGHT_BLINK && blink_state) {
        PORTD |= (1 << LEFT_LIGHT_PIN);
    } else {
        PORTD &= ~(1 << LEFT_LIGHT_PIN);
    }

    if(right_signal == LIGHT_BLINK && blink_state) {
        PORTD |= (1 << RIGHT_LIGHT_PIN);
    } else {
        PORTD &= ~(1 << RIGHT_LIGHT_PIN);
    }
}
//---------------------------------------------------------------------------------------------------------
/**
 * Update LCD display with current lighting status
 */
void Update_Display(void) {
    lcd_goto(0, 0);
    lcd_print("Mode:");
    lcd_print(current_mode == MODE_DAY ? "DAY " : "NIGHT");

    lcd_goto(0, 1);
    lcd_print("L:");
    lcd_print(left_signal == LIGHT_OFF ? "OFF " : "BLNK");
    lcd_print(" R:");
    lcd_print(right_signal == LIGHT_OFF ? "OFF" : "BLNK");

    lcd_goto(10, 0);
    lcd_print("BRK:");
    lcd_print(brake_state == LIGHT_ON ? "ON" : "OFF");
}
//---------------------------------------------------------------------------------------------------------
// Timer0 Compare Match A ISR (1ms interval)
ISR(TIMER0_COMPA_vect) {
    static uint16_t blink_ms = 0;

				// Decrement debounce timers
				for (uint8_t i = 0; i < 4; i++) {
					if (debounce_timer[i] > 0) debounce_timer[i]--;
					}

				// Blink toggle every 10ms
				if (++blink_ms >= 10) {
					blink_state = !blink_state;
					blink_ms = 0;

					// Auto-cancel signals after 10 seconds (20 blinks)
					if(left_signal == LIGHT_BLINK || right_signal == LIGHT_BLINK) {
						if(++signal_timeout >= 100) {
							left_signal = LIGHT_OFF;
							right_signal = LIGHT_OFF;
							signal_timeout = 0;
							}
							}

					Lighting_Update();
					Update_Display();
					}

    // Debounce actions
    if (debounce_timer[BTN_MODE_INDEX] == 0 && !(PINC & (1 << MODE_BTN_PIN)) && button_stable_state[BTN_MODE_INDEX]) {
        current_mode = (current_mode == MODE_DAY) ? MODE_NIGHT : MODE_DAY;
        buzzer_pattern(BEEP);
        button_stable_state[BTN_MODE_INDEX] = false;
    } else if (PINC & (1 << MODE_BTN_PIN)) {
        button_stable_state[BTN_MODE_INDEX] = true;
    }

    if (debounce_timer[BTN_BRAKE_INDEX] == 0 && !(PINC & (1 << BRAKE_BTN_PIN)) && button_stable_state[BTN_BRAKE_INDEX]) {
        brake_state = (brake_state == LIGHT_OFF) ? LIGHT_ON : LIGHT_OFF;
        buzzer_pattern(BEEP);
        button_stable_state[BTN_BRAKE_INDEX] = false;
    } else if (PINC & (1 << BRAKE_BTN_PIN)) {
        button_stable_state[BTN_BRAKE_INDEX] = true;
    }

    if (debounce_timer[BTN_LEFT_INDEX] == 0 && !(PINC & (1 << LEFT_BTN_PIN)) && button_stable_state[BTN_LEFT_INDEX]) {
        left_signal = (left_signal == LIGHT_OFF) ? LIGHT_BLINK : LIGHT_OFF;
        if(left_signal == LIGHT_BLINK) right_signal = LIGHT_OFF;
        signal_timeout = 0;
        buzzer_pattern(BEEP);
        button_stable_state[BTN_LEFT_INDEX] = false;
    } else if (PINC & (1 << LEFT_BTN_PIN)) {
        button_stable_state[BTN_LEFT_INDEX] = true;
    }

    if (debounce_timer[BTN_RIGHT_INDEX] == 0 && !(PINC & (1 << RIGHT_BTN_PIN)) && button_stable_state[BTN_RIGHT_INDEX]) {
        right_signal = (right_signal == LIGHT_OFF) ? LIGHT_BLINK : LIGHT_OFF;
        if(right_signal == LIGHT_BLINK) left_signal = LIGHT_OFF;
        signal_timeout = 0;
        buzzer_pattern(BEEP);
        button_stable_state[BTN_RIGHT_INDEX] = false;
    } else if (PINC & (1 << RIGHT_BTN_PIN)) {
        button_stable_state[BTN_RIGHT_INDEX] = true;
    }
}
//---------------------------------------------------------------------------------------------------------
// Pin Change Interrupt for buttons (start debounce only)
ISR(PCINT1_vect) {
    static uint8_t last_state = 0xFF;
    uint8_t current_state = PINC;

    if ((last_state & (1 << MODE_BTN_PIN)) && !(current_state & (1 << MODE_BTN_PIN))) {
        debounce_timer[BTN_MODE_INDEX] = DEBOUNCE_DELAY_MS;
    }
    if ((last_state & (1 << BRAKE_BTN_PIN)) && !(current_state & (1 << BRAKE_BTN_PIN))) {
        debounce_timer[BTN_BRAKE_INDEX] = DEBOUNCE_DELAY_MS;
    }
    if ((last_state & (1 << LEFT_BTN_PIN)) && !(current_state & (1 << LEFT_BTN_PIN))) {
        debounce_timer[BTN_LEFT_INDEX] = DEBOUNCE_DELAY_MS;
    }
    if ((last_state & (1 << RIGHT_BTN_PIN)) && !(current_state & (1 << RIGHT_BTN_PIN))) {
        debounce_timer[BTN_RIGHT_INDEX] = DEBOUNCE_DELAY_MS;
    }

    last_state = current_state;
}
//---------------------------------------------------------------------------------------------------------