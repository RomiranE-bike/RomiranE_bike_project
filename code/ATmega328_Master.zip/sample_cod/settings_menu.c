#include "settings_menu.h"
#include "display_menu.h"
#include "eeprom.h"
#include "motor_control.h"
#include "safety.h"

// Versioned settings structure to handle future updates
typedef struct {
    uint8_t version;        // Settings structure version (1)
    uint8_t torque_curve;   // 0-3 (Mild to Aggressive)
    uint8_t regen_level;    // 0-2 (None to Strong)
    uint8_t max_speed;      // 0-100% of system max
    uint8_t throttle_ramp;  // 0-2 (Slow to Fast)
    uint16_t checksum;
} UserSettings_t;

static UserSettings_t current_settings;

// Default settings if EEPROM is empty/corrupt
static const UserSettings_t DEFAULT_SETTINGS = {
    .version = 1,
    .torque_curve = 1,      // Moderate curve
    .regen_level = 1,       // Medium regen
    .max_speed = 80,        // 80% of max speed
    .throttle_ramp = 1,     // Medium ramp rate
    .checksum = 0
};

/**
 * @brief Calculate settings checksum
 * @param settings Pointer to settings structure
 * @return 16-bit checksum
 */
static uint16_t calculate_checksum(const UserSettings_t* settings) {
    const uint8_t* data = (const uint8_t*)settings;
    uint16_t sum = 0;
    
    // Calculate sum of all bytes except checksum
    for(size_t i = 0; i < offsetof(UserSettings_t, checksum); i++) {
        sum += data[i];
    }
    
    return ~sum; // Return 1's complement
}

void settings_load(void) {
    // Read from EEPROM
    eeprom_read_block(&current_settings, EEPROM_SETTINGS_ADDR, sizeof(current_settings));
    
    // Validate settings
    bool settings_valid = true;
    
    // Check version and checksum
    if(current_settings.version != 1 || 
       calculate_checksum(&current_settings) != current_settings.checksum) {
        settings_valid = false;
    }
    
    // Validate parameter ranges
    if(current_settings.torque_curve > 3 ||
       current_settings.regen_level > 2 ||
       current_settings.max_speed > 100 ||
       current_settings.throttle_ramp > 2) {
        settings_valid = false;
    }
    
    // Load defaults if invalid
    if(!settings_valid) {
        current_settings = DEFAULT_SETTINGS;
        current_settings.checksum = calculate_checksum(&current_settings);
        settings_save(); // Write back defaults
    }
}

void settings_save(void) {
    // Update checksum before saving
    current_settings.checksum = calculate_checksum(&current_settings);
    
    // Write to EEPROM
    eeprom_update_block(&current_settings, EEPROM_SETTINGS_ADDR, sizeof(current_settings));
}

/**
 * @brief Apply mode-specific settings to motor controllers
 * @param mode Selected ride mode
 */
void settings_apply_mode(RideMode mode) {
    // Validate mode parameter
    if(mode >= MODE_COUNT) {
        mode = MODE_NORMAL; // Fallback to normal mode
    }
    
    // Common safety limits
    motor_set_current_limit(SAFE_CURRENT_LIMIT);
    
    // Mode-specific configurations
    switch(mode) {
        case MODE_ECO:
            // 70% torque, full regen, speed limited
            motor_set_torque_curve(current_settings.torque_curve * 0.7f);
            motor_set_regen(current_settings.regen_level);
            motor_set_speed_limit(current_settings.max_speed * 0.8f);
            motor_set_throttle_ramp(current_settings.throttle_ramp + 1); // Slower ramp
            break;
            
        case MODE_SPORT:
            // 130% torque, no regen, full speed
            motor_set_torque_curve(current_settings.torque_curve * 1.3f);
            motor_set_regen(0);
            motor_set_speed_limit(100); // No speed limit
            motor_set_throttle_ramp(current_settings.throttle_ramp); // Normal ramp
            break;
            
        case MODE_NORMAL:
        default:
            // 100% torque, normal regen, user speed limit
            motor_set_torque_curve(current_settings.torque_curve);
            motor_set_regen(current_settings.regen_level);
            motor_set_speed_limit(current_settings.max_speed);
            motor_set_throttle_ramp(current_settings.throttle_ramp); // Normal ramp
            break;
    }
    
    // Update display and indicators
    display_update_ride_mode(mode);
}

/**
 * @brief Reset all settings to factory defaults
 */
void settings_reset_to_defaults(void) {
    current_settings = DEFAULT_SETTINGS;
    current_settings.checksum = calculate_checksum(&current_settings);
    settings_save();
}

/**
 * @brief Get current torque curve setting
 * @return Torque curve level (0-3)
 */
uint8_t settings_get_torque_curve(void) {
    return current_settings.torque_curve;
}

/**
 * @brief Set new torque curve setting
 * @param level New torque curve level (0-3)
 * @return True if value was valid and set
 */
bool settings_set_torque_curve(uint8_t level) {
    if(level > 3) return false;
    
    current_settings.torque_curve = level;
    return true;
}