#ifndef EEPROM_H
#define EEPROM_H

#include <stdint.h>
#include <stdbool.h>

#define EEPROM_SETTINGS_VERSION 1

bool eeprom_init(void);
bool eeprom_is_valid(void);
bool eeprom_read_settings(void* data, uint16_t size);
bool eeprom_write_settings(const void* data, uint16_t size);
bool eeprom_clear_all(void);
bool eeprom_log_fault(FaultCode fault);

// Diagnostic functions
uint16_t eeprom_calculate_checksum(const void* data, uint16_t size);
bool eeprom_test(void);

#endif