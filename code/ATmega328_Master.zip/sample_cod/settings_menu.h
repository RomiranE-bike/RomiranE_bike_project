#ifndef SETTINGS_MENU_H
#define SETTINGS_MENU_H

#include "config.h"

typedef enum {
    TORQUE_CURVE_MILD = 0,
    TORQUE_CURVE_MODERATE,
    TORQUE_CURVE_AGGRESSIVE,
    TORQUE_CURVE_MAX
} TorqueCurveLevel;

typedef enum {
    REGEN_DISABLED = 0,
    REGEN_LIGHT,
    REGEN_STRONG,
    REGEN_MAX_LEVEL
} RegenLevel;

typedef struct {
    uint8_t version;
    TorqueCurveLevel torque_curve;
    RegenLevel regen_level;
    uint8_t max_speed_pct;  // 0-100%
    uint8_t throttle_response;
    uint16_t checksum;
} UserSettings;

void settings_init(void);
bool settings_load(void);
bool settings_save(void);
void settings_apply_mode(RideMode mode);
void settings_reset_factory_defaults(void);

// Getters
TorqueCurveLevel settings_get_torque_curve(void);
RegenLevel settings_get_regen_level(void);
uint8_t settings_get_max_speed(void);
uint8_t settings_get_throttle_response(void);

// Setters
bool settings_set_torque_curve(TorqueCurveLevel level);
bool settings_set_regen_level(RegenLevel level);
bool settings_set_max_speed(uint8_t pct);
bool settings_set_throttle_response(uint8_t level);

#endif