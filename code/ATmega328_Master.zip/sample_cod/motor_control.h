#ifndef MOTOR_CONTROL_H
#define MOTOR_CONTROL_H

#include "config.h"

typedef struct {
    float current;
    float speed_rpm;
    float temperature;
    uint8_t faults;
} MotorData;

void motor_init(void);
bool motor_enable(void);
bool motor_disable(void);
void motor_set_torque_curve(TorqueCurveLevel curve);
void motor_set_regen_level(RegenLevel level);
void motor_set_speed_limit(uint8_t percent);
void motor_set_throttle_response(uint8_t level);
void motor_emergency_stop(void);

// Status getters
MotorData motor_get_data(uint8_t motor_id);
bool motor_is_ready(uint8_t motor_id);
uint8 motor_get_faults(uint8_t motor_id);

#endif