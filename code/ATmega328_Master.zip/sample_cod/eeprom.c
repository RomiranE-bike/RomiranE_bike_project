#include "eeprom.h"
#include <avr/eeprom.h>

#define EEPROM_MAGIC_NUMBER 0xAA55
#define EEPROM_SETTINGS_OFFSET sizeof(uint16_t)

bool eeprom_init(void) {
    uint16_t magic;
    eeprom_read_block(&magic, 0, sizeof(magic));
    return (magic == EEPROM_MAGIC_NUMBER);
}

bool eeprom_write_settings(const void* data, uint16_t size) {
    // Write magic number if not present
    uint16_t magic = EEPROM_MAGIC_NUMBER;
    eeprom_update_block(&magic, 0, sizeof(magic));
    
    // Write settings
    eeprom_update_block(data, (void*)EEPROM_SETTINGS_OFFSET, size);
    return true;
}