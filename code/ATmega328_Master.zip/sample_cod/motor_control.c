#include "motor_control.h"
#include "foc.h"
#include "safety.h"

static MotorData motors[2];

void motor_init(void) {
    memset(motors, 0, sizeof(motors));
    foc_init();
}

void motor_set_torque_curve(TorqueCurveLevel curve) {
    // Convert enum to actual torque mapping parameters
    const float kp_gains[] = {0.5f, 1.0f, 1.5f};
    foc_set_kp(kp_gains[curve]);
}