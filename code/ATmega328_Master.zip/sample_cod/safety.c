#include "safety.h"

static struct {
    float max_current;
    float max_temp;
    float min_voltage;
    uint8_t active_faults;
} safety;

void safety_init(void) {
    safety.max_current = MAX_CURRENT_NORMAL;
    safety.max_temp = MAX_TEMPERATURE;
    safety.min_voltage = MIN_VOLTAGE;
    safety.active_faults = 0;
}

void safety_monitor(void) {
    MotorData m1 = motor_get_data(0);
    MotorData m2 = motor_get_data(1);
    
    // Current check
    if(m1.current > safety.max_current || 
       m2.current > safety.max_current) {
        safety_trigger_fault(FAULT_OVERCURRENT);
    }
    
    // Temperature check
    if(m1.temperature > safety.max_temp ||
       m2.temperature > safety.max_temp) {
        safety_trigger_fault(FAULT_OVERTEMP);
    }
}