#include "display_menu.h"
#include "settings_menu.h"
#include "motor_control.h"
#include <string.h>

static uint8_t current_menu = 0;
static uint8_t selected_item = 0;

void display_update_main(RideMode mode, const BatteryData* batt, 
                        const MotorData* m1, const MotorData* m2) {
    char buffer[20];
    
    // Display mode
    lcd_set_cursor(0, 0);
    switch(mode) {
        case MODE_ECO: lcd_print("ECO "); break;
        case MODE_NORMAL: lcd_print("NORM"); break;
        case MODE_SPORT: lcd_print("SPRT"); break;
    }
    
    // Battery info
    snprintf(buffer, sizeof(buffer), "%2.1fV %3d%%", 
             batt->voltage, batt->charge_pct);
    lcd_print(buffer);
    
    // Motor data
    lcd_set_cursor(0, 1);
    snprintf(buffer, sizeof(buffer), "M1:%4.0fRPM %2.1fA", 
             m1->speed_rpm, m1->current);
    lcd_print(buffer);
}