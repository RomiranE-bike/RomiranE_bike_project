#ifndef SAFETY_H
#define SAFETY_H

#include "config.h"

typedef enum {
    FAULT_NONE = 0,
    FAULT_OVERCURRENT,
    FAULT_OVERTEMP,
    FAULT_UNDERVOLTAGE,
    FAULT_COMMS,
    FAULT_MAX
} FaultType;

void safety_init(void);
void safety_monitor(void);
bool safety_check_system(void);
void safety_trigger_fault(FaultType fault);
void safety_clear_faults(void);
bool safety_is_fault_active(FaultType fault);

// Configuration
void safety_set_limits(float max_current, float max_temp, float min_voltage);
void safety_get_limits(float* max_current, float* max_temp, float* min_voltage);

#endif