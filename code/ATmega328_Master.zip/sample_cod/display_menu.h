#ifndef DISPLAY_MENU_H
#define DISPLAY_MENU_H

#include "config.h"

void display_init(void);
void display_show_splash(void);
void display_update_main(RideMode mode, const BatteryData* batt, 
                        const MotorData* m1, const MotorData* m2);
void display_show_menu(uint8_t selected_item);
void display_show_settings(const UserSettings* settings);
void display_show_fault(FaultCode fault);
void display_show_message(const char* msg);
void display_clear(void);

// Navigation
void display_scroll_up(void);
void display_scroll_down(void);
void display_select_item(void);
void display_back(void);

#endif