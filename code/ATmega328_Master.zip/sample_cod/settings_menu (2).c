#include "settings_menu.h"
#include "eeprom.h"
#include "motor_control.h"
#include "safety.h"
#include <string.h>

static UserSettings current_settings;
static const UserSettings factory_defaults = {
    .version = EEPROM_SETTINGS_VERSION,
    .torque_curve = TORQUE_CURVE_MODERATE,
    .regen_level = REGEN_LIGHT,
    .max_speed_pct = 80,
    .throttle_response = 1,
    .checksum = 0
};

void settings_init(void) {
    if(!settings_load()) {
        settings_reset_factory_defaults();
    }
}

bool settings_load(void) {
    if(!eeprom_read_settings(&current_settings, sizeof(UserSettings))) {
        return false;
    }
    
    // Validate settings
    if(current_settings.version != EEPROM_SETTINGS_VERSION ||
       current_settings.torque_curve >= TORQUE_CURVE_MAX ||
       current_settings.regen_level >= REGEN_MAX_LEVEL ||
       current_settings.max_speed_pct > 100) {
        return false;
    }
    
    return true;
}

bool settings_save(void) {
    current_settings.checksum = eeprom_calculate_checksum(
        &current_settings, 
        offsetof(UserSettings, checksum)
    );
    return eeprom_write_settings(&current_settings, sizeof(UserSettings));
}

void settings_apply_mode(RideMode mode) {
    float speed_limit = (float)current_settings.max_speed_pct / 100.0f;
    float torque_scale = 1.0f;
    
    switch(mode) {
        case MODE_ECO:
            torque_scale = 0.7f;
            speed_limit *= 0.8f; // Additional 20% reduction in eco mode
            break;
        case MODE_SPORT:
            torque_scale = 1.3f;
            speed_limit = 1.0f; // No limit in sport mode
            break;
        default:
            torque_scale = 1.0f;
            break;
    }
    
    motor_set_torque_curve(current_settings.torque_curve);
    motor_set_regen_level((mode == MODE_SPORT) ? REGEN_DISABLED : current_settings.regen_level);
    motor_set_speed_limit(speed_limit);
    motor_set_throttle_response(current_settings.throttle_response);
    
    // Apply safety limits based on mode
    safety_set_limits(
        (mode == MODE_SPORT) ? MAX_CURRENT_SPORT : MAX_CURRENT_NORMAL,
        MAX_TEMPERATURE,
        MIN_VOLTAGE
    );
}