/**
 * Intelligent Lighting System v5.1
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - Day/Night mode automatic switching
 * - Turn signals with auto-cancel timer
 * - Brake light priority override
 * - LCD status display integration
 * - Audible feedback via buzzer
 * - Interrupt-driven PWM dimming
 * - Energy-efficient operation
 */

#ifndef LIGHTING_H
#define LIGHTING_H

//------------------------------------------------------------------------------------
// System Includes
//------------------------------------------------------------------------------------
#include <avr/io.h>
#include <stdbool.h>
#include "config.h"
#include "lcd.h"
#include "status_buzzer.h"

//------------------------------------------------------------------------------------
// Lighting Mode Definitions
//------------------------------------------------------------------------------------
typedef enum {
    MODE_DAY = 0,       // Daylight operation (reduced brightness)
    MODE_NIGHT,         // Nighttime operation (full brightness)
    MODE_AUTO           // Automatic light detection
} SystemMode;

//------------------------------------------------------------------------------------
// Light State Definitions
//------------------------------------------------------------------------------------
typedef enum {
    LIGHT_OFF = 0,      // Light completely off
    LIGHT_ON,           // Light fully on
    LIGHT_BLINK_SLOW,   // Slow blinking (1Hz)
    LIGHT_BLINK_FAST,   // Fast blinking (2Hz)
    LIGHT_DIM           // Reduced brightness (PWM)
} LightState;

//------------------------------------------------------------------------------------
// Lighting Channel Definitions
//------------------------------------------------------------------------------------
typedef enum {
    CHANNEL_HEADLIGHT = 0,
    CHANNEL_TAILLIGHT,
    CHANNEL_LEFT_TURN,
    CHANNEL_RIGHT_TURN,
    CHANNEL_BRAKE,
    CHANNEL_COUNT
} LightChannel;

//------------------------------------------------------------------------------------
// Public Function Prototypes
//------------------------------------------------------------------------------------

/**
 * @brief Initialize lighting system hardware
 * Configures:
 * - GPIO pins for light outputs
 * - PWM timers for dimming control
 * - Light sensor input (if available)
 */
void Lighting_Init(void);

/**
 * @brief Update lighting system state
 * Should be called from main control loop
 * Handles:
 * - Mode transitions
 * - Turn signal timing
 * - Brake light priority
 * - Automatic day/night switching
 */
void Lighting_Update(void);

/**
 * @brief Display current lighting status on LCD
 * Shows:
 * - Current mode (day/night/auto)
 * - Active turn signals
 * - Light status (on/off/dim)
 */
void Lighting_DisplayStatus(void);

/**
 * @brief Set lighting system mode
 * @param mode Desired system mode (day/night/auto)
 */
void Lighting_SetMode(SystemMode mode);

/**
 * @brief Activate turn signal
 * @param side 0 for left, 1 for right
 * @param duration_ms How long to blink (0 for manual cancel)
 */
void Lighting_ActivateTurnSignal(uint8_t side, uint16_t duration_ms);

/**
 * @brief Control brake light
 * @param state True to activate brake light
 */
void Lighting_SetBrakeLight(bool state);

/**
 * @brief Get current lighting mode
 * @return Active system mode
 */
SystemMode Lighting_GetCurrentMode(void);

#endif /* LIGHTING_H */