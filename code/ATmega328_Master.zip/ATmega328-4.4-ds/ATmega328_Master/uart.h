/**
 * UART Communication Driver v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - Full-duplex communication
 * - Interrupt-driven operation
 * - Dual buffering
 * - Error handling
 */

#ifndef UART_H
#define UART_H

#include <stdint.h>

//------------------------------------------------------------------------------------
// Buffer Size Definitions
//------------------------------------------------------------------------------------
#define UART_RX_BUFFER_SIZE 128
#define UART_TX_BUFFER_SIZE 128

//------------------------------------------------------------------------------------
// Error Code Definitions
//------------------------------------------------------------------------------------
#define UART_ERROR_NONE      0x00
#define UART_ERROR_OVERRUN   0x01
#define UART_ERROR_FRAME     0x02
#define UART_ERROR_PARITY    0x04
#define UART_ERROR_BUFFER    0x08

//------------------------------------------------------------------------------------
// Public Function Prototypes
//------------------------------------------------------------------------------------

/**
 * @brief Initialize UART with specified baud rate
 * @param baud Desired baud rate
 */
void UART_Init(uint32_t baud);

/**
 * @brief Send single character
 * @param c Character to send
 */
void UART_Putc(char c);

/**
 * @brief Send null-terminated string
 * @param str String to send
 */
void UART_Puts(const char *str);

/**
 * @brief Receive single character (blocking)
 * @return Received character
 */
char UART_Getc(void);

/**
 * @brief Check number of bytes available in receive buffer
 * @return Number of bytes available
 */
uint16_t UART_Available(void);

/**
 * @brief Flush receive buffer
 */
void UART_Flush(void);

/**
 * @brief Send telemetry data to motor controllers
 */
void UART_SendTelemetry(void);

/**
 * @brief Get last UART error status
 * @return Bitmask of error flags
 */
uint8_t UART_GetErrors(void);

#endif /* UART_H */