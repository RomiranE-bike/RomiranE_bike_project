/**
 * LCD 2x16 Driver v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - 4-bit interface mode
 * - Optimized for HD44780 compatible displays
 * - Custom character support
 * - Multi-line text display
 */

#ifndef LCD_H
#define LCD_H

#include <stdint.h>
#include <stdbool.h>

//------------------------------------------------------------------------------------
// LCD Command Definitions
//------------------------------------------------------------------------------------
#define LCD_CLEAR_DISPLAY   0x01
#define LCD_RETURN_HOME     0x02
#define LCD_ENTRY_MODE_SET  0x04
#define LCD_DISPLAY_CONTROL 0x08
#define LCD_CURSOR_SHIFT    0x10
#define LCD_FUNCTION_SET    0x20
#define LCD_SET_CGRAM_ADDR  0x40
#define LCD_SET_DDRAM_ADDR  0x80

//------------------------------------------------------------------------------------
// Display Entry Mode Flags
//------------------------------------------------------------------------------------
#define LCD_ENTRY_RIGHT     0x00
#define LCD_ENTRY_LEFT      0x02
#define LCD_ENTRY_SHIFT_ON  0x01
#define LCD_ENTRY_SHIFT_OFF 0x00

//------------------------------------------------------------------------------------
// Display Control Flags
//------------------------------------------------------------------------------------
#define LCD_DISPLAY_ON      0x04
#define LCD_DISPLAY_OFF     0x00
#define LCD_CURSOR_ON       0x02
#define LCD_CURSOR_OFF      0x00
#define LCD_BLINK_ON        0x01
#define LCD_BLINK_OFF       0x00

//------------------------------------------------------------------------------------
// Function Set Flags
//------------------------------------------------------------------------------------
#define LCD_4BIT_MODE       0x00
#define LCD_2LINE_MODE      0x08
#define LCD_5x8_DOTS        0x00

//------------------------------------------------------------------------------------
// Public Function Prototypes
//------------------------------------------------------------------------------------

/**
 * @brief Initialize the LCD in 4-bit mode
 * Configures GPIO and sends initialization sequence
 */
void LCD_Init(void);

/**
 * @brief Clear the LCD display and return cursor to home
 */
void LCD_Clear(void);

/**
 * @brief Set cursor position
 * @param row Line number (0-1)
 * @param col Position in line (0-15)
 */
void LCD_SetCursor(uint8_t row, uint8_t col);

/**
 * @brief Write a single character to LCD
 * @param data Character to display
 */
void LCD_WriteChar(char data);

/**
 * @brief Write a null-terminated string to LCD
 * @param str String to display
 */
void LCD_WriteString(const char *str);

/**
 * @brief Display welcome message on startup
 */
void LCD_DisplayWelcome(void);

/**
 * @brief Update LCD with current system status
 */
void LCD_UpdateDisplay(void);

/**
 * @brief Create custom character in CGRAM
 * @param location CGRAM location (0-7)
 * @param charmap 8-byte character pattern
 */
void LCD_CreateChar(uint8_t location, uint8_t charmap[]);

#endif /* LCD_H */