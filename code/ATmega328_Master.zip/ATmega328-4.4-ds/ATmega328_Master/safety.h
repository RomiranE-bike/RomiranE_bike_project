/**
 * Safety Monitoring System v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - Real-time parameter monitoring
 * - Configurable thresholds
 * - Predictive fault detection
 * - Multi-level protection
 */

#ifndef SAFETY_H
#define SAFETY_H

#include <stdbool.h>

//------------------------------------------------------------------------------------
// Safety Limit Structure
//------------------------------------------------------------------------------------
typedef struct {
    float max_current;      // Maximum allowed current (A)
    float max_temp;         // Maximum temperature (°C)
    float min_voltage;      // Minimum battery voltage (V)
    float max_speed;        // Maximum speed (RPM)
} SafetyLimits;

//------------------------------------------------------------------------------------
// Public Function Prototypes
//------------------------------------------------------------------------------------

/**
 * @brief Initialize safety monitoring system
 */
void Safety_Init(void);

/**
 * @brief Monitor all safety parameters
 * Called periodically from main loop
 */
void Safety_Monitor(void);

/**
 * @brief Check overall system safety
 * @return True if all parameters within limits
 */
bool Safety_CheckSystem(void);

/**
 * @brief Set safety limits
 * @param max_current Maximum allowed current (A)
 * @param max_temp Maximum temperature (°C)
 * @param min_voltage Minimum battery voltage (V)
 */
void Safety_SetLimits(float max_current, float max_temp, float min_voltage);

/**
 * @brief Get current safety limits
 * @param limits Pointer to limits structure
 */
void Safety_GetLimits(SafetyLimits *limits);

/**
 * @brief Check if safety system is in critical state
 * @return True if any parameter in critical range
 */
bool Safety_IsCritical(void);

#endif /* SAFETY_H */