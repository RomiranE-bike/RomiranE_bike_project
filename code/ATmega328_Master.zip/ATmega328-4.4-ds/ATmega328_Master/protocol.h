/**
 * Communication Protocol v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - Robust packet structure
 * - CRC error checking
 * - Command/response system
 * - Fault reporting
 */

#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <stdint.h>

//------------------------------------------------------------------------------------
// Packet Structure (Byte-aligned)
//------------------------------------------------------------------------------------
#pragma pack(push, 1)
typedef struct {
    uint8_t start_byte;    // 0xAA (packet start marker)
    uint8_t destination;   // Device address (0 = broadcast)
    uint8_t command;       // Command byte
    uint8_t length;        // Payload length (0-16)
    uint8_t data[16];      // Command payload
    uint8_t crc;           // CRC-8 checksum
} MotorPacket;
#pragma pack(pop)

//------------------------------------------------------------------------------------
// Command Definitions
//------------------------------------------------------------------------------------
#define CMD_SET_SPEED      0x01  // Set motor speed (RPM)
#define CMD_SET_TORQUE     0x02  // Set motor torque (0.1Nm)
#define CMD_GET_STATUS     0x03  // Request status update
#define CMD_FAULT_REPORT   0x04  // Fault notification
#define CMD_ACK            0x05  // Acknowledge
#define CMD_NACK           0x06  // Negative acknowledge
#define CMD_PING           0x07  // Connectivity test
#define CMD_CONFIG         0x08  // Configuration update

//------------------------------------------------------------------------------------
// Response Code Definitions
//------------------------------------------------------------------------------------
#define RESP_SUCCESS       0x00
#define RESP_INVALID_CMD   0x01
#define RESP_CRC_ERROR     0x02
#define RESP_LENGTH_ERROR  0x03
#define RESP_BUSY         0x04
#define RESP_FAULT        0x05

//------------------------------------------------------------------------------------
// Public Function Prototypes
//------------------------------------------------------------------------------------

/**
 * @brief Calculate CRC-8 checksum
 * @param data Pointer to data buffer
 * @param length Number of bytes to process
 * @return Calculated checksum
 */
uint8_t Protocol_CalculateCRC(const uint8_t *data, uint8_t length);

/**
 * @brief Validate packet structure and checksum
 * @param packet Packet to validate
 * @return True if packet is valid
 */
bool Protocol_ValidatePacket(const MotorPacket *packet);

/**
 * @brief Build command packet
 * @param packet Pointer to packet structure
 * @param command Command to send
 * @param data Command payload
 * @param length Payload length
 */
void Protocol_BuildPacket(MotorPacket *packet, uint8_t command, const uint8_t *data, uint8_t length);

/**
 * @brief Send packet to specified device
 * @param packet Packet to send
 * @return True if transmission started successfully
 */
bool Protocol_SendPacket(const MotorPacket *packet);

/**
 * @brief Receive packet (non-blocking)
 * @param packet Pointer to receive buffer
 * @return True if valid packet received
 */
bool Protocol_ReceivePacket(MotorPacket *packet);

#endif /* PROTOCOL_H */