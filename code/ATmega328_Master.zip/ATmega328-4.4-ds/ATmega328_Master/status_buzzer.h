/**
 * Status Buzzer Controller v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - PWM-based tone generation
 * - Predefined audio patterns
 * - Volume control
 * - Non-blocking operation
 */

#ifndef STATUS_BUZZER_H
#define STATUS_BUZZER_H

//------------------------------------------------------------------------------------
// Status Sound Definitions
//------------------------------------------------------------------------------------
typedef enum {
    STATUS_STARTUP = 0,    // System power-on sequence
    STATUS_SHUTDOWN,       // System power-off
    STATUS_BUTTON_PRESS,   // Button feedback
    STATUS_WARNING,        // Non-critical alert
    STATUS_ALARM,          // Critical fault
    STATUS_TURN_SIGNAL,    // Turn indicator beep
    STATUS_MODE_CHANGE     // Profile change confirmation
} StatusSound;

//------------------------------------------------------------------------------------
// Public Function Prototypes
//------------------------------------------------------------------------------------

/**
 * @brief Initialize buzzer hardware and PWM timer
 */
void StatusBuzzer_Init(void);

/**
 * @brief Trigger a status sound pattern
 * @param sound Which sound pattern to play
 */
void StatusBuzzer_Trigger(StatusSound sound);

/**
 * @brief Update buzzer state (call periodically)
 * Handles tone duration and automatic turn-off
 */
void StatusBuzzer_Update(void);

/**
 * @brief Set buzzer volume
 * @param volume 0-100 percentage
 */
void StatusBuzzer_SetVolume(uint8_t volume);

/**
 * @brief Stop any currently playing sound immediately
 */
void StatusBuzzer_Stop(void);

#endif /* STATUS_BUZZER_H */