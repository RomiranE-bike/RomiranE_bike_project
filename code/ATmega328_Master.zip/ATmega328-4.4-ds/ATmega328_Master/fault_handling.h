/**
 * Fault Management System v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - Multi-level fault handling
 * - Persistent error logging
 * - Automatic recovery
 * - User notification
 */

#ifndef FAULT_HANDLING_H
#define FAULT_HANDLING_H

#include <stdint.h>

//------------------------------------------------------------------------------------
// Fault Type Definitions
//------------------------------------------------------------------------------------
typedef enum {
    FAULT_NONE = 0,
    FAULT_OVERCURRENT,      // Excessive current draw
    FAULT_OVERTEMP,         // Motor/Battery overheating
    FAULT_UNDERVOLTAGE,     // Low battery voltage
    FAULT_COMMS,            // Communication failure
    FAULT_THROTTLE,         // Throttle sensor error
    FAULT_BRAKE,            // Brake sensor conflict
    FAULT_MOTOR1,           // Motor 1 specific fault
    FAULT_MOTOR2,           // Motor 2 specific fault
    FAULT_EEPROM,           // Memory corruption
    FAULT_COUNT             // Total fault types
} FaultType;

//------------------------------------------------------------------------------------
// Fault Severity Levels
//------------------------------------------------------------------------------------
typedef enum {
    SEVERITY_INFO = 0,      // Log only
    SEVERITY_WARNING,       // User notification
    SEVERITY_CRITICAL,      // Performance limited
    SEVERITY_FATAL          // System shutdown
} FaultSeverity;

//------------------------------------------------------------------------------------
// Public Function Prototypes
//------------------------------------------------------------------------------------

/**
 * @brief Initialize fault handling system
 */
void Fault_Init(void);

/**
 * @brief Process active faults
 * Called from safety system loop
 */
void Fault_Handler_Process(void);

/**
 * @brief Trigger new fault condition
 * @param fault Type of fault
 * @param severity How serious the fault is
 */
void Fault_Trigger(FaultType fault, FaultSeverity severity);

/**
 * @brief Clear specific fault condition
 * @param fault Fault type to clear
 */
void Fault_Clear(FaultType fault);

/**
 * @brief Check if fault is active
 * @param fault Fault type to check
 * @return True if fault is active
 */
bool Fault_IsActive(FaultType fault);

/**
 * @brief Get fault count
 * @return Number of active faults
 */
uint8_t Fault_GetCount(void);

#endif /* FAULT_HANDLING_H */