/**
 * System State Manager v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - Dual-motor synchronization tracking
 * - EEPROM wear-leveling
 * - State machine management
 * - Power profile management
 */

#ifndef SYSTEM_STATE_H
#define SYSTEM_STATE_H

#include <stdint.h>

//------------------------------------------------------------------------------------
// Global System Variables
//------------------------------------------------------------------------------------
extern volatile uint32_t system_tick;   // Milliseconds since boot
extern volatile uint8_t control_loop_flag;

//------------------------------------------------------------------------------------
// System State Machine
//------------------------------------------------------------------------------------
typedef enum {
    STATE_BOOT = 0,     // System booting up
    STATE_LOCKED,       // System locked (security)
    STATE_READY,        // System ready for operation
    STATE_RIDING,       // System in normal operation
    STATE_FAULT         // System in fault condition
} SystemState;

//------------------------------------------------------------------------------------
// Motor Telemetry Structure
//------------------------------------------------------------------------------------
typedef struct {
    float speed_rpm;    // Current motor speed in RPM
    float current_a;    // Current motor current in Amps
    uint8_t temp_c;     // Motor temperature in Celsius
    uint8_t fault_code; // Motor fault code (if any)
} MotorData;

//------------------------------------------------------------------------------------
// System State Structure
//------------------------------------------------------------------------------------
typedef struct {
    SystemState current_state; // Current system state
    float battery_voltage;     // Current battery voltage
    float battery_current;     // Current battery current
    MotorData motor[2];        // Dual motor support
    uint8_t pending_faults;    // Bitmask of pending faults
    uint8_t performance_mode;  // Current performance mode
} SystemState_t;

//------------------------------------------------------------------------------------
// Performance Profile Enum
//------------------------------------------------------------------------------------
typedef enum {
    PROFILE_ECO = 0,       // 70% max power (energy saving)
    PROFILE_NORMAL,        // 100% power (default mode)
    PROFILE_SPORT,         // 120% power (temporary boost)
    PROFILE_BOOST          // 150% power (30s limit, thermal derating)
} PerformanceProfile;

//------------------------------------------------------------------------------------
// Power Management Structure
//------------------------------------------------------------------------------------
typedef struct {
    PerformanceProfile mode;           // Current performance profile
    float current_scale;               // Current scaling factor
    uint8_t temp_limit_derate;         // 0-100% Derating based on temp
    uint32_t boost_end_time;           // Time when boost mode ends
} PowerManagement;

//------------------------------------------------------------------------------------
// Public Function Prototypes
//------------------------------------------------------------------------------------
void SystemState_Init(void);
void SystemState_Update(void);
const char* SystemState_GetName(SystemState state);
void Set_Performance_Profile(PerformanceProfile profile);
void Update_Thermal_Derating(uint8_t temp_c);
void Update_Power_Profile(void);

#endif /* SYSTEM_STATE_H */