/**
 * Sensor Acquisition Module v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - Unified interface for all analog sensors
 * - Automatic calibration
 * - Noise filtering
 * - Fault detection
 */

#ifndef SENSORS_H
#define SENSORS_H

//------------------------------------------------------------------------------------
// Sensor Channel Definitions
//------------------------------------------------------------------------------------
typedef enum {
    SENSOR_BATTERY_VOLTAGE = 0,  // Main battery voltage (0-60V)
    SENSOR_BATTERY_CURRENT,       // Battery current (-30A to +30A)
    SENSOR_MOTOR1_TEMP,           // Motor 1 temperature (NTC)
    SENSOR_MOTOR2_TEMP,           // Motor 2 temperature (NTC)
    SENSOR_THROTTLE,              // Throttle position (potentiometer)
    SENSOR_COUNT                  // Total number of sensors
} SensorChannel;

//------------------------------------------------------------------------------------
// Calibration Structure
//------------------------------------------------------------------------------------
typedef struct {
    float scale;        // Scaling factor
    float offset;       // Zero offset
    float min_value;    // Minimum expected value
    float max_value;    // Maximum expected value
} SensorCalibration;

//------------------------------------------------------------------------------------
// Public Function Prototypes
//------------------------------------------------------------------------------------

/**
 * @brief Initialize all sensors and ADC
 */
void Sensors_Init(void);

/**
 * @brief Read current value from specified sensor
 * @param channel Which sensor to read
 * @return Filtered and calibrated sensor value
 */
float Sensors_Read(SensorChannel channel);

/**
 * @brief Calibrate sensor against known value
 * @param channel Sensor to calibrate
 * @param known_value Reference value for calibration
 * @return True if calibration succeeded
 */
bool Sensors_Calibrate(SensorChannel channel, float known_value);

/**
 * @brief Perform self-test on all sensors
 * @return Bitmask of faulty sensors (0 = OK)
 */
uint8_t Sensors_SelfTest(void);

/**
 * @brief Get pointer to calibration data
 * @param channel Sensor to access
 * @return Pointer to calibration structure
 */
SensorCalibration* Sensors_GetCalibration(SensorChannel channel);

#endif /* SENSORS_H */