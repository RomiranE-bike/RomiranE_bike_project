/**
 * Watchdog Timer Manager v4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - Hardware watchdog timer
 * - Windowed operation
 * - System reset on timeout
 * - Fault recovery
 */

#ifndef WATCHDOG_H
#define WATCHDOG_H

//------------------------------------------------------------------------------------
// Watchdog Timeout Periods
//------------------------------------------------------------------------------------
typedef enum {
    WDT_16MS = 0,
    WDT_32MS,
    WDT_64MS,
    WDT_125MS,
    WDT_250MS,
    WDT_500MS,
    WDT_1S,
    WDT_2S,
    WDT_4S,
    WDT_8S
} WDT_Period;

//------------------------------------------------------------------------------------
// Public Function Prototypes
//------------------------------------------------------------------------------------

/**
 * @brief Initialize watchdog timer
 * @param period Timeout period selection
 */
void WDT_Init(WDT_Period period);

/**
 * @brief Reset watchdog timer
 * Must be called before timeout to prevent reset
 */
void WDT_Reset(void);

/**
 * @brief Enable watchdog timer
 */
void WDT_Enable(void);

/**
 * @brief Disable watchdog timer
 */
void WDT_Disable(void);

/**
 * @brief Force system reset via watchdog
 */
void WDT_ForceReset(void);

#endif /* WATCHDOG_H */