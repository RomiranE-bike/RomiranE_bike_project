/**
 * ATmega328 Master Controller - Main File v4.5
 * Project: BLDC-EBIKE-ATHENA-2025-06-11-V4.5
 * Last Updated: 2025-06-11 14:30
 * Author: ROMIRAN E_BIKE, DeepSeek AI
 * 
 * Features:
 * - Multi-layer safety system interface
 * - Dynamic performance profiles
 * - Timer/interrupt based task scheduling
 * - Five button input handling
 * - Five LED output control
 * - LCD 2x16 display interface
 * - Passive buzzer with PWM audio
 * - Sensor data acquisition
 */

#include "config.h"
#include "system_state.h"
#include "motor_control.h"
#include "sensors.h"
#include "lcd.h"
#include "led.h"
#include "status_buzzer.h"
#include "watchdog.h"
#include "eeprom.h"
#include "safety.h"
#include "security.h"
#include "uart.h"
#include <avr/interrupt.h>
#include <util/delay.h>

//------------------------------------------------------------------------------------
// Global Variables
//------------------------------------------------------------------------------------
volatile uint32_t system_tick = 0;     // Milliseconds since boot
volatile uint8_t control_loop_flag = 0; // Control loop execution flag
SystemState_t system_state;            // Global system state structure
#define SAFETY_CHECK_HZ 10  // 10 Hz safety check (every 100ms)
//------------------------------------------------------------------------------------
// Interrupt Service Routines
//------------------------------------------------------------------------------------

/**
 * @brief Timer1 Compare A Interrupt (1ms system tick)
 * Handles:
 * - System timekeeping
 * - Control loop timing
 * - Button debouncing timing
 */
ISR(TIMER1_COMPA_vect) {
    system_tick++;
    
    // Set control loop flag at 100Hz (every 10ms)
    if(system_tick % (1000/CONTROL_LOOP_HZ) == 0) {
        control_loop_flag = 1;
    }
}

//------------------------------------------------------------------------------------
// Hardware Initialization
//------------------------------------------------------------------------------------

/**
 * @brief Initialize all hardware peripherals
 * Configures:
 * - GPIO pins
 * - Timers
 * - ADC
 * - Communication interfaces
 * - System clocks
 */
void Hardware_Init(void) {
    // Initialize watchdog first for maximum safety
    WDT_Init(WDT_500MS);  // or another timeout, like WDTO_500MS, WDTO_2S, etc.
    
    // Configure GPIO directions
    LCD_DDR |= (1<<LCD_RS_PIN)|(1<<LCD_EN_PIN)|(1<<LCD_D4_PIN)|(1<<LCD_D5_PIN)|(1<<LCD_D6_PIN)|(1<<LCD_D7_PIN);
    DDRD |= (1<<LED_LEFT_PIN)|(1<<LED_RIGHT_PIN)|(1<<LED_BRAKE_PIN)|(1<<LED_STATUS_PIN);
    BUZZER_DDR |= (1<<BUZZER_PIN);
    
    // Initialize peripherals
    LCD_Init();
    LED_Init();
    StatusBuzzer_Init();
    Sensors_Init();
    MotorControl_Init();
    SystemState_Init();
    UART_Init(9600);  // Initialize UART with 9600 baud
    Security_Init();
    Safety_Init();
    
    // Configure Timer1 for 1ms interrupts
    TCCR1B |= (1<<WGM12) | (1<<CS11) | (1<<CS10); // CTC mode, prescaler 64
    OCR1A = 249; // 16MHz/64/250 = 1000Hz (1ms)
    TIMSK1 |= (1<<OCIE1A); // Enable compare match interrupt
    
    // Enable global interrupts
    sei();
    
    // Load settings from EEPROM
    EEPROM_LoadSettings();
}

//------------------------------------------------------------------------------------
// Main Application Loop
//------------------------------------------------------------------------------------

int main(void) {
    // Initialize all hardware
    Hardware_Init();
    
    // Startup sequence
    StatusBuzzer_Trigger(STATUS_STARTUP);
    LCD_DisplayWelcome();
    
    // Timing variables
    uint32_t last_telemetry = 0;
    uint32_t last_safety_check = 0;
    uint32_t last_display_update = 0;
    
    // Main loop
    while(1) {
        WDT_Reset();  // Must be called at least every 8s
        
        //--------------------------------------------------------------------------------
        // 100Hz Control Loop (Timer Interrupt Driven)
        //--------------------------------------------------------------------------------
        if(control_loop_flag) {
            control_loop_flag = 0;
            
            // Read all sensors
            system_state.battery_voltage = Sensors_Read(SENSOR_BATTERY_VOLTAGE);
            system_state.battery_current = Sensors_Read(SENSOR_BATTERY_CURRENT);
            system_state.motor[0].temp_c = (uint8_t)Sensors_Read(SENSOR_MOTOR1_TEMP);
            system_state.motor[1].temp_c = (uint8_t)Sensors_Read(SENSOR_MOTOR2_TEMP);
            
            // Update motor control
            MotorControl_Update();
            
            // Update system state machine
            SystemState_Update();
            
            // Handle button inputs
            Button_Handler();
        }
        
        //--------------------------------------------------------------------------------
        // 10Hz Safety System (Timer Based)
        //--------------------------------------------------------------------------------
        if(system_tick - last_safety_check >= (1000/SAFETY_CHECK_HZ)) {
            last_safety_check = system_tick;
            
            // Check all safety parameters
            Safety_Monitor();
            
            // Process any pending faults
            if(system_state.pending_faults) {
                Fault_Handler_Process();
            }
            
            // Update power profile based on conditions
            Update_Power_Profile();
        }
        
        //--------------------------------------------------------------------------------
        // 1Hz Telemetry Updates (Timer Based)
        //--------------------------------------------------------------------------------
        if(system_tick - last_telemetry >= TELEMETRY_INTERVAL_MS) {
            last_telemetry = system_tick;
            
            // Send telemetry data over UART
            UART_SendTelemetry();
            
            // Update EEPROM if values changed
            EEPROM_CheckSave();
        }
        
        //--------------------------------------------------------------------------------
        // 5Hz Display Updates (Timer Based)
        //--------------------------------------------------------------------------------
        if(system_tick - last_display_update >= 200) { // 5Hz
            last_display_update = system_tick;
            
            // Update LCD display
            LCD_UpdateDisplay();
        }
        
        _delay_us(50);  // Reduce CPU load
    }
}