#ifndef CONFIG_H
#define CONFIG_H

#include <avr/io.h>
#include <stdint.h>
#include <avr/interrupt.h>
#include <stdbool.h>
//------------------------------------------------------------------------------------
// System Configuration
#define F_CPU 16000000UL
//------------------------------------------------------------------------------------
// LCD Pin Configuration - Using PORTB
#define LCD_RS_PIN   PB2  // Register Select (Command/Data)
#define LCD_EN_PIN   PB3  // Enable pin
#define LCD_D4_PIN   PB4  // Data bit 4
#define LCD_D5_PIN   PB5  // Data bit 5
#define LCD_D6_PIN   PB6  // Data bit 6
#define LCD_D7_PIN   PB7  // Data bit 7
#define LCD_PORT     PORTB  // Port register
#define LCD_DDR      DDRB   // Data direction register
//------------------------------------------------------------------------------------
// Button Inputs - PORTC
#define BUTTON_PORT         PINC
#define BUTTON_UP_PIN       PC0
#define BUTTON_DOWN_PIN     PC1
#define BUTTON_OK_PIN       PC2
#define BUTTON_BACK_PIN     PC3
//------------------------------------------------------------------------------------
// Output Pins - BUZZER & LIGHTS
#define BUZZER_PORT     PORTB
#define BUZZER_DDR      DDRB
#define BUZZER_PIN      PB1
#define STATUS_LED_PIN  PB0

// LED Pin Definitions
#define HEAD_LIGHT_PIN   PD6  // D6 (OC0A)
#define TAIL_LIGHT_PIN   PD5  // D5 (OC0B)
#define BRAKE_LIGHT_PIN  PD5  // Shared with taillight
#define LEFT_LIGHT_PIN   PD7  // D7
#define RIGHT_LIGHT_PIN  PD4  // D4
#define HAZARD_IND_PIN   PD5  // Shared

// Button Pins
#define MODE_BTN_PIN     PC0
#define BRAKE_BTN_PIN    PC1
#define LEFT_BTN_PIN     PC2
#define RIGHT_BTN_PIN    PC3
//-----------------------------------------------------------------------------------
#endif // CONFIG_H
//-----------------------------------------------------------------------------------
