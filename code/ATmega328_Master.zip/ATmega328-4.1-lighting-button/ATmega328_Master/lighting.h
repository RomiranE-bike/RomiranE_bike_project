/**
 * Intelligent Lighting System v5.1
 * Features:
 * - Hardware timer-based debouncing
 * - Day/Night mode toggle
 * - Turn signals with auto-cancel
 * - Brake light override
 * - LCD status display
 */

//---------------------------------------------------------------------------------------------------------
#ifndef LIGHTING_H
#define LIGHTING_H
//---------------------------------------------------------------------------------------------------------
#include <avr/io.h>
#include <stdbool.h>
#include "config.h"
#include "lcd.h"
#include "status_buzzer.h"
//---------------------------------------------------------------------------------------------------------
// System Modes
typedef enum {
	MODE_DAY,
	MODE_NIGHT
} SystemMode;
//---------------------------------------------------------------------------------------------------------
// Button States
typedef enum {
	BTN_IDLE,
	BTN_PRESSED,
	BTN_DEBOUNCING
} ButtonState;
//---------------------------------------------------------------------------------------------------------
void Lighting_Init(void);
void Lighting_Update(void);

#endif
//---------------------------------------------------------------------------------------------------------