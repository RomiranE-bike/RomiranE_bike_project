/**
 * Intelligent Lighting System v5.0
 * Features:
 * - Day/Night mode toggle
 * - Left/Right turn signals with auto-cancel
 * - Brake light override
 * - LCD status display
 * - Buzzer feedback
 * - Interrupt-driven operation
 */
//---------------------------------------------------------------------------------------------------------
#ifndef LIGHTING_H
#define LIGHTING_H
//---------------------------------------------------------------------------------------------------------
#include <avr/io.h>
#include <stdbool.h>
#include "config.h"
#include "lcd.h"
#include "status_buzzer.h"
//---------------------------------------------------------------------------------------------------------
// System Modes
typedef enum {
    MODE_DAY,
    MODE_NIGHT
} SystemMode;
//---------------------------------------------------------------------------------------------------------
// Lighting States
typedef enum {
    LIGHT_OFF,
    LIGHT_ON,
    LIGHT_BLINK
} LightState;
//---------------------------------------------------------------------------------------------------------
void Lighting_Init(void);
void Lighting_Update(void);

#endif
//---------------------------------------------------------------------------------------------------------