/**
 * Intelligent Lighting System v5.0
 * Features:
 * - Day/Night mode toggle
 * - Left/Right turn signals with auto-cancel
 * - Brake light override
 * - LCD status display
 * - Buzzer feedback
 * - Interrupt-driven operation
 */
//---------------------------------------------------------------------------------------------------------
#include "lighting.h"
#include <avr/interrupt.h>
#include <util/delay.h>
//---------------------------------------------------------------------------------------------------------
// System State
static volatile SystemMode current_mode = MODE_DAY;
static volatile LightState brake_state = LIGHT_OFF;
static volatile LightState left_signal = LIGHT_OFF;
static volatile LightState right_signal = LIGHT_OFF;

// Timing Counters
static volatile uint8_t blink_counter = 0;
static volatile bool blink_state = false;
static volatile uint16_t signal_timeout = 0;

// Button States
static volatile bool mode_btn_pressed = false;
static volatile bool brake_btn_pressed = false;
static volatile bool left_btn_pressed = false;
static volatile bool right_btn_pressed = false;
//---------------------------------------------------------------------------------------------------------
/**
 * Initialize lighting hardware and timers
 */
void Lighting_Init(void) {
    // Configure LED outputs
    DDRD |= (1 << HEAD_LIGHT_PIN) | (1 << TAIL_LIGHT_PIN) |
            (1 << LEFT_LIGHT_PIN) | (1 << RIGHT_LIGHT_PIN);
    
    // Configure buttons with pull-ups
    DDRC &= ~((1 << MODE_BTN_PIN) | (1 << BRAKE_BTN_PIN) |
            (1 << LEFT_BTN_PIN) | (1 << RIGHT_BTN_PIN));
    PORTC |= (1 << MODE_BTN_PIN) | (1 << BRAKE_BTN_PIN) |
             (1 << LEFT_BTN_PIN) | (1 << RIGHT_BTN_PIN);
    
    // Timer0 for blinking (CTC mode, 500ms interval)
    TCCR0A = (1 << WGM01);  // CTC mode
    TCCR0B = (1 << CS02) | (1 << CS00);  // 1024 prescaler
    OCR0A = 78;  // 500ms at 16MHz/1024
    TIMSK0 = (1 << OCIE0A);
    
    // Enable pin change interrupts for buttons
    PCICR |= (1 << PCIE1);
    PCMSK1 |= (1 << PCINT8) | (1 << PCINT9) | (1 << PCINT10) | (1 << PCINT11);
    
    sei();  // Enable global interrupts
}
//---------------------------------------------------------------------------------------------------------
/**
 * Update all lighting outputs based on current state
 */
void Lighting_Update(void) {
    // Headlight control
    if(current_mode == MODE_NIGHT) {
        PORTD |= (1 << HEAD_LIGHT_PIN);
    } else {
        PORTD &= ~(1 << HEAD_LIGHT_PIN);
    }
    
    // Brake light (overrides taillight)
    if(brake_state == LIGHT_ON) {
        PORTD |= (1 << TAIL_LIGHT_PIN);
    } 
    // Taillight blinking in night mode
    else if(current_mode == MODE_NIGHT && blink_state) {
        PORTD |= (1 << TAIL_LIGHT_PIN);
    } else {
        PORTD &= ~(1 << TAIL_LIGHT_PIN);
    }
    
    // Turn signals
    if(left_signal == LIGHT_BLINK && blink_state) {
        PORTD |= (1 << LEFT_LIGHT_PIN);
    } else {
        PORTD &= ~(1 << LEFT_LIGHT_PIN);
    }
    
    if(right_signal == LIGHT_BLINK && blink_state) {
        PORTD |= (1 << RIGHT_LIGHT_PIN);
    } else {
        PORTD &= ~(1 << RIGHT_LIGHT_PIN);
    }
}
//---------------------------------------------------------------------------------------------------------
/**
 * Update LCD display with current lighting status
 */
void Update_Display(void) {
    lcd_goto(0, 0);
    lcd_print("Mode:");
    lcd_print(current_mode == MODE_DAY ? "DAY " : "NIGHT");
    
    lcd_goto(0, 1);
    lcd_print("L:");
    lcd_print(left_signal == LIGHT_OFF ? "OFF " : "BLNK");
    lcd_print(" R:");
    lcd_print(right_signal == LIGHT_OFF ? "OFF" : "BLNK");
    
    lcd_goto(10, 0);
    lcd_print("BRK:");
    lcd_print(brake_state == LIGHT_ON ? "ON" : "OFF");
}
//---------------------------------------------------------------------------------------------------------
// Timer0 Compare Match A ISR (500ms interval)
ISR(TIMER0_COMPA_vect) {
    blink_state = !blink_state;  // Toggle blink state
    
    // Auto-cancel signals after 10 seconds (20 blinks)
    if(left_signal == LIGHT_BLINK || right_signal == LIGHT_BLINK) {
        if(++signal_timeout >= 200) {
            left_signal = LIGHT_OFF;
            right_signal = LIGHT_OFF;
            signal_timeout = 0;
        }
    }
    
    Lighting_Update();
    Update_Display();
}
//---------------------------------------------------------------------------------------------------------
// Pin Change Interrupt for buttons
ISR(PCINT1_vect) {
    static uint8_t last_state = 0xFF;
    uint8_t current_state = PINC;
    
    // Mode button (PC0)
    if((last_state & (1 << MODE_BTN_PIN)) && !(current_state & (1 << MODE_BTN_PIN))) {
        mode_btn_pressed = true;
        current_mode = (current_mode == MODE_DAY) ? MODE_NIGHT : MODE_DAY;
        buzzer_pattern(BEEP);
    }
    
    // Brake button (PC1)
    if((last_state & (1 << BRAKE_BTN_PIN)) && !(current_state & (1 << BRAKE_BTN_PIN))) {
        brake_btn_pressed = true;
        brake_state = (brake_state == LIGHT_OFF) ? LIGHT_ON : LIGHT_OFF;
        buzzer_pattern(BEEP);
    }
    
    // Left signal (PC2)
    if((last_state & (1 << LEFT_BTN_PIN)) && !(current_state & (1 << LEFT_BTN_PIN))) {
        left_btn_pressed = true;
        left_signal = (left_signal == LIGHT_OFF) ? LIGHT_BLINK : LIGHT_OFF;
        if(left_signal == LIGHT_BLINK) right_signal = LIGHT_OFF;
        signal_timeout = 0;
        buzzer_pattern(BEEP);
    }
    
    // Right signal (PC3)
    if((last_state & (1 << RIGHT_BTN_PIN)) && !(current_state & (1 << RIGHT_BTN_PIN))) {
        right_btn_pressed = true;
        right_signal = (right_signal == LIGHT_OFF) ? LIGHT_BLINK : LIGHT_OFF;
        if(right_signal == LIGHT_BLINK) left_signal = LIGHT_OFF;
        signal_timeout = 0;
        buzzer_pattern(BEEP);
    }
    
    last_state = current_state;
}
//---------------------------------------------------------------------------------------------------------