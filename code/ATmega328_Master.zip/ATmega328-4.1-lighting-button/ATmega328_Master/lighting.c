/**
 * Intelligent Lighting System v5.1
 * Features:
 * - Hardware timer-based debouncing
 * - Day/Night mode toggle
 * - Turn signals with auto-cancel
 * - Brake light override
 * - LCD status display
 */
//---------------------------------------------------------------------------------------------------------
#include "lighting.h"
#include <avr/interrupt.h>
//---------------------------------------------------------------------------------------------------------
// System State
static volatile SystemMode current_mode = MODE_DAY;
static volatile bool brake_active = false;
static volatile bool left_signal = false;
static volatile bool right_signal = false;
//---------------------------------------------------------------------------------------------------------
// Timing Control
static volatile uint8_t blink_counter = 0;
static volatile bool blink_state = false;
static volatile uint16_t signal_timeout = 0;
//---------------------------------------------------------------------------------------------------------
// Debounce Engine
#define DEBOUNCE_TICKS 5  // ~50ms at 100Hz check rate
typedef struct {
	ButtonState state;
	uint8_t counter;
	bool last_phys_state;
} Button;
//---------------------------------------------------------------------------------------------------------
static volatile Button buttons[4] = {0};  // Mode, Brake, Left, Right
//---------------------------------------------------------------------------------------------------------
// Timer0 Compare Match ISR (100Hz - 10ms interval)
ISR(TIMER0_COMPA_vect) {
	// Blink control (500ms period)
	if(++blink_counter >= 50) {
		blink_counter = 0;
		blink_state = !blink_state;
		
		// Auto-cancel signals after 10s (20 blinks)
		if(left_signal || right_signal) {
			if(++signal_timeout >= 20) {
				left_signal = right_signal = false;
				signal_timeout = 0;
			}
		}
	}
	
	// Button state machine (runs at 100Hz)
	for(uint8_t i = 0; i < 4; i++) {
		bool curr_phys_state = !(PINC & (1 << (MODE_BTN_PIN + i)));  // Active-low
		
		switch(buttons[i].state) {
			case BTN_IDLE:
			if(curr_phys_state != buttons[i].last_phys_state) {
				buttons[i].state = BTN_DEBOUNCING;
				buttons[i].counter = DEBOUNCE_TICKS;
			}
			break;
			
			case BTN_DEBOUNCING:
			if(--buttons[i].counter == 0) {
				buttons[i].state = BTN_IDLE;
				if(curr_phys_state) {
					buttons[i].state = BTN_PRESSED;
					handle_button_press(i);  // Process valid press
				}
			}
			break;
			
			case BTN_PRESSED:
			if(!curr_phys_state) {
				buttons[i].state = BTN_IDLE;
			}
			break;
		}
		buttons[i].last_phys_state = curr_phys_state;
	}
	
	Lighting_Update();  // Refresh outputs
}
//---------------------------------------------------------------------------------------------------------
void handle_button_press(uint8_t btn_id) {
	switch(btn_id) {
		case 0:  // Mode button
		current_mode = (current_mode == MODE_DAY) ? MODE_NIGHT : MODE_DAY;
		buzzer_pattern(BEEP);
		break;
		
		case 1:  // Brake button
		brake_active = !brake_active;
		break;
		
		case 2:  // Left signal
		left_signal = !left_signal;
		if(left_signal) right_signal = false;
		signal_timeout = 0;
		break;
		
		case 3:  // Right signal
		right_signal = !right_signal;
		if(right_signal) left_signal = false;
		signal_timeout = 0;
		break;
	}
}
//---------------------------------------------------------------------------------------------------------
void Lighting_Init(void) {
	// Configure LED outputs
	DDRD |= (1 << HEAD_LIGHT_PIN) | (1 << TAIL_LIGHT_PIN) |
	(1 << LEFT_LIGHT_PIN) | (1 << RIGHT_LIGHT_PIN);
	
	// Button inputs with pull-ups
	DDRC &= ~((1 << MODE_BTN_PIN) | (1 << BRAKE_BTN_PIN) |
	(1 << LEFT_BTN_PIN) | (1 << RIGHT_BTN_PIN));
	PORTC |= (1 << MODE_BTN_PIN) | (1 << BRAKE_BTN_PIN) |
	(1 << LEFT_BTN_PIN) | (1 << RIGHT_BTN_PIN);
	
	// Timer0 for debounce and blinking (CTC mode, 10ms interval)
	TCCR0A = (1 << WGM01);             // CTC mode
	OCR0A = 156;                       // 10ms at 16MHz/1024
	TCCR0B = (1 << CS02) | (1 << CS00); // 1024 prescaler
	TIMSK0 = (1 << OCIE0A);            // Enable interrupt
	
	sei();
}
//---------------------------------------------------------------------------------------------------------
void Lighting_Update(void) {
	// Headlight control
	PORTD = (PORTD & ~(1 << HEAD_LIGHT_PIN)) |
	((current_mode == MODE_NIGHT) << HEAD_LIGHT_PIN);
	
	// Brake light (overrides taillight)
	if(brake_active) {
		PORTD |= (1 << TAIL_LIGHT_PIN);
	}
	// Taillight blinking in night mode
	else if(current_mode == MODE_NIGHT && blink_state) {
		PORTD |= (1 << TAIL_LIGHT_PIN);
		} else {
		PORTD &= ~(1 << TAIL_LIGHT_PIN);
	}
	
	// Turn signals
	PORTD = (PORTD & ~(1 << LEFT_LIGHT_PIN)) |
	((left_signal && blink_state) << LEFT_LIGHT_PIN);
	PORTD = (PORTD & ~(1 << RIGHT_LIGHT_PIN)) |
	((right_signal && blink_state) << RIGHT_LIGHT_PIN);
	
	Update_Display();
}
//---------------------------------------------------------------------------------------------------------
void Update_Display(void) {
	lcd_goto(0, 0);
	lcd_print(current_mode == MODE_DAY ? "DAY  " : "NIGHT");
	
	lcd_goto(7, 0);
	lcd_print(brake_active ? "BRK:ON " : "BRK:OFF");
	
	lcd_goto(0, 1);
	lcd_print(left_signal ? "L:BLINK " : "L:OFF  ");
	lcd_print(right_signal ? "R:BLINK" : "R:OFF");
}
//---------------------------------------------------------------------------------------------------------