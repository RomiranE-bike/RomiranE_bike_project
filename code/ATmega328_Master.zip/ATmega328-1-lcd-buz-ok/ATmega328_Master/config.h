#ifndef CONFIG_H
#define CONFIG_H

#include <avr/io.h>
#include <stdint.h>
//------------------------------------------------------------------------------------
// System Configuration
#define F_CPU 16000000UL
#define SAMPLE_RATE_MS 100
#define LCD_REFRESH_RATE 500
#define SOC_UPDATE_INTERVAL 5000

#define f_beep   500     // beep frequency :500 cycle  if  clock set to 8MHZ/ 250 cycle if clock set to 1MHZ
#define d_beep   2000     // beep delay :2000us if clock set to 8MHZ  /250us if clock set to 1MHZ
//------------------------------------------------------------------------------------
// PORT Definitions
#define LCD_RS_PORT     PORTB
#define LCD_RS_DDR      DDRB

#define output_PORT     PORTD
#define output_DDR      DDRD

#define input_PORT     PORTC
#define input_DDR      DDRC
//------------------------------------------------------------------------------------
// LCD Pin Configuration - Using PORTB
#define LCD_RS_PIN     PB2
#define LCD_EN_PIN     PB3
#define LCD_D4_PIN     PB4
#define LCD_D5_PIN     PB5
#define LCD_D6_PIN     PB6
#define LCD_D7_PIN     PB7

//input Pin Configuration - Using PORTC
#define BUTTON_UP_PIN      PC0
#define BUTTON_DOWN_PIN    PC1
#define BUTTON_OK_PIN      PC2
#define BUTTON_BACK_PIN    PC3

#define THROTTLE_PIN       A0
#define BRAKE_SW_PIN       A1
#define BATTERY_VOLT_PIN   A2
#define TEMP_SENSOR_PIN    A3

//output Pin Configuration - Using PORTC
#define BUZZER_PIN         PB1
#define BRAKE_LIGHT_PIN    PD4
#define HEADLIGHT_PIN      PD5
#define TAILLIGHT_PIN      PD6
#define HAZARD_LIGHT_PIN   PD7

//------------------------------------------------------------------------------------
// Constants
#define BATTERY_CAPACITY_MAH 10000
#define BATTERY_CELLS 10
#define BATTERY_FULL_VOLTAGE 42.0f
#define BATTERY_EMPTY_VOLTAGE 30.0f

// System Parameters
#define SAMPLE_RATE_MS 100
#define SOC_UPDATE_INTERVAL 5000
#define LCD_REFRESH_RATE 500


// I2C Addresses
#define MOTOR1_I2C_ADDR 0x10
#define MOTOR2_I2C_ADDR 0x12

// Motor Control Commands
#define CMD_SET_TORQUE     0x01
#define CMD_SET_SPEED      0x02
#define CMD_SHUTDOWN       0x03
#define CMD_REDUCE_POWER   0x04

// Safety Limits
#define MAX_BATTERY_CURRENT 20.0f  // 20A
#define MAX_MOTOR_TEMP 80.0f       // 80°C
#define LOW_VOLTAGE_WARNING 33.0f  // 33V

// EEPROM Addresses
#define EEPROM_PIN_ADDR 0x00
#define EEPROM_SETTINGS_ADDR 0x10
#define EEPROM_LOG_START_ADDR 0x50

// Ride Modes
typedef enum {
    MODE_ECO = 0,
    MODE_NORMAL,
    MODE_SPORT,
    MODE_COUNT
} RideMode;

#endif // CONFIG_H