#include "status_buzzer.h"
#include "config.h"
#include <avr/io.h>
#include <util/delay.h>

void buzzer_init(void) {
    DDRB |= (1 << PB1); // OC1A (PB1) as output
}

void buzzer_play_tone(uint16_t frequency, uint16_t duration_ms) {
    uint16_t ocr_value = (F_CPU / (2UL * 8UL * frequency)) - 1;

    TCCR1A = (1 << COM1A0);               // Toggle OC1A on Compare Match
    TCCR1B = (1 << WGM12) | (1 << CS11);  // CTC mode, prescaler 8
    OCR1A = ocr_value;

    for (uint16_t i = 0; i < duration_ms / 2; i++) {
        _delay_ms(2); // crude timing
    }

    TCCR1B = 0;  // Stop timer
    PORTB &= ~(1 << PB1); // Ensure buzzer off
}

void buzzer_pattern(enum BuzzerPattern pattern) {
    switch (pattern) {
        case PATTERN_STARTUP:
            buzzer_play_tone(7000, 5);
            _delay_ms(1);
            buzzer_play_tone(8000, 5);
            _delay_ms(1);
            buzzer_play_tone(9000, 5);
            break;

        case PATTERN_FAULT:
            for (int i = 0; i < 5; i++) {
                buzzer_play_tone(9000, 25);
                _delay_ms(1);
            }
            break;

        case PATTERN_LOCKED:
            buzzer_play_tone(7000, 5);
            _delay_ms(1);
            buzzer_play_tone(5000, 5);
            break;

        case PATTERN_UNLOCKED:
            buzzer_play_tone(5000, 30);
            break;

        case PATTERN_POWER_ON:
            buzzer_play_tone(9000, 10);
            break;

        case PATTERN_PIN_FAIL:
            for (int i = 0; i < 5; i++) {
                buzzer_play_tone(7000, 10);
                _delay_ms(10);
            }
            break;

        case PATTERN_OVERHEAT:
            for (int i = 0; i < 7; i++) {
                buzzer_play_tone(9000, 25);
                _delay_ms(20);
            }
            break;

        case PATTERN_MODE_SWITCH:
            buzzer_play_tone(10000, 7);
            break;

        default:
            break;
    }
}
