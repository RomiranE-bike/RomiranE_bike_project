#include "status_buzzer.h"
#include "config.h"

#include <avr/io.h>
#include <util/delay.h>
#include <stdint.h>


//-------------------------------------------------------------------------------------------

void buzzer_init(void) {
	output_DDR |= (1 << BUZZER_PIN);
}
/*
void buzzer_play_tone(uint16_t frequency, uint16_t duration) {
	
	// Software PWM tone generation
	uint32_t cycles = (uint32_t)duration * frequency / 1000;
	for (uint32_t i = 0; i < cycles; i++) {
		output_PORT |= (1 << BUZZER_PIN);
		delay_us(500000/frequency);
		output_PORT &= ~(1 << BUZZER_PIN);
		delay_us(500000/frequency);
	}
}
*/
void buzzer_beep(uint16_t freq_hz, uint8_t times, uint16_t duration_ms, uint16_t pause_ms) {
	uint32_t cycles = f_beep;//(freq_hz * duration_ms) / 1000;
	for (uint8_t i = 0; i < times; i++) {
		// Software PWM tone generation
		for(uint32_t j=0; i<cycles; j++) {
			output_PORT ^= (1 << BUZZER_PIN);
			_delay_us(d_beep);//500000/freq_hz
		}
		delay_ms(pause_ms);
	}
}


void buzzer_play_pattern(BuzzerPattern_t pattern) {
    switch(pattern) {
        case PATTERN_STARTUP:// Triple short beeps(3, 100, 100)
            // Double beep
            buzzer_beep(1000, 3, 100, 100);
            break;
            
        case PATTERN_FAULT:// 5 long beeps
            // Rapid triple beep
                buzzer_beep(2000, 5, 300, 200);
            break;
            
        case PATTERN_LOCKED:// Double medium beep
            // Long low beep
            buzzer_beep(1000,2, 250, 100);
            break;
			
		case PATTERN_UNLOCKED:// One long beep
		// Double beep
		buzzer_beep(1000,1, 500, 0);
		   break;
		
		case PATTERN_POWER_ON:// One short beep
		// Double beep
		buzzer_beep(1000,1, 150, 0);
		   break;
		
		case PATTERN_PIN_FAIL:// 2 fast short beeps
		// Double beep
		buzzer_beep(2000,2, 100, 50);
		   break;	
		
		case PATTERN_OVERHEAT:// 3 long beeps
		// Double beep
		buzzer_beep(2000,3, 300, 150);
		break;
		
		case PATTERN_MODE_SWITCH:// One very short beep
		// Double beep
		buzzer_beep(1000,1, 100, 0);
		break;
    }
}



