#ifndef LCD_H
#define LCD_H

#include <avr/io.h>
#include <util/delay.h>

// LCD Pin Configuration - Using PORTB
#define LCD_RS_PIN   PB2  // Register Select (Command/Data)
#define LCD_EN_PIN   PB3  // Enable pin
#define LCD_D4_PIN   PB4  // Data bit 4
#define LCD_D5_PIN   PB5  // Data bit 5
#define LCD_D6_PIN   PB6  // Data bit 6
#define LCD_D7_PIN   PB7  // Data bit 7
#define LCD_PORT     PORTB  // Port register
#define LCD_DDR      DDRB   // Data direction register

// LCD Commands
#define LCD_CLEAR 0x01  // Clear display
#define LCD_HOME  0x02   // Return home

// Function prototypes
void lcd_command(uint8_t cmd);  // Send command to LCD
void lcd_char(char data);       // Send single character
void lcd_init(void);            // Initialize LCD
void lcd_print(const char* str); // Print string
void lcd_clear(void);           // Clear display
void lcd_home(void);            // Return cursor home
void lcd_goto(uint8_t x, uint8_t y); // Move cursor to position (x,y)

#endif