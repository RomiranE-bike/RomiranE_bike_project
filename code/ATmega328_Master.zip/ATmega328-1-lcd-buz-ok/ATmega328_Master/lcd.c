#include "lcd.h"

// Pulse the enable pin to execute command
void lcd_enable(void) {
	LCD_PORT |= (1 << LCD_EN_PIN);
	_delay_us(1);
	LCD_PORT &= ~(1 << LCD_EN_PIN);
	_delay_us(100);
}

// Send 4 bits of data to LCD
void lcd_send4(uint8_t data) {
	LCD_PORT &= ~(1 << LCD_D4_PIN | 1 << LCD_D5_PIN | 1 << LCD_D6_PIN | 1 << LCD_D7_PIN);
	if (data & 1 << 0) LCD_PORT |= (1 << LCD_D4_PIN);
	if (data & 1 << 1) LCD_PORT |= (1 << LCD_D5_PIN);
	if (data & 1 << 2) LCD_PORT |= (1 << LCD_D6_PIN);
	if (data & 1 << 3) LCD_PORT |= (1 << LCD_D7_PIN);
	lcd_enable();
}

// Send a command to LCD (8 bits, split into two 4-bit transfers)
void lcd_command(uint8_t cmd) {
	LCD_PORT &= ~(1 << LCD_RS_PIN);  // RS low for command mode
	lcd_send4(cmd >> 4);         // Send high nibble
	lcd_send4(cmd & 0x0F);       // Send low nibble
	_delay_ms(2);                // Wait for command to execute
}

// Send a character to LCD
void lcd_char(char data) {
	LCD_PORT |= (1 << LCD_RS_PIN);   // RS high for data mode
	lcd_send4(data >> 4);        // Send high nibble
	lcd_send4(data & 0x0F);      // Send low nibble
	_delay_us(50);               // Wait for data to be processed
}

// Initialize LCD in 4-bit mode
void lcd_init(void) {
	// Set all LCD pins as outputs
	LCD_DDR |= (1 << LCD_RS_PIN | 1 << LCD_EN_PIN |
	1 << LCD_D4_PIN | 1 << LCD_D5_PIN | 1 << LCD_D6_PIN | 1 << LCD_D7_PIN);
	
	_delay_ms(50);               // Wait for LCD to power up
	
	// Initialize 4-bit mode
	lcd_send4(0x03); _delay_ms(5);
	lcd_send4(0x03); _delay_us(200);
	lcd_send4(0x03); _delay_us(200);
	lcd_send4(0x02);             // 4-bit mode
	
	// Configure LCD
	lcd_command(0x28);           // 2 line, 5x8 font
	lcd_command(0x0C);           // Display on, cursor off
	lcd_command(0x06);           // Entry mode - increment, no shift
	lcd_clear();                 // Clear display
}

// Print a string to LCD
void lcd_print(const char* str) {
	while (*str) lcd_char(*str++);
}

// Clear LCD and return cursor home
void lcd_clear(void) {
	lcd_command(LCD_CLEAR);
	_delay_ms(2);
}

// Return cursor to home position
void lcd_home(void) {
	lcd_command(LCD_HOME);
	_delay_ms(2);
}

// Move cursor to specific position (x,y)
void lcd_goto(uint8_t x, uint8_t y) {
	uint8_t addr = (y == 0) ? 0x00 : 0x40;  // Line 1 or 2
	lcd_command(0x80 | (addr + x));         // Set DDRAM address
}