#ifndef STATUS_BUZZER_H
#define STATUS_BUZZER_H
#include <stdint.h> // ? Add this line

typedef enum {
    PATTERN_STARTUP,
    PATTERN_FAULT,
    PATTERN_LOCKED,
    PATTERN_UNLOCKED,
	PATTERN_POWER_ON,
	PATTERN_PIN_FAIL,
	PATTERN_OVERHEAT,
	PATTERN_MODE_SWITCH
} BuzzerPattern_t;

void buzzer_init(void);
void buzzer_play_tone(uint16_t frequency, uint16_t duration);

void delay_us(unsigned int us);
void delay_ms(unsigned int ms);

void buzzer_play_pattern(BuzzerPattern_t pattern);
void buzzer_beep(uint16_t freq_hz, uint8_t times, uint16_t duration_ms, uint16_t pause_ms);

#endif