/**
 * Intelligent Lighting System v5.1
 * Features:
 * - Hardware timer-based debouncing
 * - Day/Night mode toggle
 * - Turn signals with auto-cancel
 * - Brake light override
 * - LCD status display
 */
//---------------------------------------------------------------------------------------------------------
#include "lighting.h"
#include <avr/interrupt.h>
#include <util/delay.h>
//---------------------------------------------------------------------------------------------------------
// System State
static volatile PowerState power_state = SYSTEM_ON;
static volatile SystemMode current_mode = MODE_DAY;
static volatile bool brake_active = false;
static volatile bool left_signal = false;
static volatile bool right_signal = false;
//---------------------------------------------------------------------------------------------------------
// Timing Control
static volatile uint8_t blink_counter = 0;
static volatile bool blink_state = false;
static volatile uint16_t signal_timeout = 0;
static volatile uint16_t hold_counter = 0;
//---------------------------------------------------------------------------------------------------------
// Button States
#define HOLD_THRESHOLD 200  // 2 seconds (200 * 10ms)
typedef struct {
	bool pressed;
	bool long_press;
	uint16_t hold_time;
} Button;
//---------------------------------------------------------------------------------------------------------
static volatile Button mode_button = {0};
//---------------------------------------------------------------------------------------------------------
// Timer0 Compare Match ISR (100Hz)
ISR(TIMER0_COMPA_vect) {
	// Power control (only if system is on)
	if(power_state == SYSTEM_ON) {
		// Blink control (500ms period)500 mili seconds (50 * 10ms) or 50 mili seconds (5 * 10ms)
		if(++blink_counter >= 5) {
			blink_counter = 0;
			blink_state = !blink_state;
			
			// Auto-cancel signals after 10s
			if(left_signal || right_signal) {
				if(++signal_timeout >= 20) {
					left_signal = right_signal = false;
					signal_timeout = 0;
				}
			}
		}
		
		// Handle mode button press-and-hold
		if(mode_button.pressed) {
			if(++mode_button.hold_time >= HOLD_THRESHOLD && !mode_button.long_press) {
				mode_button.long_press = true;
				power_state = SYSTEM_OFF;
				PORTD = 0;  // Turn all lights off
				lcd_clear();
				lcd_print("Powering Off...");
				buzzer_pattern(POWER_OFF);
			}
		}
		} else {
		// Special blink pattern when powered off
		if(++blink_counter >= 10) {  // Faster blink when off
			blink_counter = 0;
			blink_state = !blink_state;
			PORTD = blink_state ? (1 << HEAD_LIGHT_PIN) : 0;
		}
		
		// Check for power-on
		if(mode_button.pressed && mode_button.hold_time >= HOLD_THRESHOLD) {
			power_state = SYSTEM_ON;
			current_mode = MODE_DAY;
			lcd_clear();
			lcd_print("Powering On...");
			buzzer_pattern(STARTUP);
			_delay_ms(500);
		}
	}
	
	Lighting_Update();
}
//---------------------------------------------------------------------------------------------------------
void Lighting_Init(void) {
	// Configure I/O
	DDRD |= (1 << HEAD_LIGHT_PIN) | (1 << TAIL_LIGHT_PIN) |(1 << LEFT_LIGHT_PIN) | (1 << RIGHT_LIGHT_PIN);
	DDRC &= ~(1 << MODE_BTN_PIN);
	PORTC |= (1 << MODE_BTN_PIN);
	
	// Timer0 Configuration
	TCCR0A = (1 << WGM01);
	OCR0A = 156;  // 10ms interval
	TCCR0B = (1 << CS02) | (1 << CS00);
	TIMSK0 = (1 << OCIE0A);
	
	// Pin Change Interrupt for mode button
	PCICR |= (1 << PCIE1);
	PCMSK1 |= (1 << PCINT8);
	
	sei();
}
//---------------------------------------------------------------------------------------------------------
// Pin Change ISR for mode button
ISR(PCINT1_vect) {
	static uint8_t last_state = 0xFF;
	uint8_t current_state = PINC;
	
	// Mode button (PC0) edge detection
	if((last_state & (1 << MODE_BTN_PIN)) && !(current_state & (1 << MODE_BTN_PIN))) {
		mode_button.pressed = true;
		mode_button.hold_time = 0;
		mode_button.long_press = false;
	}
	else if(!(last_state & (1 << MODE_BTN_PIN)) && (current_state & (1 << MODE_BTN_PIN))) {
		mode_button.pressed = false;
		
		// Short press action (only when powered on)
		if(power_state == SYSTEM_ON && mode_button.hold_time < HOLD_THRESHOLD) {
			current_mode = (current_mode == MODE_DAY) ? MODE_NIGHT : MODE_DAY;
			buzzer_pattern(BEEP);
		}
	}
	
	last_state = current_state;
}
//---------------------------------------------------------------------------------------------------------
void Lighting_Update(void) {
	if(power_state == SYSTEM_ON) {
		// Headlight control
		PORTD = (PORTD & ~(1 << HEAD_LIGHT_PIN)) |
		((current_mode == MODE_NIGHT) << HEAD_LIGHT_PIN);
		
		// Brake light (overrides taillight)
		if(brake_active) {
			PORTD |= (1 << TAIL_LIGHT_PIN);
		}
		// Taillight blinking in night mode
		else if(current_mode == MODE_NIGHT && blink_state) {
			PORTD |= (1 << TAIL_LIGHT_PIN);
			} else {
			PORTD &= ~(1 << TAIL_LIGHT_PIN);
		}
		
		// Turn signals
		PORTD = (PORTD & ~((1 << LEFT_LIGHT_PIN) | (1 << RIGHT_LIGHT_PIN))) |
		((left_signal && blink_state) << LEFT_LIGHT_PIN) |
		((right_signal && blink_state) << RIGHT_LIGHT_PIN);
		
		Update_Display();
	}
}
//---------------------------------------------------------------------------------------------------------
void Update_Display(void) {
	lcd_goto(0, 0);
	lcd_print(power_state == SYSTEM_ON ?
	(current_mode == MODE_DAY ? "DAY  " : "NIGHT") : "OFF  ");
	
	lcd_goto(6, 0);
	lcd_print("PWR:");
	lcd_print(mode_button.pressed ? "HOLD" : "    ");
	
	lcd_goto(0, 1);
	lcd_print(left_signal ? "L:BLINK " : "L:OFF  ");
	lcd_print(right_signal ? "R:BLINK" : "R:OFF");
}
//---------------------------------------------------------------------------------------------------------