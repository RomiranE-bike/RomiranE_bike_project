/**
 * Intelligent Lighting System v5.1
 * Features:
 * - Day/Night mode toggle
 * - Left/Right turn signals with auto-cancel
 * - Brake light override
 * - LCD status display
 * - Buzzer feedback
 * - Interrupt-driven design
 */
/**
 * Intelligent Lighting System v5.2
 * New Features:
 * - Press-and-hold power control (2-second hold)
 * - Visual feedback during power transition
 * - System power state tracking
 */
//----------------------------------------------------------------------------------------
#ifndef LIGHTING_H
#define LIGHTING_H
//----------------------------------------------------------------------------------------
#include <avr/io.h>
#include <stdbool.h>
#include "config.h"
#include "lcd.h"
#include "status_buzzer.h"
//----------------------------------------------------------------------------------------
// System States
typedef enum {
	SYSTEM_OFF,
	SYSTEM_ON
} PowerState;
//----------------------------------------------------------------------------------------
typedef enum {
	MODE_DAY,
	MODE_NIGHT
} SystemMode;
//----------------------------------------------------------------------------------------
void Lighting_Init(void);
void Lighting_Update(void);
//----------------------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------------------------------------