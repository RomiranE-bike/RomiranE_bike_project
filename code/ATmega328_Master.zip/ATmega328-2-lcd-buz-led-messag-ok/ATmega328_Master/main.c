/*
 * ATmega328 Motor Controller
 * 
 * Features:
 * - Dual motor control with PID
 * - LCD interface
 * - UART communication
 * - EEPROM storage for PID parameters
 * - Over-temperature/current protection
 * 
 * Pin Configuration:
 * - LCD: PORTB
 * - Button: PD2
 * - UART: PD0/RX, PD1/TX
 * - ADC: Throttle input on ADC0
 */
//--------------------------------------------------------------------------------------------------------
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include "lcd.h"
#include "config.h"
#include "status_buzzer.h"
//--------------------------------------------------------------------------------------------------------
#define F_CPU 16000000UL
#define BAUD 9600
#define UBRR_VAL ((F_CPU / (16UL * BAUD)) - 1)
//--------------------------------------------------------------------------------------------------------
int main(void) {
	// Initialize peripherals
	buzzer_init();
	lcd_init();
	// Initial display
	

	while (1) {
		
			buzzer_pattern(PATTERN_STARTUP);
			_delay_ms(1000);
			buzzer_pattern(PATTERN_FAULT);
			_delay_ms(1000);
			buzzer_pattern(PATTERN_LOCKED);
			_delay_ms(1000);
			buzzer_pattern(PATTERN_UNLOCKED);
			_delay_ms(1000);
			buzzer_pattern(PATTERN_POWER_ON);
			_delay_ms(1000);
			buzzer_pattern(PATTERN_PIN_FAIL);
			_delay_ms(1000);
			buzzer_pattern(PATTERN_OVERHEAT);
			_delay_ms(1000);
			buzzer_pattern(PATTERN_MODE_SWITCH);
			_delay_ms(1000);

		
		
        _delay_ms(200); // Update rate ~5Hz

	}
}
//--------------------------------------------------------------------------------------------------------
