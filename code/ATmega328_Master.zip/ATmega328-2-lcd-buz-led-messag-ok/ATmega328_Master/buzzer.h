#ifndef BUZZER_H
#define BUZZER_H
#include <stdint.h> // ? Add this line

void buzzer_init(void);
void buzzer_play_tone(uint16_t frequency, uint16_t duration);

void delay_us(unsigned int us);
void delay_ms(unsigned int ms);

#endif // BUZZER_H