#include "buzzer.h"
#include "config.h"
#include <avr/io.h>
#include <util/delay.h>

//-------------------------------------------------------------------------------------------
/*----- Microsecond Delay Function (approximate) -----*/
void delay_us(unsigned int us) {
	while (us--) {
		// 16 MHz = 16 cycles per microsecond
		// Each loop takes about 4 cycles
		// So, 4 NOPs (each 1 cycle) help refine timing
		__asm__ __volatile__ (
		"nop\n\t""nop\n\t""nop\n\t""nop\n\t"
		);
	}
}

/*----- Millisecond Delay Function -----*/
void delay_ms(unsigned int ms) {
	while (ms--) {
		// 1 ms = 1000 us
		delay_us(1000);
	}
}

//-------------------------------------------------------------------------------------------
  
void buzzer_init(void) {
    output_DDR |= (1 << BUZZER_PIN);
}

void buzzer_play_tone(uint16_t frequency, uint16_t duration) {
	
    // Software PWM tone generation
    uint32_t cycles = (uint32_t)duration * frequency / 1000;
    for (uint32_t i = 0; i < cycles; i++) {
        output_PORT |= (1 << BUZZER_PIN);
        delay_us(500000/frequency);
        output_PORT &= ~(1 << BUZZER_PIN);
        delay_us(500000/frequency);
    }
}

