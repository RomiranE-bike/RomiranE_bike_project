#include "status_buzzer.h"
#include "config.h"
#include "lcd.h"
#include <avr/io.h>
#include <util/delay.h>

void buzzer_init(void) {
   DDRB |= (1 << PB1); // OC1A (Buzzer)
   DDRB |= (1 << PB0); // Status LED
}

void buzzer_play_tone(uint16_t frequency, uint16_t duration_ms) {
    uint16_t ocr_value = (F_CPU / (2UL * 8UL * frequency)) - 1;

    TCCR1A = (1 << COM1A0);               // Toggle OC1A on Compare Match
    TCCR1B = (1 << WGM12) | (1 << CS11);  // CTC mode, prescaler 8
    OCR1A = ocr_value;

    PORTB |= (1 << PB0);  // Turn on LED during tone
    for (uint16_t i = 0; i < duration_ms / 2; i++) {
	    _delay_ms(2); // crude timing
    }

    TCCR1B = 0;  // Stop timer
    PORTB &= ~(1 << PB1); // Ensure buzzer off
	PORTB &= ~(1 << PB0); // Turn off LED
}

void buzzer_pattern(enum BuzzerPattern pattern) {
    switch (pattern) {
        case PATTERN_STARTUP:
		    lcd_print("Startup...");
            buzzer_play_tone(7000, 5);_delay_ms(1);
            buzzer_play_tone(8000, 5);_delay_ms(1);           
            buzzer_play_tone(9000, 5);
            break;

        case PATTERN_FAULT:
		    lcd_print("FAULT! Check System");
            for (int i = 0; i < 5; i++) {
                buzzer_play_tone(9000, 25);
                _delay_ms(1);
            }
            break;

        case PATTERN_LOCKED:
		     lcd_print("System Locked");
            buzzer_play_tone(7000, 5);
            _delay_ms(1);
            buzzer_play_tone(5000, 5);
            break;

        case PATTERN_UNLOCKED:
		    lcd_print("System Unlocked");
            buzzer_play_tone(7000, 30);
            break;

        case PATTERN_POWER_ON:
		    lcd_print("Power On");
            buzzer_play_tone(7000, 10);_delay_ms(1);
            buzzer_play_tone(8000, 10);_delay_ms(1);
            break;

        case PATTERN_PIN_FAIL:
		    lcd_print("PIN Failed"); 
            for (int i = 0; i < 5; i++) {
                buzzer_play_tone(7000, 10);
                _delay_ms(10);
            }
            break;

        case PATTERN_OVERHEAT:
		    lcd_print("Overheat Warning!");
            for (int i = 0; i < 7; i++) {
                buzzer_play_tone(9000, 25);
                _delay_ms(20);
            }
            break;

        case PATTERN_MODE_SWITCH:
		    lcd_print("Mode Switched");
            buzzer_play_tone(10000, 7);
            break;        
			}
	
	_delay_ms(50);
	lcd_clear();
}
