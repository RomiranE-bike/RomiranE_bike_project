Here's an expanded implementation of the Field Oriented Control (FOC) algorithm for a Brushless DC (BLDC) motor using an ATmega328 in Atmel Studio IDE. 
This version includes advanced features such as improved rotor angle estimation, phase voltage limiting, enhanced control logic, current sensing,
 motor temperature sensing, motor speed control, torque control, and the use of timers and interrupts for better performance.

Expanded FOC Implementation Code
c
#include <avr/io.h>  
#include <avr/interrupt.h>  
#include <util/delay.h>  
#include <math.h>  

// Constants  
#define PI 3.14159265358979323846  
#define MAX_VOLTAGE 255 // Max PWM value (8-bit)  
#define PWM_MAX 255 // Max PWM value  
#define ADC_MAX 1023 // Max ADC value (10-bit)  
#define Kp 1.0 // Proportional gain for PI controller  
#define Ki 0.1 // Integral gain for PI controller  
#define DT 0.01 // Time step in seconds  
#define TEMP_THRESHOLD 75 // Temperature threshold in Celsius  
#define CURRENT_SENSE_CHANNEL 0 // ADC channel for current sensing  
#define TEMP_SENSE_CHANNEL 1 // ADC channel for temperature sensing  

// Motor parameters  
typedef struct {  
    float rotor_angle; // Rotor angle in radians  
    float id;          // d-axis current  
    float iq;          // q-axis current  
    float vd;          // d-axis voltage  
    float vq;          // q-axis voltage  
    float integral;    // Integral term for PI controller  
    float speed;       // Motor speed  
} Motor;  

// Function prototypes  
void init_adc();  
uint16_t read_adc(uint8_t channel);  
void init_pwm();  
void apply_pwm(float va, float vb, float vc);  
void clarke_transform(float ia, float ib, float ic, float *alpha, float *beta);  
void park_transform(Motor *motor, float alpha, float beta);  
void inverse_park_transform(Motor *motor, float *va, float *vb, float *vc);  
void control_loop(Motor *motor, float desired_torque);  
float estimate_rotor_angle(float speed);  
void limit_voltage(float *v, float max_voltage);  
float read_temperature();  
void init_timer();  
void start_timer();  
void stop_timer();  

volatile float desired_speed = 0.0; // Desired speed in RPM  
volatile float desired_torque = 5.0; // Desired torque in Nm  
volatile uint8_t timer_flag = 0;  

int main() {  
    // Initialize ADC, PWM, and Timer  
    init_adc();  
    init_pwm();  
    init_timer();  

    Motor motor = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};  

    start_timer(); // Start timer for control loop  

    while (1) {  
        // Read phase currents  
        float ia = read_adc(CURRENT_SENSE_CHANNEL) * (MAX_VOLTAGE / ADC_MAX); // Phase A current  
        float ib = read_adc(CURRENT_SENSE_CHANNEL + 1) * (MAX_VOLTAGE / ADC_MAX); // Phase B current  
        float ic = read_adc(CURRENT_SENSE_CHANNEL + 2) * (MAX_VOLTAGE / ADC_MAX); // Phase C current  

        // Clarke transformation  
        float alpha, beta;  
        clarke_transform(ia, ib, ic, &alpha, &beta);  

        // Estimate rotor angle  
        motor.rotor_angle = estimate_rotor_angle(motor.speed);  

        // Perform Park transformation  
        park_transform(&motor, alpha, beta);  

        // Control loop to adjust voltage based on desired torque  
        control_loop(&motor, desired_torque);  

        // Inverse Park transformation to get phase voltages  
        float va, vb, vc;  
        inverse_park_transform(&motor, &va, &vb, &vc);  

        // Apply calculated PWM signals to the motor  
        apply_pwm(va, vb, vc);  

        // Check for temperature  
        float temperature = read_temperature();  
        if (temperature > TEMP_THRESHOLD) {  
            // Implement safety measures (e.g., reduce PWM or shut down motor)  
            apply_pwm(0, 0, 0); // Stop the motor  
        }  

        // Wait for the timer interrupt to execute control loop logic  
        while (!timer_flag);  
        timer_flag = 0; // Reset flag  
    }  

    return 0;  
}  

// Function to initialize ADC  
void init_adc() {  
    ADMUX = (1 << REFS0); // AVcc with external capacitor at AREF pin  
    ADCSRA = (1 << ADEN) | (1 << ADPS2) | (1 << ADPS1); // Enable ADC, prescaler 64  
}  

// Function to read ADC value  
uint16_t read_adc(uint8_t channel) {  
    ADMUX = (ADMUX & 0xF0) | (channel & 0x0F); // Select ADC channel  
    ADCSRA |= (1 << ADSC); // Start conversion  
    while (ADCSRA & (1 << ADSC)); // Wait for conversion to complete  
    return ADC;  
}  

// Function to initialize PWM  
void init_pwm() {  
    // Set PWM pins as output  
    DDRD |= (1 << PD6) | (1 << PD5) | (1 << PD3); // OC0A, OC0B, OC2  

    // Set Fast PWM mode with non-inverted output  
    TCCR0A = (1 << WGM00) | (1 << WGM01) | (1 << COM0A1) | (1 << COM0B1); // Timer0  
    TCCR0B = (1 << CS00); // No prescaling  

    TCCR2 = (1 << WGM20) | (1 << WGM21) | (1 << COM21) | (1 << CS20); // Timer2  
}  

// Clarke transformation to convert phase currents to alpha-beta currents  
void clarke_transform(float ia, float ib, float ic, float *alpha, float *beta) {  
    *alpha = ia;  
    *beta = (ib - ic) / sqrt(3.0);  
}  

// Park transformation to convert alpha-beta currents to d-q currents  
void park_transform(Motor *motor, float alpha, float beta) {  
    float theta = motor->rotor_angle; // Current rotor angle  

    motor->id = alpha * cos(theta) + beta * sin(theta);  
    motor->iq = -alpha * sin(theta) + beta * cos(theta);  
}  

// Inverse Park transformation to convert d-q voltages to alpha-beta voltages  
void inverse_park_transform(Motor *motor, float *va, float *vb, float *vc) {  
    float theta = motor->rotor_angle;  

    *va = motor->vd * cos(theta) - motor->vq * sin(theta);  
    *vb = motor->vd * cos(theta - (2 * PI / 3)) - motor->vq * sin(theta - (2 * PI / 3));  
    *vc = motor->vd * cos(theta + (2 * PI / 3)) - motor->vq * sin(theta + (2 * PI / 3));  
}  

// Control loop to calculate d-q voltages based on desired torque  
void control_loop(Motor *motor, float desired_torque) {  
    // Calculate error  
    float torque_error = desired_torque - motor->iq;  

    // PI control for iq  
    motor->integral += torque_error * DT;  
    motor->vq = Kp * torque_error + Ki * motor->integral;  

    // Limit voltage to maximum voltage  
    limit_voltage(&motor->vq, MAX_VOLTAGE);  

    // For simplicity, we set vd to zero (flux control)  
    motor->vd = 0.0;  
}  

// Function to limit voltage to a maximum value  
void limit_voltage(float *v, float max_voltage) {  
    if (*v > max_voltage) *v = max_voltage;  
    if (*v < -max_voltage) *v = -max_voltage;  
}  

// Function to apply calculated PWM signals to the motor  
void apply_pwm(float va, float vb, float vc) {  
    // Convert voltages to PWM values (assuming a simple linear mapping)  
    int pwm_a = (int)((va / MAX_VOLTAGE) * PWM_MAX);  
    int pwm_b = (int)((vb / MAX_VOLTAGE) * PWM_MAX);  
    int pwm_c = (int)((vc / MAX_VOLTAGE) * PWM_MAX);  

    // Ensure PWM values are within bounds  
    if (pwm_a < 0) pwm_a = 0; if (pwm_a > PWM_MAX) pwm_a = PWM_MAX;  
    if (pwm_b < 0) pwm_b = 0; if (pwm_b > PWM_MAX) pwm_b = PWM_MAX;  
    if (pwm_c < 0) pwm_c = 0; if (pwm_c > PWM_MAX) pwm_c = PWM_MAX;  

    // Set PWM values  
    OCR0A = pwm_a; // Set PWM for phase A  
    OCR0B = pwm_b; // Set PWM for phase B  
    OCR2 = pwm_c;  // Set PWM for phase C  
}  

// Placeholder function to estimate rotor angle based on speed  
float estimate_rotor_angle(float speed) {  
    static float angle = 0.0;  
    angle += speed * DT; // Update angle based on speed  
    if (angle >= 2 * PI) angle -= 2 * PI; // Wrap angle  
    if (angle < 0) angle += 2 * PI; // Wrap angle  
    return angle;  
}  

// Function to read temperature from a sensor  
float read_temperature() {  
    uint16_t temp_adc = read_adc(TEMP_SENSE_CHANNEL);  
    // Convert ADC value to temperature (assuming linear mapping)  
    // Adjust the formula based on your temperature sensor's characteristics  
    return (temp_adc / ADC_MAX) * 100.0; // Example: 0-100°C range  
}  

// Timer initialization for control loop  
void init_timer() {  
    TCCR1A = 0; // Normal mode  
    TCCR1B = (1 << WGM12) | (1 << CS12); // CTC mode, prescaler 256  
    OCR1A = 624; // Set compare value for 1Hz interrupt (assuming 16MHz clock)  
    TIMSK |= (1 << OCIE1A); // Enable Timer1 Compare Match A interrupt  
}  

// Start timer  
void start_timer() {  
    TCNT1 = 0; // Reset timer count  
    TIMSK |= (1 << OCIE1A); // Enable Timer1 interrupt  
}  

// Stop timer  
void stop_timer() {  
    TIMSK &= ~(1 << OCIE1A); // Disable Timer1 interrupt  
}  

// Timer interrupt service routine  
ISR(TIMER1_COMPA_vect) {  
    timer_flag = 1; // Set flag to indicate timer interrupt has occurred  
}  
Key Features of the Expanded Code
Initialization Functions:

ADC Initialization: Configures the ADC for reading phase currents and temperature.
PWM Initialization: Sets up the PWM outputs for controlling the motor.
Timer Initialization: Configures Timer1 for generating periodic interrupts to manage the control loop.
Motor Structure: The Motor struct holds parameters such as rotor angle, d-axis and q-axis currents, voltages, integral term for the PI controller, and motor speed.

Control Loop: The main loop reads phase currents, performs Clarke and Park transformations, estimates the rotor angle, executes the control loop, and applies the PWM signals to the motor.
 It also checks for motor temperature and implements safety measures if the temperature exceeds a threshold.

Transformations:

Clarke Transformation: Converts three-phase currents to two-phase stationary coordinates (α, β).
Park Transformation: Converts stationary coordinates to rotating coordinates (d, q) based on the rotor angle.
Inverse Transformations: Converts d-q voltages back to three-phase voltages.
Control Logic: A PI controller adjusts the q-axis voltage based on the desired torque. The integral term helps eliminate steady-state error.

Voltage Limiting: The limit_voltage function ensures that the calculated voltages do not exceed the maximum allowable voltage.

Temperature Sensing: The read_temperature function reads the temperature from a sensor and checks if it exceeds a predefined threshold.

Timer and Interrupts: The code uses Timer1 and interrupts to manage the control loop timing, allowing for more precise control over the motor.

Important Considerations
Rotor Angle Estimation: Implement a method to accurately estimate the rotor angle, which can be done using encoders or sensorless methods.

Current Sensing: Ensure that the current sensors are properly calibrated and connected to the correct ADC channels.

Temperature Sensor: Adjust the temperature reading logic based on the characteristics of your specific temperature sensor.

PWM Configuration: The PWM pins must be configured correctly for your specific hardware setup.

Safety and Limits: Implement additional safety checks and limits to prevent overcurrent, overheating, and other potential issues.

Conclusion
This expanded code provides a comprehensive framework for implementing FOC for a BLDC motor using an ATmega328 in Atmel Studio IDE. You may need to adapt and expand this code based on your specific hardware and application requirements. If you have any specific questions or need further assistance, feel free to ask!