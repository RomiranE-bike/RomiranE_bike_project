﻿Below is the complete implementation of a tachometer using a Hall sensor, ATmega8 microcontroller, and an LCD display. I'll provide the pin definitions, code, and library for interfacing the LCD.

Components Required
ATmega8 microcontroller

Hall sensor (e.g., A3144)

Magnet (attached to the rotating object)

16x2 LCD display

Resistors (for current limiting, if needed)

Power supply (5V)

Breadboard and connecting wires

Pin Definitions
Hall Sensor:

Output → PD2 (INT0) of ATmega8

VCC → 5V

GND → GND

LCD Display (16x2):

RS → PB0

RW → GND

EN → PB1

D4 → PB2

D5 → PB3

D6 → PB4

D7 → PB5

VCC → 5V

GND → GND

ATmega8:

Crystal oscillator (16 MHz) → XTAL1 and XTAL2

Reset pin → Pull-up resistor (10kΩ) to VCC

Working Principle
The Hall sensor detects the magnet and generates a pulse for each revolution.

The ATmega8 counts these pulses over a fixed time interval (e.g., 1 second).

The pulse count is converted into RPM and displayed on the LCD.

Code Implementation
Below is the complete code for the ATmega8 to measure RPM using a Hall sensor and display it on an LCD.

1. LCD Library
Save the following code as lcd.h and lcd.c in your project directory.

lcd.h

c
Copy
#ifndef LCD_H
#define LCD_H

#include <avr/io.h>
#include <util/delay.h>

#define LCD_RS PB0
#define LCD_EN PB1
#define LCD_D4 PB2
#define LCD_D5 PB3
#define LCD_D6 PB4
#define LCD_D7 PB5

void lcd_init();
void lcd_clear();
void lcd_set_cursor(uint8_t row, uint8_t col);
void lcd_print(char *str);
void lcd_print_number(uint16_t num);

#endif
lcd.c

c
Copy
#include "lcd.h"

void lcd_send_command(uint8_t cmd) {
    PORTB = (PORTB & 0xC0) | (cmd >> 4); // Send high nibble
    PORTB &= ~(1 << LCD_RS); // RS = 0 for command
    PORTB |= (1 << LCD_EN); // EN = 1
    _delay_us(1);
    PORTB &= ~(1 << LCD_EN); // EN = 0
    _delay_us(100);

    PORTB = (PORTB & 0xC0) | (cmd & 0x0F); // Send low nibble
    PORTB |= (1 << LCD_EN); // EN = 1
    _delay_us(1);
    PORTB &= ~(1 << LCD_EN); // EN = 0
    _delay_us(100);
}

void lcd_send_data(uint8_t data) {
    PORTB = (PORTB & 0xC0) | (data >> 4); // Send high nibble
    PORTB |= (1 << LCD_RS); // RS = 1 for data
    PORTB |= (1 << LCD_EN); // EN = 1
    _delay_us(1);
    PORTB &= ~(1 << LCD_EN); // EN = 0
    _delay_us(100);

    PORTB = (PORTB & 0xC0) | (data & 0x0F); // Send low nibble
    PORTB |= (1 << LCD_EN); // EN = 1
    _delay_us(1);
    PORTB &= ~(1 << LCD_EN); // EN = 0
    _delay_us(100);
}

void lcd_init() {
    DDRB |= 0x3F; // Set PB0-PB5 as output
    _delay_ms(20);

    lcd_send_command(0x02); // 4-bit mode
    lcd_send_command(0x28); // 2 lines, 5x7 matrix
    lcd_send_command(0x0C); // Display on, cursor off
    lcd_send_command(0x06); // Increment cursor
    lcd_send_command(0x01); // Clear display
    _delay_ms(2);
}

void lcd_clear() {
    lcd_send_command(0x01); // Clear display
    _delay_ms(2);
}

void lcd_set_cursor(uint8_t row, uint8_t col) {
    uint8_t address = (row == 0) ? 0x80 : 0xC0;
    address += col;
    lcd_send_command(address);
}

void lcd_print(char *str) {
    while (*str) {
        lcd_send_data(*str++);
    }
}

void lcd_print_number(uint16_t num) {
    char buffer[6];
    itoa(num, buffer, 10);
    lcd_print(buffer);
}
2. Main Code
Save the following code as main.c.

c
Copy
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "lcd.h"

#define F_CPU 16000000UL // 16 MHz clock
#define PULSES_PER_REV 1 // Number of pulses per revolution

volatile uint16_t pulse_count = 0;
uint16_t rpm = 0;

// Initialize external interrupt for pulse counting
void init_interrupt() {
    GICR |= (1 << INT0); // Enable INT0
    MCUCR |= (1 << ISC01); // Trigger INT0 on falling edge
}

// Initialize Timer1 for 1-second interval
void init_timer() {
    TCCR1B |= (1 << WGM12); // Configure Timer1 in CTC mode
    OCR1A = 15624; // Set compare value for 1-second interval (16MHz / 1024 prescaler)
    TIMSK |= (1 << OCIE1A); // Enable Timer1 compare interrupt
    TCCR1B |= (1 << CS12) | (1 << CS10); // Set prescaler to 1024 and start timer
}

// External interrupt ISR for pulse counting
ISR(INT0_vect) {
    pulse_count++;
}

// Timer1 compare interrupt ISR for calculating RPM
ISR(TIMER1_COMPA_vect) {
    rpm = (pulse_count * 60) / PULSES_PER_REV; // Calculate RPM
    pulse_count = 0; // Reset pulse count
}

int main() {
    lcd_init();
    lcd_clear();
    init_interrupt();
    init_timer();
    sei(); // Enable global interrupts

    while (1) {
        lcd_set_cursor(0, 0);
        lcd_print("RPM: ");
        lcd_print_number(rpm); // Display RPM on LCD
        _delay_ms(500); // Update display every 500ms
    }

    return 0;
}
Steps to Build and Test
Assemble the circuit as per the pin definitions.

Upload the code to the ATmega8 using a programmer (e.g., USBasp).

Attach a magnet to the rotating object and place the Hall sensor nearby.

Rotate the object and observe the RPM on the LCD.

Adjust the PULSES_PER_REV constant based on your setup.

Tips
Use a debouncing circuit or software debouncing to avoid false pulse counts.

Calibrate the system by comparing the measured RPM with a known reference.

Ensure the Hall sensor is placed close enough to the magnet for reliable detection.

This project provides a simple and effective way to measure and display RPM using a Hall sensor and an LCD. You can expand it by adding more features like data logging or wireless transmission.