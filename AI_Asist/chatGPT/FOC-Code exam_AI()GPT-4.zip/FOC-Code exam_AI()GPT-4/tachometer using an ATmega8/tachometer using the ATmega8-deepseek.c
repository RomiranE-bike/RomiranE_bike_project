﻿Using an OLED display with the ATmega8 microcontroller to build a tachometer is a modern and efficient approach. OLED displays are compact, easy to interface, and provide a clear visual output. Below, I'll provide the complete code and instructions for interfacing an I2C-based OLED display (e.g., SSD1306) with the ATmega8 to display RPM readings from a Hall sensor.

Components Required
ATmega8 microcontroller

Hall sensor (e.g., A3144)

Magnet (attached to the rotating object)

I2C OLED display (SSD1306, 128x64 or 128x32)

Resistors (for current limiting, if needed)

Power supply (5V)

Breadboard and connecting wires

Working Principle
The Hall sensor detects the magnet and generates a pulse for each revolution.

The ATmega8 counts these pulses over a fixed time interval (e.g., 1 second).

The pulse count is converted into RPM and displayed on the OLED display.

Circuit Diagram
Connect the Hall sensor output to one of the ATmega8's external interrupt pins (e.g., INT0 or INT1).

Connect the OLED display to the ATmega8's I2C pins:

SDA (Serial Data) → PC4 (ATmega8)

SCL (Serial Clock) → PC5 (ATmega8)

Provide a 16 MHz crystal oscillator to the ATmega8 for accurate timing.

Connect the power supply (5V) and ground to the ATmega8 and other components.

Libraries Required
To interface the OLED display, we'll use the SSD1306 OLED library for AVR microcontrollers. You can download the library from GitHub or use the one provided below.

Code Implementation
Below is the complete code for the ATmega8 to measure RPM using a Hall sensor and display it on an OLED display.

1. SSD1306 OLED Library
Save the following code as ssd1306.h and ssd1306.c in your project directory.

ssd1306.h

c
Copy
#ifndef SSD1306_H
#define SSD1306_H

#include <avr/io.h>
#include <util/delay.h>

#define SSD1306_I2C_ADDRESS 0x3C

void ssd1306_init();
void ssd1306_clear();
void ssd1306_set_cursor(uint8_t x, uint8_t y);
void ssd1306_print(char *str);
void ssd1306_print_number(uint16_t num);

#endif
ssd1306.c

c
Copy
#include "ssd1306.h"
#include "i2c.h"

void ssd1306_command(uint8_t cmd) {
    i2c_start(SSD1306_I2C_ADDRESS << 1);
    i2c_write(0x00); // Command mode
    i2c_write(cmd);
    i2c_stop();
}

void ssd1306_data(uint8_t data) {
    i2c_start(SSD1306_I2C_ADDRESS << 1);
    i2c_write(0x40); // Data mode
    i2c_write(data);
    i2c_stop();
}

void ssd1306_init() {
    _delay_ms(100);
    ssd1306_command(0xAE); // Display off
    ssd1306_command(0xD5); // Set display clock divide ratio/oscillator frequency
    ssd1306_command(0x80);
    ssd1306_command(0xA8); // Set multiplex ratio
    ssd1306_command(0x3F);
    ssd1306_command(0xD3); // Set display offset
    ssd1306_command(0x00);
    ssd1306_command(0x40); // Set display start line
    ssd1306_command(0x8D); // Charge pump
    ssd1306_command(0x14);
    ssd1306_command(0x20); // Memory mode
    ssd1306_command(0x00);
    ssd1306_command(0xA1); // Segment remap
    ssd1306_command(0xC8); // COM output scan direction
    ssd1306_command(0xDA); // Set COM pins hardware configuration
    ssd1306_command(0x12);
    ssd1306_command(0x81); // Set contrast control
    ssd1306_command(0xCF);
    ssd1306_command(0xD9); // Set pre-charge period
    ssd1306_command(0xF1);
    ssd1306_command(0xDB); // Set VCOMH deselect level
    ssd1306_command(0x40);
    ssd1306_command(0xA4); // Entire display on
    ssd1306_command(0xA6); // Set normal display
    ssd1306_command(0xAF); // Display on
}

void ssd1306_clear() {
    for (uint16_t i = 0; i < 1024; i++) {
        ssd1306_data(0x00);
    }
}

void ssd1306_set_cursor(uint8_t x, uint8_t y) {
    ssd1306_command(0x21); // Set column address
    ssd1306_command(x);
    ssd1306_command(127);
    ssd1306_command(0x22); // Set page address
    ssd1306_command(y);
    ssd1306_command(7);
}

void ssd1306_print(char *str) {
    while (*str) {
        for (uint8_t i = 0; i < 5; i++) {
            ssd1306_data(pgm_read_byte(&font5x7[*str - 32][i]));
        }
        ssd1306_data(0x00); // Space between characters
        str++;
    }
}

void ssd1306_print_number(uint16_t num) {
    char buffer[6];
    itoa(num, buffer, 10);
    ssd1306_print(buffer);
}
2. I2C Library
Save the following code as i2c.h and i2c.c in your project directory.

i2c.h

c
Copy
#ifndef I2C_H
#define I2C_H

#include <avr/io.h>
#include <util/delay.h>

void i2c_init();
void i2c_start(uint8_t address);
void i2c_write(uint8_t data);
void i2c_stop();

#endif
i2c.c

c
Copy
#include "i2c.h"

void i2c_init() {
    TWSR = 0x00; // Set prescaler to 1
    TWBR = 0x48; // Set bit rate register for 100 kHz
    TWCR = (1 << TWEN); // Enable TWI
}

void i2c_start(uint8_t address) {
    TWCR = (1 << TWINT) | (1 << TWSTA) | (1 << TWEN);
    while (!(TWCR & (1 << TWINT)));
    TWDR = address;
    TWCR = (1 << TWINT) | (1 << TWEN);
    while (!(TWCR & (1 << TWINT)));
}

void i2c_write(uint8_t data) {
    TWDR = data;
    TWCR = (1 << TWINT) | (1 << TWEN);
    while (!(TWCR & (1 << TWINT)));
}

void i2c_stop() {
    TWCR = (1 << TWINT) | (1 << TWSTO) | (1 << TWEN);
}
3. Main Code
Save the following code as main.c.

c
Copy
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "ssd1306.h"

#define F_CPU 16000000UL // 16 MHz clock
#define PULSES_PER_REV 1 // Number of pulses per revolution

volatile uint16_t pulse_count = 0;
uint16_t rpm = 0;

// Initialize external interrupt for pulse counting
void init_interrupt() {
    GICR |= (1 << INT0); // Enable INT0
    MCUCR |= (1 << ISC01); // Trigger INT0 on falling edge
}

// Initialize Timer1 for 1-second interval
void init_timer() {
    TCCR1B |= (1 << WGM12); // Configure Timer1 in CTC mode
    OCR1A = 15624; // Set compare value for 1-second interval (16MHz / 1024 prescaler)
    TIMSK |= (1 << OCIE1A); // Enable Timer1 compare interrupt
    TCCR1B |= (1 << CS12) | (1 << CS10); // Set prescaler to 1024 and start timer
}

// External interrupt ISR for pulse counting
ISR(INT0_vect) {
    pulse_count++;
}

// Timer1 compare interrupt ISR for calculating RPM
ISR(TIMER1_COMPA_vect) {
    rpm = (pulse_count * 60) / PULSES_PER_REV; // Calculate RPM
    pulse_count = 0; // Reset pulse count
}

int main() {
    i2c_init();
    ssd1306_init();
    ssd1306_clear();
    init_interrupt();
    init_timer();
    sei(); // Enable global interrupts

    while (1) {
        ssd1306_set_cursor(0, 0);
        ssd1306_print("RPM: ");
        ssd1306_print_number(rpm); // Display RPM on OLED
        _delay_ms(500); // Update display every 500ms
    }

    return 0;
}
Steps to Build and Test
Assemble the circuit as per the diagram.

Upload the code to the ATmega8 using a programmer (e.g., USBasp).

Attach a magnet to the rotating object and place the Hall sensor nearby.

Rotate the object and observe the RPM on the OLED display.

Adjust the PULSES_PER_REV constant based on your setup.

Tips
Ensure the I2C connections (SDA and SCL) are properly pulled up with 4.7kΩ resistors.

Use a logic level converter if the OLED display operates at 3.3V.

Calibrate the system by comparing the measured RPM with a known reference.

This project provides a modern and efficient way to measure and display RPM using a Hall sensor and an OLED display. You can expand it by adding more features like data logging or graphical representations.

