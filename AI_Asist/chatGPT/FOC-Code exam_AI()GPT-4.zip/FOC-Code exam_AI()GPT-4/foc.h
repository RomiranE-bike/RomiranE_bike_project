//foc.h Library
//This library implements the sensorless FOC algorithm, including rotor position estimation, Clarke and Park transforms, and Space Vector Modulation (SVM).

#ifndef FOC_H
#define FOC_H

#include <avr/io.h>
#include <math.h>

// Constants
#define PI 3.14159265358979323846
#define PWM_MAX 255
#define PWM_MIN 0

// Function Prototypes
void init_foc();
void set_pwm_duty(uint8_t duty);
void clarke_transform(float ia, float ib, float ic, float *ialpha, float *ibeta);
void park_transform(float ialpha, float ibeta, float theta, float *id, float *iq);
void inverse_park_transform(float vd, float vq, float theta, float *valpha, float *vbeta);
void space_vector_modulation(float valpha, float vbeta, uint8_t *pwm_u, uint8_t *pwm_v, uint8_t *pwm_w);
void rotor_position_estimation(float *theta);

#endif
