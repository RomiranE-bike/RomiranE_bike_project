Overview of FOC Algorithm
Current Sensing: Measure the phase currents of the motor (Ia, Ib, Ic) using current sensors.

Clarke Transformation: Convert the three-phase currents into two-phase stationary coordinates (α, β).

Park Transformation: Transform the stationary coordinates into rotating coordinates (d, q) based on the rotor angle.

Control Loop: Implement a control strategy (usually PI control) to regulate the d-axis and q-axis currents.
 The q-axis current (Iq) is typically controlled to manage torque, while the d-axis current (Id) is controlled to manage flux.

Inverse Park Transformation: Convert the d-q voltages back to α-β voltages.

Inverse Clarke Transformation: Convert the α-β voltages back to three-phase voltages.

PWM Generation: Use the calculated phase voltages to generate PWM signals for the motor driver.

C Code Example
Here’s a simplified C code example that outlines the FOC algorithm for a BLDC motor:

c
#include <math.h>  
#include <stdio.h>  
#include <unistd.h> // For usleep  

// Constants  
#define PI 3.14159265358979323846  
#define MAX_VOLTAGE 12.0 // Maximum voltage in Volts  
#define PWM_MAX 255 // Maximum PWM value  

// Motor parameters  
typedef struct {  
    float rotor_angle; // Rotor angle in radians  
    float id;          // d-axis current  
    float iq;          // q-axis current  
    float vd;          // d-axis voltage  
    float vq;          // q-axis voltage  
} Motor;  

// Function prototypes  
void clarke_transform(float ia, float ib, float ic, float *alpha, float *beta);  
void park_transform(Motor *motor, float alpha, float beta);  
void inverse_park_transform(Motor *motor, float *va, float *vb, float *vc);  
void control_loop(Motor *motor, float desired_torque, float dt);  
void apply_pwm(float va, float vb, float vc);  

int main() {  
    Motor motor = {0.0, 0.0, 0.0, 0.0, 0.0};  
    float desired_torque = 5.0; // Desired torque in Nm  
    float dt = 0.01; // Time step in seconds  

    while (1) {  
        // Simulate current readings (replace with actual sensor readings)  
        float ia = 1.0; // Phase A current  
        float ib = 0.5; // Phase B current  
        float ic = -1.5; // Phase C current  

        // Clarke transformation  
        float alpha, beta;  
        clarke_transform(ia, ib, ic, &alpha, &beta);  

        // Perform Park transformation  
        park_transform(&motor, alpha, beta);  

        // Control loop to adjust voltage based on desired torque  
        control_loop(&motor, desired_torque, dt);  

        // Inverse Park transformation to get phase voltages  
        float va, vb, vc;  
        inverse_park_transform(&motor, &va, &vb, &vc);  

        // Apply calculated PWM signals to the motor  
        apply_pwm(va, vb, vc);  

        // Simulate a delay for the control loop  
        usleep(dt * 1000000); // Convert seconds to microseconds  
    }  

    return 0;  
}  

// Clarke transformation to convert phase currents to alpha-beta currents  
void clarke_transform(float ia, float ib, float ic, float *alpha, float *beta) {  
    *alpha = ia;  
    *beta = (ib - ic) / sqrt(3.0);  
}  

// Park transformation to convert alpha-beta currents to d-q currents  
void park_transform(Motor *motor, float alpha, float beta) {  
    float theta = motor->rotor_angle; // Current rotor angle  

    motor->id = alpha * cos(theta) + beta * sin(theta);  
    motor->iq = -alpha * sin(theta) + beta * cos(theta);  
}  

// Inverse Park transformation to convert d-q voltages to alpha-beta voltages  
void inverse_park_transform(Motor *motor, float *va, float *vb, float *vc) {  
    float theta = motor->rotor_angle;  

    *va = motor->vd * cos(theta) - motor->vq * sin(theta);  
    *vb = motor->vd * cos(theta - (2 * PI / 3)) - motor->vq * sin(theta - (2 * PI / 3));  
    *vc = motor->vd * cos(theta + (2 * PI / 3)) - motor->vq * sin(theta + (2 * PI / 3));  
}  

// Control loop to calculate d-q voltages based on desired torque  
void control_loop(Motor *motor, float desired_torque, float dt) {  
    // Simple PI controller for iq (torque control)  
    float Kp = 1.0; // Proportional gain  
    float Ki = 0.1; // Integral gain  
    static float integral = 0.0;  

    // Calculate error  
    float torque_error = desired_torque - motor->iq;  

    // PI control for iq  
    integral += torque_error * dt;  
    motor->vq = Kp * torque_error + Ki * integral;  

    // Limit voltage to maximum voltage  
    if (motor->vq > MAX_VOLTAGE) motor->vq = MAX_VOLTAGE;  
    if (motor->vq < -MAX_VOLTAGE) motor->vq = -MAX_VOLTAGE;  

    // For simplicity, we set vd to zero (flux control)  
    motor->vd = 0.0;  
}  

// Function to apply calculated PWM signals to the motor  
void apply_pwm(float va, float vb, float vc) {  
    // Convert voltages to PWM values (assuming a simple linear mapping)  
    int pwm_a = (int)((va / MAX_VOLTAGE) * PWM_MAX);  
    int pwm_b = (int)((vb / MAX_VOLTAGE) * PWM_MAX);  
    int pwm_c = (int)((vc / MAX_VOLTAGE) * PWM_MAX);  

    // Ensure PWM values are within bounds  
    if (pwm_a < 0) pwm_a = 0; if (pwm_a > PWM_MAX) pwm_a = PWM_MAX;  
    if (pwm_b < 0) pwm_b = 0; if (pwm_b > PWM_MAX) pwm_b = PWM_MAX;  
    if (pwm_c < 0) pwm_c = 0; if (pwm_c > PWM_MAX) pwm_c = PWM_MAX;  

    // Here you would send the PWM signals to the motor driver  
    printf("PWM A: %d, PWM B: %d, PWM C: %d\n", pwm_a, pwm_b, pwm_c);  
}  
Explanation of the Code
Motor Structure: The Motor struct holds the necessary parameters for the motor, including rotor angle, d-axis and q-axis currents, and voltages.

Clarke Transformation: The clarke_transform function converts the three-phase currents into two-phase stationary coordinates (α, β).

Park Transformation: The park_transform function converts the stationary coordinates into rotating coordinates (d, q) based on the rotor angle.

Control Loop: The control_loop function implements a simple PI controller to adjust the q-axis voltage based on the desired torque.

Inverse Park Transformation: The inverse_park_transform function converts the d-q voltages back to α-β voltages.

PWM Generation: The apply_pwm function converts the calculated voltages into PWM signals for the motor driver.

Note
This code is a basic framework and does not include all necessary components for a complete FOC implementation, such as rotor angle estimation, current sensing, or PWM generation. You would need to integrate this with your specific hardware and add additional features for a fully functional system. If you have any specific requirements or questions, feel free to ask!