Menu System Implementation
c
#include <avr/io.h>  
#include <avr/interrupt.h>  
#include <util/delay.h>  
#include "lcd.h"  

// Constants for menu options  
#define MENU_OPTIONS 3  
#define OPTION_SPEED 0  
#define OPTION_TORQUE 1  
#define OPTION_PARAMETERS 2  

// Global variables  
volatile uint8_t current_option = 0; // Current menu option  
volatile uint8_t speed_setting = 0;   // Speed setting  
volatile uint8_t torque_setting = 0;  // Torque setting  

// Function prototypes  
void display_menu();  
void update_display();  
void navigate_menu();  
void adjust_setting();  
void handle_buttons();  

// Main function  
int main() {  
    lcd_init(); // Initialize the LCD  
    // Initialize buttons (assuming they are connected to PORTC)  
    DDRC &= ~((1 << PC0) | (1 << PC1) | (1 << PC2)); // Set PC0, PC1, PC2 as input for buttons  

    while (1) {  
        handle_buttons(); // Check for button presses  
        update_display(); // Update the LCD display  
        _delay_ms(100);  // Debounce delay  
    }  

    return 0;  
}  

// Function to display the menu  
void display_menu() {  
    lcd_clear();  
    switch (current_option) {  
        case OPTION_SPEED:  
            lcd_puts("Speed: ");  
            lcd_puts(itoa(speed_setting, buffer, 10)); // Display current speed setting  
            break;  
        case OPTION_TORQUE:  
            lcd_puts("Torque: ");  
            lcd_puts(itoa(torque_setting, buffer, 10)); // Display current torque setting  
            break;  
        case OPTION_PARAMETERS:  
            lcd_puts("Motor Params");  
            break;  
    }  
}  

// Function to update the display based on the current option  
void update_display() {  
    lcd_gotoxy(0, 0); // Set cursor to first line  
    switch (current_option) {  
        case OPTION_SPEED:  
            lcd_puts("Speed Setting");  
            break;  
        case OPTION_TORQUE:  
            lcd_puts("Torque Setting");  
            break;  
        case OPTION_PARAMETERS:  
            lcd_puts("Motor Parameters");  
            break;  
    }  
}  

// Function to navigate through the menu  
void navigate_menu() {  
    if (PINC & (1 << PC0)) { // Up button pressed  
        current_option++;  
        if (current_option >= MENU_OPTIONS) {  
            current_option = 0; // Wrap around  
        }  
    }  
    if (PINC & (1 << PC1)) { // Down button pressed  
        if (current_option == 0) {  
            current_option = MENU_OPTIONS - 1; // Wrap around  
        } else {  
            current_option--;  
        }  
    }  
}  

// Function to adjust the current setting  
void adjust_setting() {  
    if (PINC & (1 << PC2)) { // Enter button pressed  
        switch (current_option) {  
            case OPTION_SPEED:  
                speed_setting += 10; // Increase speed by 10 (example)  
                if (speed_setting > 100) speed_setting = 0; // Reset if exceeds max  
                break;  
            case OPTION_TORQUE:  
                torque_setting += 5; // Increase torque by 5 (example)  
                if (torque_setting > 50) torque_setting = 0; // Reset if exceeds max  
                break;  
            case OPTION_PARAMETERS:  
                // Handle motor parameters adjustment if needed  
                break;  
        }  
    }  
}  

// Function to handle button presses  
void handle_buttons() {  
    navigate_menu(); // Navigate through menu options  
    adjust_setting(); // Adjust the selected setting  
}  
Explanation of the Code
Menu Options: The code defines three menu options: Speed, Torque, and Motor Parameters.

Global Variables:

current_option: Tracks the currently selected menu option.
speed_setting and torque_setting: Store the current values for speed and torque.
Display Menu: The display_menu function updates the LCD with the current setting based on the selected option.

Update Display: The update_display function shows the name of the current setting on the LCD.

Navigation: The navigate_menu function checks for button presses to navigate through the menu options. It wraps around when reaching the end or beginning of the options.

Adjust Settings: The adjust_setting function allows the user to modify the speed and torque settings when the enter button is pressed.

Button Handling: The handle_buttons function combines navigation and adjustment functionalities.

Button Connections
PC0: Up button
PC1: Down button
PC2: Enter button
Additional Considerations
Debouncing: The _delay_ms(100) provides a simple debounce mechanism. For more robust handling, consider implementing a more sophisticated debounce routine.
LCD Library: Ensure you have a compatible LCD library that supports the functions used (like lcd_init, lcd_puts, and lcd_gotoxy).
Adjustable Limits: Modify the limits for speed and torque settings based on your application requirements.
This menu system provides a basic framework for navigating and adjusting motor control settings. You can expand it further by adding more options or features as needed. If you have any specific requirements or questions, feel free to ask!