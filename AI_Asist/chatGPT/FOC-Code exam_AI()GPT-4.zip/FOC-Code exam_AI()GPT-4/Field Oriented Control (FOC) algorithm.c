Here's a simple example of C code that demonstrates the basic structure of a Field Oriented Control (FOC) algorithm for a brushless DC motor. 
This example includes the transformation of currents and a basic control loop. 
Note that this is a simplified version and may need to be adapted for specific hardware and application requirements.

c
#include <math.h>  
#include <stdio.h>  

// Constants  
#define PI 3.14159265358979323846  
#define MAX_CURRENT 10.0 // Maximum current in Amperes  
#define MAX_VOLTAGE 12.0 // Maximum voltage in Volts  

// Motor parameters  
typedef struct {  
    float rotor_angle; // Rotor angle in radians  
    float id;          // d-axis current  
    float iq;          // q-axis current  
    float vd;          // d-axis voltage  
    float vq;          // q-axis voltage  
} Motor;  

// Function prototypes  
void park_transform(Motor *motor, float ia, float ib, float ic);  
void control_loop(Motor *motor, float desired_torque, float dt);  
void apply_voltage(Motor *motor);  

int main() {  
    Motor motor = {0.0, 0.0, 0.0, 0.0, 0.0};  
    float desired_torque = 5.0; // Desired torque in Nm  
    float dt = 0.01; // Time step in seconds  

    while (1) {  
        // Simulate current readings (replace with actual sensor readings)  
        float ia = 1.0; // Phase A current  
        float ib = 0.5; // Phase B current  
        float ic = -1.5; // Phase C current  

        // Perform Park transformation  
        park_transform(&motor, ia, ib, ic);  

        // Control loop to adjust voltage based on desired torque  
        control_loop(&motor, desired_torque, dt);  

        // Apply calculated voltage to the motor  
        apply_voltage(&motor);  

        // Simulate a delay for the control loop  
        // In a real application, this would be handled by a timer interrupt  
        usleep(dt * 1000000); // Convert seconds to microseconds  
    }  

    return 0;  
}  

// Park transformation to convert phase currents to d-q currents  
void park_transform(Motor *motor, float ia, float ib, float ic) {  
    float theta = motor->rotor_angle; // Current rotor angle  
    float sqrt3 = sqrt(3.0);  

    // Clarke transformation  
    float alpha = ia;  
    float beta = (ib - ic) / sqrt3;  

    // Park transformation  
    motor->id = alpha * cos(theta) + beta * sin(theta);  
    motor->iq = -alpha * sin(theta) + beta * cos(theta);  
}  

// Control loop to calculate d-q voltages based on desired torque  
void control_loop(Motor *motor, float desired_torque, float dt) {  
    // Simple PI controller for iq (torque control)  
    float Kp = 1.0; // Proportional gain  
    float Ki = 0.1; // Integral gain  
    static float integral = 0.0;  

    // Calculate error  
    float torque_error = desired_torque - motor->iq;  

    // PI control for iq  
    integral += torque_error * dt;  
    motor->vq = Kp * torque_error + Ki * integral;  

    // Limit voltage to maximum voltage  
    if (motor->vq > MAX_VOLTAGE) motor->vq = MAX_VOLTAGE;  
    if (motor->vq < -MAX_VOLTAGE) motor->vq = -MAX_VOLTAGE;  

    // For simplicity, we set vd to zero (flux control)  
    motor->vd = 0.0;  
}  

// Function to apply calculated voltages to the motor (placeholder)  
void apply_voltage(Motor *motor) {  
    // Here you would convert vd and vq back to phase voltages  
    // and apply them to the motor driver  
    printf("Applying vd: %.2f V, vq: %.2f V\n", motor->vd, motor->vq);  
}  
Explanation
Motor Structure: The Motor struct holds the necessary parameters for the motor, including rotor angle, d-axis and q-axis currents, and voltages.
Park Transformation: The park_transform function converts the three-phase currents into d-q currents using Clarke and Park transformations.
Control Loop: The control_loop function implements a simple PI controller to adjust the q-axis voltage based on the desired torque.
Voltage Application: The apply_voltage function is a placeholder where you would typically convert the d-q voltages back to phase voltages
 and send them to the motor driver.
Note
This code is a basic framework and does not include all necessary components for a complete FOC implementation, such as rotor angle estimation, 
current sensing, or PWM generation. You would need to integrate this with your specific hardware and add additional features for a fully functional system.
 If you have any specific requirements or questions, feel free to ask!