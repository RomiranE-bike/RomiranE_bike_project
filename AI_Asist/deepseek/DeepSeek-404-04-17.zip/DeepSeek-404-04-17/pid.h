#ifndef __PID_H
#define __PID_H

/**
 * @brief PID controller structure
 */
typedef struct {
    float Kp;               // Proportional gain
    float Ki;               // Integral gain
    float Kd;               // Derivative gain
    float integral;         // Integral accumulator
    float prev_error;       // Previous error for derivative
    float output_limit;     // Output saturation limit
    float integral_limit;   // Anti-windup limit
} PID_Controller;

void PID_Init(PID_Controller *pid, float Kp, float Ki, float Kd, float output_limit, float integral_limit);
float PID_Update(PID_Controller *pid, float setpoint, float feedback, float dt);

#endif /* __PID_H */