#ifndef __OBSERVER_H
#define __OBSERVER_H

#include <stdint.h>

/**
 * @brief Sliding Mode Observer structure
 */
typedef struct {
    float angle;        // Estimated rotor angle (rad)
    float speed;        // Estimated speed (rad/s)
    float alpha_est;    // Estimated α-axis current
    float beta_est;     // Estimated β-axis current
    float K1;           // Observer gain (current error)
    float K2;           // Observer gain (speed estimation)
    float Ls;           // Stator inductance (H)
    float Rs;           // Stator resistance (Ω)
    float dt;           // Sampling time (s)
} SlidingModeObserver;

void Observer_Init(SlidingModeObserver *obs, float dt);
void Observer_Update(SlidingModeObserver *obs, float alpha, float beta, 
                    float Valpha, float Vbeta);

#endif /* __OBSERVER_H */