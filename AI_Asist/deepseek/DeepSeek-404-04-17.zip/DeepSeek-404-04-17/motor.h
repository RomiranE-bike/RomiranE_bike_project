#ifndef __MOTOR_H
#define __MOTOR_H

#include "pid.h"
#include "observer.h"

typedef enum {
    MOTOR_STOPPED,
    MOTOR_STARTUP,
    MOTOR_RUNNING,
    MOTOR_FAULT
} Motor_State;

typedef struct {
    Motor_State state;
    float target_speed;      // rad/s
    float max_current;       // A
    float max_voltage;       // V
    float pole_pairs;
    float phase_resistance;  // Ω
    float phase_inductance;  // H
    
    PID_Controller speed_pid;
    PID_Controller current_q_pid;
    PID_Controller current_d_pid;
    
    SlidingModeObserver observer;
    
    // Startup parameters
    float startup_duty;
    float startup_time;
    float startup_elapsed;
} Motor_Controller;

void Motor_Init(Motor_Controller *motor);
void Motor_Update(Motor_Controller *motor, float Ia, float Ib, float Ic, 
                 float Vdc, float dt, float *pwm1, float *pwm2, float *pwm3);
void Motor_Set_Speed(Motor_Controller *motor, float speed);
void Motor_Stop(Motor_Controller *motor);

#endif /* __MOTOR_H */