/**
  * @file    system_stm32f1xx.c
  * @brief   CMSIS Cortex-M3 Device Peripheral Access Layer
  *          - Configures system clock to 72MHz using HSE (8MHz crystal)
  *          - Sets up FLASH latency and prefetch buffer
  * @author  STMicroelectronics
  * @date    YYYY-MM-DD
  */

#include "stm32f1xx.h"

/* Clock Definitions */
#define HSE_VALUE   8000000U  /* 8MHz external crystal */
#define HSI_VALUE   8000000U  /* Internal RC oscillator */

/* Global Variables */
uint32_t SystemCoreClock = 72000000U;  /* System Clock Frequency */

/**
  * @brief  System Clock Configuration (72MHz HCLK)
  *         Called during startup (before main())
  */
void SystemInit(void)
{
  /* Enable Prefetch Buffer */
  FLASH->ACR |= FLASH_ACR_PRFTBE;
  
  /* 2 Wait States (required at 72MHz) */
  FLASH->ACR &= ~FLASH_ACR_LATENCY;
  FLASH->ACR |= FLASH_ACR_LATENCY_2;
  
  /* Reset CFGR register */
  RCC->CFGR = 0x00000000;
  
  /* Enable HSE (external 8MHz crystal) */
  RCC->CR |= RCC_CR_HSEON;
  while(!(RCC->CR & RCC_CR_HSERDY));
  
  /* Configure PLL (8MHz * 9 = 72MHz) */
  RCC->CFGR |= RCC_CFGR_PLLMULL9 | RCC_CFGR_PLLSRC;
  
  /* Enable PLL */
  RCC->CR |= RCC_CR_PLLON;
  while(!(RCC->CR & RCC_CR_PLLRDY));
  
  /* Select PLL as system clock source */
  RCC->CFGR |= RCC_CFGR_SW_PLL;
  while((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL);
  
  /* Configure APB1 = 36MHz, APB2 = 72MHz */
  RCC->CFGR |= RCC_CFGR_PPRE1_DIV2 | RCC_CFGR_PPRE2_DIV1;
  
  /* Update SystemCoreClock variable */
  SystemCoreClockUpdate();
}

/**
  * @brief  Updates SystemCoreClock variable
  */
void SystemCoreClockUpdate(void)
{
  uint32_t tmp = 0U;
  
  switch (RCC->CFGR & RCC_CFGR_SWS)
  {
    case RCC_CFGR_SWS_HSI:  /* HSI used as system clock */
      SystemCoreClock = HSI_VALUE;
      break;
      
    case RCC_CFGR_SWS_HSE:  /* HSE used as system clock */
      SystemCoreClock = HSE_VALUE;
      break;
      
    case RCC_CFGR_SWS_PLL:  /* PLL used as system clock */
      /* PLL clock = HSE * PLL multiplier */
      tmp = RCC->CFGR & RCC_CFGR_PLLMULL;
      if (tmp == RCC_CFGR_PLLMULL6_5) {
        SystemCoreClock = (HSI_VALUE * 13U) / 2U;
      }
      else if (tmp == RCC_CFGR_PLLMULL9) {
        SystemCoreClock = HSE_VALUE * 9U;
      }
      break;
      
    default:
      SystemCoreClock = HSI_VALUE;
      break;
  }
  
  /* Compute HCLK clock divider */
  tmp = AHBPrescTable[((RCC->CFGR & RCC_CFGR_HPRE) >> 4)];
  SystemCoreClock >>= tmp;
}

/* AHBPrescTable values */
const uint8_t AHBPrescTable[16] = {
  0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 6, 7, 8, 9
};