#include "main.h"
#include "motor.h"
#include "adc_handler.h"
#include "uart_comm.h"
#include "motor_config.h"

Motor_Controller motor;  // Global motor controller instance

int main(void) {
  // HAL Initialization (auto-generated)
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_TIM1_Init();
  MX_USART1_UART_Init();

  // Initialize modules
  Motor_Init(&motor);
  ADC_Init(&hadc1);
  UART_Init(&huart1);

  // Start PWM
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);

  // Main loop
  uint32_t last_tick = HAL_GetTick();
  Motor_Controller motor;
  Motor_Config_Init(&motor);  // Initialize hardware parameters
  Current_Sensor_Calibrate(&hadc1);  // Call with motor stopped
  while (1) {
    uint32_t current_tick = HAL_GetTick();
    float dt = (current_tick - last_tick) * 0.001f;  // Convert to seconds
    last_tick = current_tick;

    // 1. Read sensors
    float Ia = get_phase_current(0);  // Phase A current
    float Ib = get_phase_current(1);  // Phase B current
    float Ic = get_phase_current(2);  // Phase C current
    float Vdc = get_dc_voltage();     // DC bus voltage
    float speed = get_potentiometer() * 100.0f;  // Scale pot to rad/s
    Motor_Set_Speed(&motor, speed);
    // 2. Update motor control
    float pwm1, pwm2, pwm3;
    Motor_Update(&motor, Ia, Ib, Ic, Vdc, dt, &pwm1, &pwm2, &pwm3);

    // 3. Apply PWM
    uint32_t pwm_max = htim1.Instance->ARR;
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, pwm1 * pwm_max);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, pwm2 * pwm_max);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, pwm3 * pwm_max);

    // 4. Handle UART commands
    UART_Process_Commands(&motor);

    HAL_Delay(1);  // ~1kHz control loop
  }
}

// Error handler (blink LED)
void Error_Handler(void) {
  while (1) {
    HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);
    HAL_Delay(100);
  }
}