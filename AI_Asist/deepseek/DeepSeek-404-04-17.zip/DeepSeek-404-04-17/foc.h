/**
  * @file    foc.h
  * @brief   Field-Oriented Control (FOC) transformations for 3-phase motors
  * @author  Your Name
  * @date    YYYY-MM-DD
  */

#ifndef __FOC_H
#define __FOC_H

#include "stm32f1xx_hal.h"
#include <math.h>

/**
  * @brief Clarke transform output structure (αβ-frame)
  */
typedef struct {
    float alpha;    /*!< α-axis component */
    float beta;     /*!< β-axis component */
} Clarke_Components;

/**
  * @brief Park transform output structure (dq-frame)
  */
typedef struct {
    float d;        /*!< Direct-axis component */
    float q;        /*!< Quadrature-axis component */
} Park_Components;

/**
  * @brief Inverse Park transform output structure
  */
typedef struct {
    float alpha;    /*!< α-axis component */
    float beta;     /*!< β-axis component */
} Inv_Park_Components;

/* Function Prototypes */
Clarke_Components Clarke_Transform(float a, float b, float c);
Park_Components Park_Transform(float alpha, float beta, float theta);
Inv_Park_Components Inv_Park_Transform(float d, float q, float theta);
void FOC_Update(float Ia, float Ib, float Ic, float theta, float Vd, float Vq, 
               float *pwm1, float *pwm2, float *pwm3);

#endif /* __FOC_H */