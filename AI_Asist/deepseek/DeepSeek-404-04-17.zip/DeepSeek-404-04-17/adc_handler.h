#ifndef __ADC_HANDLER_H
#define __ADC_HANDLER_H

#include "stm32f1xx_hal.h"

#define ADC_CHANNELS 5
#define ADC_FILTER_SAMPLES 8

extern uint16_t adc_buffer[ADC_CHANNELS * ADC_FILTER_SAMPLES];

void ADC_Init(ADC_HandleTypeDef *hadc);
void Calibrate_Current_Offsets(void);
float get_phase_current(uint8_t channel);
float get_dc_voltage(void);
float get_potentiometer(void);

#endif /* __ADC_HANDLER_H */