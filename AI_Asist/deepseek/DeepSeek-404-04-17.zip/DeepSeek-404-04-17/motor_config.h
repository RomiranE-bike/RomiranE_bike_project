/**
  * @file    motor_config.h
  * @brief   Motor hardware configuration defines
  * @author  Your Name
  * @date    YYYY-MM-DD
  */

#ifndef __MOTOR_CONFIG_H
#define __MOTOR_CONFIG_H

#include "motor.h"

/* Motor Electrical Parameters */
#define POLE_PAIRS          7       // 42-pole → 7 pole pairs
#define PHASE_RESISTANCE    0.4f    // Ohms per phase
#define PHASE_INDUCTANCE    0.001f  // Henries
#define MAX_CURRENT         10.0f   // Amperes (current limit)
#define MAX_VOLTAGE         48.0f   // Volts (set lower than supply)

/* Hardware Settings */
#define PWM_FREQUENCY       20000   // Hz (20kHz typical for FOC)
#define ADC_FILTER_SAMPLES  8       // Moving average filter depth

/* Current Sensing (Update for your hardware!) */
#define SHUNT_RESISTOR      0.1f    // Ohms
#define AMP_GAIN            20.0f   // Current amplifier gain
//-------------------------------------------------
/* Function Prototypes */
void Motor_Config_Init(Motor_Controller *motor);
void Current_Sensor_Calibrate(ADC_HandleTypeDef *hadc);
float ADC_to_Current(uint16_t raw_adc, uint8_t channel);

#endif /* __MOTOR_CONFIG_H */