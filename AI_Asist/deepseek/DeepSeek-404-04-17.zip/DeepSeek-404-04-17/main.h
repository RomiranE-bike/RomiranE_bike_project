#ifndef __MAIN_H
#define __MAIN_H

#include "stm32f1xx_hal.h"
#include "motor.h"

// Exported variables
extern TIM_HandleTypeDef htim1;
extern ADC_HandleTypeDef hadc1;
extern UART_HandleTypeDef huart1;

// Function prototypes
void Error_Handler(void);

#endif /* __MAIN_H */