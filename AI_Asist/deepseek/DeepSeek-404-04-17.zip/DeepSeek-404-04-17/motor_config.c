/**
  * @file    motor_config.c
  * @brief   Hardware-specific motor configuration
  * @author  Your Name
  * @date    YYYY-MM-DD
  */

#include "motor_config.h"
#include "stm32f1xx_hal.h"

/**
  * @brief Initialize hardware-specific motor parameters
  * @param motor Pointer to motor controller structure
  */
void Motor_Config_Init(Motor_Controller *motor) {
    /* BLDC Motor Parameters (Update these for your motor!) */
    motor->pole_pairs = 7;          // 42-pole motor → 7 pole pairs
    motor->phase_resistance = 0.4f;  // Ohms per phase (measured)
    motor->phase_inductance = 0.001f;// Henries (measured)
    motor->max_current = 10.0f;      // Amperes (current limit)
    motor->max_voltage = 48.0f;      // Volts (set lower than power supply)

    /* Hardware Configuration */
    motor->pwm_frequency = 20000;    // 20kHz PWM frequency
    motor->adc_filter_samples = 8;   // Moving average filter depth

    /* Current Sensing Calibration (Update for your hardware!) */
    motor->shunt_resistor = 0.1f;    // Shunt resistor value (Ohms)
    motor->amp_gain = 20.0f;         // Current sense amplifier gain

    /* Startup Parameters */
    motor->startup_duty = 0.1f;      // Initial duty cycle (10%)
    motor->startup_time = 1.0f;      // Open-loop duration (seconds)
}

/**
  * @brief Calibrate current sensor offsets (call with motor stopped)
  * @param hadc Pointer to ADC handle
  */
void Current_Sensor_Calibrate(ADC_HandleTypeDef *hadc) {
    float sum[3] = {0};
    uint16_t adc_buffer[3*8]; // Temporary buffer for 3 channels × 8 samples
    
    HAL_ADC_Start_DMA(hadc, (uint32_t*)adc_buffer, 24);
    HAL_Delay(10); // Allow ADC to settle
    
    // Average samples for each channel
    for(int i=0; i<8; i++) {
        sum[0] += adc_buffer[i];     // Phase A
        sum[1] += adc_buffer[8+i];   // Phase B
        sum[2] += adc_buffer[16+i];  // Phase C
    }
    
    // Store offsets (to subtract from measurements)
    motor->current_offsets[0] = sum[0]/8;
    motor->current_offsets[1] = sum[1]/8;
    motor->current_offsets[2] = sum[2]/8;
}

/**
  * @brief Convert ADC reading to current (Amperes)
  * @param raw_adc Raw ADC value
  * @param channel 0=IA, 1=IB, 2=IC
  * @return Current in Amperes
  */
float ADC_to_Current(uint16_t raw_adc, uint8_t channel) {
    // Formula: I = (ADC - offset) × (3.3V / 4095) / (R_shunt × Gain)
    float voltage = (raw_adc - motor->current_offsets[channel]) * (3.3f / 4095.0f);
    return voltage / (motor->shunt_resistor * motor->amp_gain);
}