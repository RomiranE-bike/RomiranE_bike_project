#include "pid.h"
#include <math.h>

/**
 * @brief Initialize PID controller
 * @param pid PID instance
 * @param Kp Proportional gain
 * @param Ki Integral gain
 * @param Kd Derivative gain
 * @param output_limit Output saturation limit
 * @param integral_limit Anti-windup limit
 */
void PID_Init(PID_Controller *pid, float Kp, float Ki, float Kd, 
             float output_limit, float integral_limit) {
    pid->Kp = Kp;
    pid->Ki = Ki;
    pid->Kd = Kd;
    pid->integral = 0.0f;
    pid->prev_error = 0.0f;
    pid->output_limit = output_limit;
    pid->integral_limit = integral_limit;
}

/**
 * @brief Update PID controller
 * @param pid PID instance
 * @param setpoint Target value
 * @param feedback Measured value
 * @param dt Time step (seconds)
 * @return PID output
 */
float PID_Update(PID_Controller *pid, float setpoint, float feedback, float dt) {
    float error = setpoint - feedback;
    
    // Proportional term
    float P = pid->Kp * error;
    
    // Integral term with anti-windup
    pid->integral += error * dt;
    if (pid->integral > pid->integral_limit) {
        pid->integral = pid->integral_limit;
    } else if (pid->integral < -pid->integral_limit) {
        pid->integral = -pid->integral_limit;
    }
    float I = pid->Ki * pid->integral;
    
    // Derivative term (filtered)
    float D = pid->Kd * (error - pid->prev_error) / dt;
    pid->prev_error = error;
    
    // Calculate and limit output
    float output = P + I + D;
    if (output > pid->output_limit) {
        output = pid->output_limit;
    } else if (output < -pid->output_limit) {
        output = -pid->output_limit;
    }
    
    return output;
}