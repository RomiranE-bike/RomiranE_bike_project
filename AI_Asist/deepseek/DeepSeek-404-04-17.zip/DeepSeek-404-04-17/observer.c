#include "observer.h"
#include <math.h>

// Sign function macro
#define SIGN(x) ((x) > 0 ? 1.0f : ((x) < 0 ? -1.0f : 0.0f))

/**
 * @brief Initialize sliding mode observer
 * @param obs Observer instance
 * @param dt Sampling time (seconds)
 */
void Observer_Init(SlidingModeObserver *obs, float dt) {
    obs->angle = 0.0f;
    obs->speed = 0.0f;
    obs->alpha_est = 0.0f;
    obs->beta_est = 0.0f;
    
    // Tune these gains for your motor:
    obs->K1 = 100.0f;   // Current error gain (higher = faster tracking)
    obs->K2 = 10.0f;    // Speed estimation gain
    
    // Motor parameters (update in motor_config.h)
    obs->Ls = PHASE_INDUCTANCE;
    obs->Rs = PHASE_RESISTANCE;
    
    obs->dt = dt;
}

/**
 * @brief Update observer with new measurements
 * @param obs Observer instance
 * @param alpha,beta Measured currents (αβ frame)
 * @param Valpha,Vbeta Applied voltages (αβ frame)
 */
void Observer_Update(SlidingModeObserver *obs, float alpha, float beta,
                    float Valpha, float Vbeta) {
    // 1. Calculate current estimation errors
    float e_alpha = obs->alpha_est - alpha;
    float e_beta = obs->beta_est - beta;
    
    // 2. Sliding mode terms
    float z_alpha = obs->K1 * SIGN(e_alpha);
    float z_beta = obs->K1 * SIGN(e_beta);
    
    // 3. Back-EMF estimation
    float Ealpha = z_alpha;
    float Ebeta = z_beta;
    
    // 4. Update current estimates
    obs->alpha_est += obs->dt * ((Valpha - obs->Rs * alpha - Ealpha) / obs->Ls);
    obs->beta_est += obs->dt * ((Vbeta - obs->Rs * beta - Ebeta) / obs->Ls);
    
    // 5. Estimate rotor angle from back-EMF
    float angle_est = atan2f(-Ealpha, Ebeta);
    
    // 6. Normalize angle difference (-π to π)
    float angle_diff = angle_est - obs->angle;
    while(angle_diff > M_PI) angle_diff -= 2*M_PI;
    while(angle_diff < -M_PI) angle_diff += 2*M_PI;
    
    // 7. Update speed estimate (filtered)
    obs->speed = angle_diff / obs->dt;
    
    // 8. Update angle estimate
    obs->angle = angle_est;
    
    // 9. Normalize to 0-2π range
    while(obs->angle > 2*M_PI) obs->angle -= 2*M_PI;
    while(obs->angle < 0) obs->angle += 2*M_PI;
}