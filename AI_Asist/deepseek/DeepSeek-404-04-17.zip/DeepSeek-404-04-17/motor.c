#include "motor.h"
#include "foc.h"
#include <math.h>

/**
 * @brief Initialize motor controller
 * @param motor Motor controller instance
 */
void Motor_Init(Motor_Controller *motor) {
    motor->state = MOTOR_STOPPED;
    motor->target_speed = 0.0f;
    
    // Initialize with default values (override in motor_config.h)
    motor->pole_pairs = POLE_PAIRS;
    motor->phase_resistance = PHASE_RESISTANCE;
    motor->phase_inductance = PHASE_INDUCTANCE;
    motor->max_current = MAX_CURRENT;
    motor->max_voltage = MAX_VOLTAGE;
    
    // Initialize PID controllers
    PID_Init(&motor->speed_pid, 0.1f, 0.05f, 0.001f, 
             motor->max_current, motor->max_current);
    PID_Init(&motor->current_q_pid, 1.0f, 0.1f, 0.0f,
             motor->max_voltage, motor->max_voltage);
    PID_Init(&motor->current_d_pid, 1.0f, 0.1f, 0.0f,
             motor->max_voltage, motor->max_voltage);
    
    // Initialize observer
    Observer_Init(&motor->observer, 0.00005f); // 50μs update rate
    
    // Startup parameters
    motor->startup_duty = 0.1f;
    motor->startup_time = 1.0f;
    motor->startup_elapsed = 0.0f;
}

// ... (Continued in next message due to length limits)
/**
 * @brief Update motor control algorithm
 * @param motor Controller instance
 * @param Ia,Ib,Ic Phase currents (A)
 * @param Vdc DC bus voltage (V)
 * @param dt Time step (s)
 * @param pwm1-3 Output PWM duties [0-1]
 */
void Motor_Update(Motor_Controller *motor, float Ia, float Ib, float Ic,
                 float Vdc, float dt, float *pwm1, float *pwm2, float *pwm3) {
    // 1. Clarke transform currents
    Clarke_Components clarke = Clarke_Transform(Ia, Ib, Ic);
    
    switch(motor->state) {
        case MOTOR_STOPPED:
            // Safe state - all PWMs at 50% (zero voltage)
            *pwm1 = 0.5f;
            *pwm2 = 0.5f;
            *pwm3 = 0.5f;
            break;
            
        case MOTOR_STARTUP:
            // Open-loop acceleration
            motor->startup_elapsed += dt;
            
            if(motor->startup_elapsed >= motor->startup_time) {
                motor->state = MOTOR_RUNNING;
                break;
            }
            
            // Ramp frequency from 0 to 5Hz
            float progress = motor->startup_elapsed / motor->startup_time;
            float freq = 5.0f * progress;
            
            // Generate open-loop angle
            static float startup_angle = 0.0f;
            startup_angle += 2 * M_PI * freq * dt;
            while(startup_angle > 2*M_PI) startup_angle -= 2*M_PI;
            
            // Apply fixed voltage (Vq only)
            float Vq = motor->startup_duty * motor->max_voltage * progress;
            
            // Initialize observer with open-loop angle
            motor->observer.angle = startup_angle;
            motor->observer.speed = 2 * M_PI * freq;
            
            // Generate PWM
            FOC_Update(Ia, Ib, Ic, startup_angle, 0, Vq, pwm1, pwm2, pwm3);
            break;
            
        case MOTOR_RUNNING:
            // 2. Park transform for current control
            Park_Components current_park = Park_Transform(
                clarke.alpha, clarke.beta, motor->observer.angle);
            
            // 3. Speed control (outer loop)
            float target_Iq = PID_Update(&motor->speed_pid, 
                                       motor->target_speed, 
                                       motor->observer.speed, 
                                       dt);
            
            // 4. Current control (inner loops)
            float Vq = PID_Update(&motor->current_q_pid,
                                target_Iq,
                                current_park.q,
                                dt);
            float Vd = PID_Update(&motor->current_d_pid,
                                0.0f,  // Id_ref = 0 (max torque)
                                current_park.d,
                                dt);
            
            // 5. Update sensorless observer
            Inv_Park_Components inv_park = Inv_Park_Transform(Vd, Vq, motor->observer.angle);
            Observer_Update(&motor->observer, 
                          clarke.alpha, clarke.beta,
                          inv_park.alpha, inv_park.beta);
            
            // 6. Generate PWM
            FOC_Update(Ia, Ib, Ic, motor->observer.angle, Vd, Vq, pwm1, pwm2, pwm3);
            break;
            
        case MOTOR_FAULT:
            // Emergency stop - disable PWMs
            *pwm1 = 0.5f;
            *pwm2 = 0.5f;
            *pwm3 = 0.5f;
            break;
    }
}

/**
 * @brief Set target speed (rad/s)
 */
void Motor_Set_Speed(Motor_Controller *motor, float speed) {
    if(speed == 0.0f) {
        Motor_Stop(motor);
    } else {
        motor->target_speed = speed;
        if(motor->state == MOTOR_STOPPED) {
            motor->state = MOTOR_STARTUP;
            motor->startup_elapsed = 0.0f;
        }
    }
}

/**
 * @brief Emergency stop
 */
void Motor_Stop(Motor_Controller *motor) {
    motor->state = MOTOR_STOPPED;
    motor->target_speed = 0.0f;
    
    // Reset controllers
    motor->speed_pid.integral = 0.0f;
    motor->current_q_pid.integral = 0.0f;
    motor->current_d_pid.integral = 0.0f;
}