#include "foc.h"
#include "svpwm.h"

/**
 * Transforms 3-phase currents to 2-phase (αβ)
 * @param a,b,c Phase currents (A)
 * @return Clarke components (αβ)
 */
Clarke_Components Clarke_Transform(float a, float b, float c) {
  Clarke_Components clarke;
  clarke.alpha = a;                     // α = a
  clarke.beta = (b - c) * 0.57735f;     // β = (b-c)/√3
  return clarke;
}

/**
 * Transforms stationary (αβ) to rotating frame (dq)
 * @param alpha,beta Stationary components
 * @param theta Electrical angle (rad)
 * @return Park components (dq)
 */
Park_Components Park_Transform(float alpha, float beta, float theta) {
  Park_Components park;
  float sin_t = sinf(theta);
  float cos_t = cosf(theta);
  park.d = alpha * cos_t + beta * sin_t;    // d = α*cosθ + β*sinθ
  park.q = -alpha * sin_t + beta * cos_t;   // q = -α*sinθ + β*cosθ
  return park;
}

/**
 * Inverse Park transform (dq → αβ)
 * @param d,q Rotating frame components
 * @param theta Electrical angle (rad)
 * @return Stationary components (αβ)
 */
Inv_Park_Components Inv_Park_Transform(float d, float q, float theta) {
  Inv_Park_Components inv_park;
  float sin_t = sinf(theta);
  float cos_t = cosf(theta);
  inv_park.alpha = d * cos_t - q * sin_t;   // α = d*cosθ - q*sinθ
  inv_park.beta = d * sin_t + q * cos_t;    // β = d*sinθ + q*cosθ
  return inv_park;
}

/**
 * Main FOC update function
 * @param Ia,Ib,Ic Phase currents (A)
 * @param theta Electrical angle (rad)
 * @param Vd,Vq Reference voltages (V)
 * @param pwm1-3 Output PWM duty cycles [0-1]
 */
void FOC_Update(float Ia, float Ib, float Ic, float theta, float Vd, float Vq, float *pwm1, float *pwm2, float *pwm3) {
  Clarke_Components clarke = Clarke_Transform(Ia, Ib, Ic);
  Inv_Park_Components inv_park = Inv_Park_Transform(Vd, Vq, theta);
  SVPWM_Generate(inv_park.alpha, inv_park.beta, pwm1, pwm2, pwm3);
}