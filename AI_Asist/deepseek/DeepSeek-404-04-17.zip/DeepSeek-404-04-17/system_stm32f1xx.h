/**
  * @file    system_stm32f1xx.h
  * @brief   CMSIS Cortex-M3 Device Header File for STM32F103
  * @author  STMicroelectronics
  */

#ifndef SYSTEM_STM32F1XX_H
#define SYSTEM_STM32F1XX_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

/* System Clock Frequency (Core Clock) */
extern uint32_t SystemCoreClock;  // Defined in system_stm32f1xx.c

/* Function Prototypes */
void SystemInit(void);            // Initialize clock and Flash
void SystemCoreClockUpdate(void); // Update SystemCoreClock variable

#ifdef __cplusplus
}
#endif

#endif /* SYSTEM_STM32F1XX_H */