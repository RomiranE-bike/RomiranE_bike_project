#include "adc_handler.h"
#include "motor_config.h"

uint16_t adc_buffer[ADC_CHANNELS * ADC_FILTER_SAMPLES];
float current_offsets[3] = {0};

void ADC_Init(ADC_HandleTypeDef *hadc) {
    if (HAL_ADCEx_Calibration_Start(hadc) != HAL_OK) {
        Error_Handler();
    }
    HAL_ADC_Start_DMA(hadc, (uint32_t*)adc_buffer, 
                     ADC_CHANNELS * ADC_FILTER_SAMPLES);
}

// ... (Implementation continues)

/**
 * @brief Calibrate current sensor offsets (call with motor stopped)
 */
void Calibrate_Current_Offsets(void) {
    float sum[3] = {0};
    
    // Average multiple samples
    for(int i = 0; i < ADC_FILTER_SAMPLES; i++) {
        sum[0] += adc_buffer[ADC_CHANNEL_IA * ADC_FILTER_SAMPLES + i];
        sum[1] += adc_buffer[ADC_CHANNEL_IB * ADC_FILTER_SAMPLES + i];
        sum[2] += adc_buffer[ADC_CHANNEL_IC * ADC_FILTER_SAMPLES + i];
    }
    
    current_offsets[0] = sum[0] / ADC_FILTER_SAMPLES;
    current_offsets[1] = sum[1] / ADC_FILTER_SAMPLES;
    current_offsets[2] = sum[2] / ADC_FILTER_SAMPLES;
}

/**
 * @brief Get filtered phase current
 * @param channel 0=IA, 1=IB, 2=IC
 * @return Current in Amperes
 */
float get_phase_current(uint8_t channel) {
    if(channel > 2) return 0.0f;
    
    // Moving average filter
    float sum = 0;
    for(int i = 0; i < ADC_FILTER_SAMPLES; i++) {
        sum += adc_buffer[channel * ADC_FILTER_SAMPLES + i];
    }
    float average = sum / ADC_FILTER_SAMPLES;
    
    // Convert ADC → Voltage → Current
    // Formula: I = (ADC_value - offset) * (Vref / 4095) / (R_shunt × Gain)
    float voltage = (average - current_offsets[channel]) * (3.3f / 4095.0f);
    return voltage / (SHUNT_RESISTOR * AMP_GAIN);
}

/**
 * @brief Get DC bus voltage
 * @return Voltage in Volts
 */
float get_dc_voltage(void) {
    float sum = 0;
    for(int i = 0; i < ADC_FILTER_SAMPLES; i++) {
        sum += adc_buffer[ADC_CHANNEL_VBUS * ADC_FILTER_SAMPLES + i];
    }
    float average = sum / ADC_FILTER_SAMPLES;
    
    // Voltage divider conversion
    // Vbus = ADC_value × (Vref / 4095) × (R1 + R2)/R2
    return average * (3.3f / 4095.0f) * 11.0f; // 11:1 divider ratio
}

/**
 * @brief Get potentiometer value
 * @return Normalized value [0-1]
 */
float get_potentiometer(void) {
    float sum = 0;
    for(int i = 0; i < ADC_FILTER_SAMPLES; i++) {
        sum += adc_buffer[ADC_CHANNEL_POT * ADC_FILTER_SAMPLES + i];
    }
    return (sum / ADC_FILTER_SAMPLES) / 4095.0f;
}